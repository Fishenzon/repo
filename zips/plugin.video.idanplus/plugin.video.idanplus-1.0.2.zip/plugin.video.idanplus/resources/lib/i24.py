﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import sys, re, json, urllib, urllib2, urlparse, base64
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'i24'
userAgent = common.GetUserAgent()

def WatchLive(url, name='', iconimage='', quality='best'):
	headers={"User-Agent": userAgent}
	text = common.OpenURL(url, headers=headers)
	match = re.compile("__STORES__ = '(.*?)'").findall(text)
	a2 = json.loads(base64.b64decode(match[0]))
	text = common.OpenURL('http://www.dailymotion.com/embed/video/{0}'.format(a2.get('LiveVideoStore', '').get('video', '').get('hash', '')), headers=headers)
	match = re.compile('"stream_chromecast_url":"(.*?)"').findall(text)
	link = common.OpenURL('{0}&redirect=0'.format(match[0].replace('\\','')), headers=headers)
	link = common.GetStreams(link, headers=headers, quality=quality)
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	if quality == 'choose':
		listitem = xbmcgui.ListItem(name, path=final, iconImage=iconimage, thumbnailImage=iconimage)
		listitem.setInfo(type="Video", infoLabels={"Title": name})
		xbmc.Player().play(final, listitem)
	else:
		listitem = xbmcgui.ListItem(path=final)
		xbmcplugin.setResolvedUrl(handle=handle, succeeded=True, listitem=listitem)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 10:
		WatchLive(url, name, iconimage, moreData)
		
	common.SetViewMode('episodes')