﻿# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import sys, re, cookielib
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'knesset'
userAgent = common.GetUserAgent()

def WatchLive(name='', iconimage='', quality='best'):
	headers={"User-Agent": userAgent}
	url = 'https://main.knesset.gov.il/News/Broadcast/Pages/Channel99.aspx'
	cookie_jar = cookielib.LWPCookieJar()
	text = common.OpenURL(url, headers=headers, CookieJar=cookie_jar)
	cookies = ['{0}={1}'.format(_cookie.name, _cookie.value) for _cookie in cookie_jar]
	headers['Cookie'] = cookies[0]#[:cookies[0].find(';')]
	text = common.OpenURL(url, headers=headers)
	headers={"User-Agent": userAgent}
	#match = re.compile("UpdateMEPlayer\('(.*?)'\);").findall(text)
	#link = common.GetStreams(match[0], headers=headers, quality=quality)
	match = re.compile('<iframe src="(.+?)"').findall(text)
	text = common.OpenURL(match[0], headers=headers)
	match = re.compile('<meta name="twitter:player:stream" content="(.+?)"').findall(text)
	url = common.GetRedirect(match[0], headers=headers)
	link = common.GetStreams(url, headers=headers, quality=quality)
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 10:
		WatchLive(name, iconimage, moreData)
		
	common.SetViewMode('episodes')
