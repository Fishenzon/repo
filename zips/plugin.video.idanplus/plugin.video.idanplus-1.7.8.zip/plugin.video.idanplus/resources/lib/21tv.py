﻿# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import sys, re, urlparse
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = '21tv'
userAgent = common.GetUserAgent()

def WatchLive(name='', iconimage='', quality='best'):
	headers={"User-Agent": userAgent}
	url = 'http://www.21.tv/pages/video/video.htm'
	text = common.OpenURL(url, headers=headers)
	match = re.compile('var videoSrc="(.*?)";').findall(text)
	text = common.OpenURL(match[0], headers=headers)
	match = re.compile("var\s*metadataURL\s*?=\s*?'(.+?)'").findall(text)
	text = common.OpenURL(match[0], headers=headers)
	match = re.compile("<SmilURL.*>(.+)</SmilURL>").findall(text)
	smil = match[0].replace('amp;', '')
	match = re.compile("<Server priority='1'>(.+)</Server>").findall(text)
	server = match[0]
	link = urlparse.urlunparse(urlparse.urlparse(smil)._replace(netloc=server))
	link = common.GetStreams(link, headers=headers, quality=quality)
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 10:
		WatchLive(name, iconimage, moreData)
		
	common.SetViewMode('episodes')