﻿# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import os, sys, time, datetime, tarfile
import resources.lib.common as common

AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'iptv'
imagesDir = 'special://home/addons/{0}/resources/images/'.format(AddonID)
profileDir = common.profileDir
m3uFile = os.path.join(profileDir, 'idanplus.m3u')
xmlFile = os.path.join(profileDir, 'epg.xml')

def MakeIPTVlist(channels):
	if Addon.getSetting("useIPTV") != 'true':
		return
	iptvList = '#EXTM3U\n'
	for item in channels:
		try:
			type = item.get('type', '')
			if type != 'radio' and type != 'tv':
				continue
			tvg_id = item["tvgID"]
			view_name = common.GetLocaleString(item['nameID'])
			tvg_logo = '{0}{1}'.format(imagesDir, item['image'])
			if type == 'radio':
				radio = ' radio="true"'
				group = ' group-title="Radio"'
			elif type == 'tv': 
				radio = ''
				group = ' group-title="TV"'
			resKey = item.get('resKey', '')
			if resKey == '':
				bitrate = 'best'
			else:
				bitrate = Addon.getSetting(resKey)
				if bitrate == '':
					bitrate = 'best'
			url = '{0}?url={1}&mode={2}&module={3}&moredata={4}'.format(sys.argv[0], item['channelID'], item['mode'], item['module'], bitrate)
			iptvList += '\n#EXTINF:-1 tvg-id="{0}"{1} tvg-logo="{2}"{3},{4}\n{5}\n'.format(tvg_id, group, tvg_logo, radio, view_name, url)
		except Exception as ex:
			xbmc.log("{0}".format(ex), 3)
	iptvListOld = ''
	if os.path.isfile(m3uFile):
		with open(m3uFile, 'r') as f:
			iptvListOld = f.read()
	if iptvListOld != iptvList:
		with open(m3uFile, 'w') as f:
			f.write(iptvList)

def GetTZtime(timestamp):
	ts = time.time()
	tz = Addon.getSetting('timeZone')
	if tz == '':
		delta = datetime.datetime.fromtimestamp(ts) - datetime.datetime.utcfromtimestamp(ts)
	else:
		tz = float(tz)
		delta = datetime.timedelta(hours=-tz) * -1 if tz < 0 else datetime.timedelta(hours=tz)
	hrs = '+0000'
	if delta > datetime.timedelta(0):
		hrs = '+{0:02d}{1:02d}'.format(delta.seconds//3600, (delta.seconds//60)%60)
	else:
		delta = -delta
		hrs = '-{0:02d}{1:02d}'.format(delta.seconds//3600, (delta.seconds//60)%60)
	return '{0} {1}'.format(time.strftime('%Y%m%d%H%M%S', time.localtime(timestamp)), hrs)

def MakeChannelsGuide():
	if Addon.getSetting("useIPTV") != 'true':
		return
	channelsList = ""
	programmeList = ""
	epgList = common.ReadList(common.epgFile)
	for key,val in epgList.items():
		chName = key.encode("utf-8")
		channelsList += "\t<channel id=\"{0}\">\n\t\t<display-name>{1}</display-name>\n\t</channel>\n".format(common.EscapeXML(chName), chName)
		for programme in val:
			start = GetTZtime(programme["start"])
			end = GetTZtime(programme["end"])
			name = common.EscapeXML(programme["name"].encode("utf-8")) if programme["name"] != None else ""
			description = common.EscapeXML(programme["description"].encode("utf-8")) if programme["description"] != None else ""
			programmeList += "\t<programme start=\"{0}\" stop=\"{1}\" channel=\"{2}\">\n\t\t<title>{3}</title>\n\t\t<desc>{4}</desc>\n\t</programme>\n".format(start, end, common.EscapeXML(chName), name, description)
	xmlList = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<tv>\n{0}{1}</tv>".format(channelsList, programmeList)
	with open(xmlFile, 'w') as f:
		f.write(xmlList)
	if Addon.getSetting("zipEPG") == 'true':
		with tarfile.open('{0}.tar.gz'.format(xmlFile), "w:gz") as tar:
			tar.add(xmlFile)
		try:
			os.remove(xmlFile)
		except:
			pass

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 1:
		MakeIPTVlist(moreData)
	common.SetViewMode('episodes')