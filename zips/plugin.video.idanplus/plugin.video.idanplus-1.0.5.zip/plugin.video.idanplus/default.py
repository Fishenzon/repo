# -*- coding: utf-8 -*-
import sys, os, urlparse, urllib, datetime
import xbmc, xbmcplugin, xbmcaddon
import resources.lib.common as common
import resources.lib.epg as epg

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
imagesDir = xbmc.translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources', 'images')).decode("utf-8")

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
url = urllib.unquote_plus(params.get('url', ''))
mode = int(params.get('mode','-1'))
name = urllib.unquote_plus(params.get('name', ''))
iconimage = urllib.unquote_plus(params.get('iconimage', ''))
module = params.get('module')
moreData = urllib.unquote_plus(params.get('moredata', ''))

def GetCategoriesList():
	name = '[B]שידורים חיים[/B]'
	common.addDir(name, '', 1, icon, {"Title": name})
	name = 'כאן VOD'
	common.addDir(name, '', 0, os.path.join(imagesDir, "kan.jpg"), infos={"Title": name}, module='kan')
	name = 'מאקו VOD'
	common.addDir(name, '', 0, os.path.join(imagesDir, "mako.png"), infos={"Title": name}, module='keshet')
	name = 'רשת VOD'
	common.addDir(name, '', 0, os.path.join(imagesDir, "reshet.png"), infos={"Title": name}, module='reshet')
	name = 'עשר VOD'
	common.addDir(name, '', 0, os.path.join(imagesDir, "ten.png"), infos={"Title": name}, module='ten')

def LiveChannels():
	name = '[B]קליק ימני על ערוץ להצגת מדריך מפורט[/B]'
	common.addDir(name, '', 99, icon, infos={"Title": name}, isFolder=False)
	name = '[B]רענון רשימה[/B]'
	common.addDir(name, '', 2, icon, infos={"Title": name}, isFolder=False)
	nowEPG = epg.GetNowEPG()
	LiveChannel('כאן 11', '11', 10, os.path.join(imagesDir, "11.png"), 'kan', programs=nowEPG.get('11', []))
	LiveChannel('קשת 12', '12', 10, os.path.join(imagesDir, "12.jpg"), 'keshet', programs=nowEPG.get('12', []))
	LiveChannel('רשת 13', '13', 4, os.path.join(imagesDir, "reshet.png"), 'reshet', programs=nowEPG.get('13', []))
	LiveChannel('עשר 14', '14', 6, os.path.join(imagesDir, "ten.png"), 'ten', programs=nowEPG.get('14', []))
	LiveChannel('מורשת 20', '20', 10, os.path.join(imagesDir, "20.png"), 'twenty', programs=nowEPG.get('20', []))
	LiveChannel('מוזיקה 24', '24', 10, os.path.join(imagesDir, "24.jpg"), 'keshet', programs=nowEPG.get('24', []))
	LiveChannel('מכאן 33', '33', 10, os.path.join(imagesDir, "33.png"), 'kan', programs=nowEPG.get('33', []))
	LiveChannel('קבלה 66', '66', 10, os.path.join(imagesDir, "kabbalah.jpg"), 'kabbalah', programs=nowEPG.get('66', []))
	LiveChannel('מאיר 96', '96', 10, os.path.join(imagesDir, "meirtv.jpg"), 'meirtv', programs=nowEPG.get('96', []))
	LiveChannel('הידברות 97', '97', 10, os.path.join(imagesDir, "hidabroot.jpg"), 'hidabroot', programs=nowEPG.get('97', []))
	LiveChannel('כנסת 99', '99', 10, os.path.join(imagesDir, "knesset.png"), 'knesset', programs=nowEPG.get('99', []))
	LiveChannel('i24 English', 'i24en', 10, os.path.join(imagesDir, "i24.png"), 'i24', programs=nowEPG.get('i24en', []))
	LiveChannel('i24 French', 'i24fr', 10, os.path.join(imagesDir, "i24.png"), 'i24', programs=nowEPG.get('i24fr', []))
	LiveChannel('i24 Arabic', 'i24ar', 10, os.path.join(imagesDir, "i24.png"), 'i24', programs=nowEPG.get('i24ar', []))
	LiveChannel('קשת המיטב', 'keshetBest', 10, os.path.join(imagesDir, "keshet_best.jpg"), 'keshet')
	common.SetViewMode('episodes')

def LiveChannel(name, url, mode, iconimage, module, choose=True, programs=[]):
	displayName = "[COLOR {0}][B]{1}[/B][/COLOR]".format(Addon.getSetting("chColor"), name)
	description = ''
	contextMenu = []
	if choose:
		contextMenu.append((common.GetLocaleString(30005), 'RunPlugin({0}?url={1}&name={2}&mode={3}&iconimage={4}&moredata=choose&module={5})'.format(sys.argv[0], url, urllib.quote_plus(name), mode, urllib.quote_plus(iconimage), module)))
	if len(programs) > 0:
		contextMenu.append(('EPG', 'Container.Update({0}?url={1}&name={2}&mode=2&iconimage={3}&module=epg)'.format(sys.argv[0], url, urllib.quote_plus(name), urllib.quote_plus(iconimage))))
		start_time = datetime.datetime.fromtimestamp(programs[0]["start"]).strftime('%H:%M')
		end_time = datetime.datetime.fromtimestamp(programs[0]["end"]).strftime('%H:%M')
		programName = "[COLOR {0}][B]{1}[/B][/COLOR] [COLOR {2}][{3}-{4}][/COLOR]".format(Addon.getSetting("prColor"), programs[0]["name"].encode('utf-8'), Addon.getSetting("timesColor"), start_time, end_time)
		displayName = "{0} - {1}".format(displayName, programName)
		description = '{0}[CR]{1}'.format(programName, programs[0]["description"].encode('utf-8'))
		if len(programs) > 1:
			description = '{0}[CR][CR]Next: [COLOR {1}][B]{2}[/B][/COLOR] [COLOR {3}][{4}-{5}][/COLOR]'.format(description, Addon.getSetting("prColor"), programs[1]["name"].encode('utf-8'), Addon.getSetting("timesColor"), datetime.datetime.fromtimestamp(programs[1]["start"]).strftime('%H:%M'), datetime.datetime.fromtimestamp(programs[1]["end"]).strftime('%H:%M'))
	if contextMenu == []:
		contextMenu = None
	common.addDir(displayName, url, mode, iconimage, infos={"Title": displayName, "Plot": description}, contextMenu=contextMenu, moreData='best', module=module, isFolder=False, isPlayable=True)

if module is None:
	if mode == -1:
		GetCategoriesList()
	elif mode == 1:
		LiveChannels()
	elif mode == 2:
		xbmc.executebuiltin("Container.Refresh()")
else:
	try:
		moduleScript = __import__('resources.lib.{0}'.format(module), fromlist=[module])
		moduleScript.Run(name, url, mode, iconimage, moreData)
	except Exception as ex:
		xbmc.log(str(ex), 3)

xbmcplugin.endOfDirectory(handle)