﻿# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import os, time, datetime, tarfile
import resources.lib.common as common

AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'epg'
profileDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(profileDir):
	os.makedirs(profileDir)
epgFile = os.path.join(profileDir, 'epg.json')
xmlFile = os.path.join(profileDir, 'epg.xml')
epgURL = 'http://bit.ly/epgzip'

now = int(time.time())

def GetDisplayName(programTime, programName, channelNameFormat):
	if channelNameFormat == 0 or channelNameFormat == 1:
		displayName = ' {0} {1} '.format(programTime, programName)  
	elif channelNameFormat == 2 or channelNameFormat == 3:
		displayName = ' {0} {1} '.format(programName, programTime)
	return displayName
	
def ShowChannelEPG(channel, name='', iconimage='', provider='auto', days=2):
	common.addDir('------- {0} -------'.format(common.GetLabelColor(name, keyColor="chColor", bold=True)), name, 99, iconimage, isFolder=False)
	day = ""
	epg = GetEPG()
	programs = epg[channel]
	channelNameFormat = int(Addon.getSetting("channelNameFormat"))
	for program in programs:
		if now >= program['end']:
			continue
		startdate = datetime.datetime.fromtimestamp(program["start"]).strftime('%d/%m/%y')
		if startdate != day:
			day = startdate
			dayS = common.GetLabelColor(day, keyColor="nprColor", bold=True)
			common.addDir(dayS, 'epg', 99, iconimage, {"Title": dayS}, module=module, isFolder=False)
		start_time = datetime.datetime.fromtimestamp(program["start"]).strftime('%H:%M')
		end_time = datetime.datetime.fromtimestamp(program["end"]).strftime('%H:%M')
		programName = GetDisplayName(common.GetLabelColor('[{0}-{1}]'.format(start_time, end_time), keyColor="timesColor"), common.GetLabelColor(program["name"].strip().encode('utf-8'), keyColor="prColor", bold=True), channelNameFormat)
		description = program["description"].strip().encode('utf-8')
		common.addDir(programName, 'epg', 99, iconimage, {"Title": programName, "Plot": description}, module=module, isFolder=False)

def GetNowEPG():
	epg = GetEPG()
	for channel in list(epg.keys()):
		programs = []
		programsCount = len(epg[channel])
		for i in range(programsCount):
			start = epg[channel][i]["start"]
			end = epg[channel][i]["end"]
			if now >= end:
				continue
			if i+1 < programsCount: 
				programs = epg[channel][i:i+2]
				break
			else:
				programs = epg[channel][i:i+1]
				break
		epg[channel] = programs
	return epg

def GetEPG(deltaInSec=86400):
	if common.isFileOld(epgFile, deltaInSec=deltaInSec):
		try:
			data = common.OpenURL(epgURL)
			zFile = os.path.join(profileDir, 'epg.zip')
			with open(zFile, 'wb') as f:
				f.write(data)
			xbmc.executebuiltin("XBMC.Extract({0}, {1})".format(zFile, profileDir), True)
			try:
				os.remove(zFile)
			except:
				pass
			MakeChannelsGuide()
		except Exception as ex:
			xbmc.log("{0}".format(ex), 3)
	return common.ReadList(epgFile)

def GetTZtime(timestamp):
	timeStr = ""
	ts = time.time()
	delta = (datetime.datetime.fromtimestamp(ts) - datetime.datetime.utcfromtimestamp(ts))
	hrs = "+0000"
	if delta > datetime.timedelta(0):
		hrs = "+{0:02d}{1:02d}".format(delta.seconds//3600, (delta.seconds//60)%60)
	else:
		delta = -delta
		hrs = "-{0:02d}{1:02d}".format(delta.seconds//3600, (delta.seconds//60)%60)
	timeStr = "{0} {1}".format(time.strftime('%Y%m%d%H%M%S', time.localtime(timestamp)), hrs)
	return timeStr

def MakeChannelsGuide():
	if Addon.getSetting("useIPTV") != 'true':
		return
	channelsList = ""
	programmeList = ""
	epgList = common.ReadList(epgFile)
	for key,val in epgList.items():
		chName = key.encode("utf-8")
		channelsList += "\t<channel id=\"{0}\">\n\t\t<display-name>{1}</display-name>\n\t</channel>\n".format(common.EscapeXML(chName), chName)
		for programme in val:
			start = GetTZtime(programme["start"])
			end = GetTZtime(programme["end"])
			name = common.EscapeXML(programme["name"].encode("utf-8")) if programme["name"] != None else ""
			description = common.EscapeXML(programme["description"].encode("utf-8")) if programme["description"] != None else ""
			programmeList += "\t<programme start=\"{0}\" stop=\"{1}\" channel=\"{2}\">\n\t\t<title>{3}</title>\n\t\t<desc>{4}</desc>\n\t</programme>\n".format(start, end, common.EscapeXML(chName), name, description)
	xmlList = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<tv>\n{0}{1}</tv>".format(channelsList, programmeList)
	with open(xmlFile, 'w') as f:
		f.write(xmlList)
	with tarfile.open('{0}.tar.gz'.format(xmlFile), "w:gz") as tar:
		tar.add(xmlFile)
	try:
		os.remove(xmlFile)
	except:
		pass

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 2:
		days = 2
		provider = 'auto'
		if moreData != '':
			params = moreData.split(';')
			for param in params:
				prm = param.split('=')
				if prm[0] == 'provider':
					provider = prm[1]
				elif prm[0] == 'days':
					days = prm[1]
		ShowChannelEPG(url, name, iconimage, provider, days)
	common.SetViewMode('episodes')