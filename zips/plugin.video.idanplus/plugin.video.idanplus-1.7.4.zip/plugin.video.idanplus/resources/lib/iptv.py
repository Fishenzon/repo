﻿# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import os, sys
import resources.lib.common as common

AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'iptv'
imagesDir = 'special://home/addons/{0}/resources/images/'.format(AddonID)
profileDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
m3uFile = os.path.join(profileDir, 'idanplus.m3u')

def MakeIPTVlist(channels):
	if Addon.getSetting("useIPTV") != 'true':
		return
	iptvList = '#EXTM3U\n'
	for item in channels:
		try:
			tvg_id = item["tvgID"]
			view_name = common.GetLocaleString(item['nameID'])
			tvg_logo = '{0}{1}'.format(imagesDir, item['image'])
			type = item.get('type', '')
			if type == 'radio':
				radio = ' radio="true"'
				group = ' group-title="Radio"'
			elif type == '': 
				radio = ''
				group = ' group-title="TV"'
			resKey = item.get('resKey', '')
			if resKey == '':
				bitrate = 'best'
			else:
				bitrate = Addon.getSetting(resKey)
				if bitrate == '':
					bitrate = 'best'
			url = '{0}?url={1}&mode={2}&module={3}&moredata={4}'.format(sys.argv[0], item['channelID'], item['mode'], item['module'], bitrate)
			iptvList += '\n#EXTINF:-1 tvg-id="{0}"{1} tvg-logo="{2}"{3},{4}\n{5}\n'.format(tvg_id, group, tvg_logo, radio, view_name, url)
		except Exception as ex:
			xbmc.log("{0}".format(ex), 3)
	with open(m3uFile, 'w') as f:
		f.write(iptvList)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 1:
		MakeIPTVlist(moreData)
	common.SetViewMode('episodes')