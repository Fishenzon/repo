# -*- coding: utf-8 -*-
import sys, os, urlparse, urllib
import xbmc, xbmcplugin, xbmcaddon
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
imagesDir = xbmc.translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources', 'images')).decode("utf-8")

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
url = urllib.unquote_plus(params.get('url', ''))
mode = int(params.get('mode','-1'))
name = urllib.unquote_plus(params.get('name', ''))
iconimage = urllib.unquote_plus(params.get('iconimage', ''))
module = params.get('module')
moreData = urllib.unquote_plus(params.get('moredata', ''))

def GetCategoriesList():
	name = '[B]שידורים חיים[/B]'
	common.addDir(name, '', 1, icon, {"Title": name})
	name = 'מאקו VOD'
	common.addDir(name, '', 0, os.path.join(imagesDir, "mako.png"), infos={"Title": name}, module='keshet')
	name = 'רשת VOD'
	common.addDir(name, '', 0, os.path.join(imagesDir, "reshet.png"), infos={"Title": name}, module='reshet')
	name = 'עשר VOD'
	common.addDir(name, '', 0, os.path.join(imagesDir, "ten.png"), infos={"Title": name}, module='ten')

def LiveChannels():
	name = 'כאן 11'
	url = 'http://www.kan.org.il/live/tv.aspx?stationId=2'
	iconimage = os.path.join(imagesDir, "11.png")
	common.addDir(name, url, 10, iconimage, infos={"Title": name}, contextMenu=[(common.GetLocaleString(30005), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=10&iconimage={3}&moredata=choose&module=kan)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name), urllib.quote_plus(iconimage)))], moreData='best', module='kan', isFolder=False, isPlayable=True)
	name = 'קשת 12'
	url = 'http://www.mako.co.il/mako-vod-live-tv/VOD-6540b8dcb64fd31006.htm'
	iconimage = 'http://img.mako.co.il/2017/11/01/i_12_c.jpg'
	common.addDir(name, url, 5, iconimage, infos={"Title": name}, contextMenu=[(common.GetLocaleString(30005), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=5&iconimage={3}&moredata=choose&module=keshet)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name), urllib.quote_plus(iconimage)))], moreData='best', module='keshet', isFolder=False, isPlayable=True)
	name = 'רשת 13'
	iconimage = os.path.join(imagesDir, "reshet.png")
	common.addDir(name, '', 4, iconimage, infos={"Title": name}, contextMenu=[(common.GetLocaleString(30005), 'XBMC.RunPlugin({0}?name={1}&mode=4&iconimage={2}&moredata=choose&module=reshet)'.format(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(iconimage)))], moreData='best', module='reshet', isFolder=False, isPlayable=True)
	name = 'עשר 14'
	iconimage = os.path.join(imagesDir, "ten.png")
	common.addDir(name, '', 6, iconimage, infos={"Title": name}, contextMenu=[(common.GetLocaleString(30005), 'XBMC.RunPlugin({0}?name={1}&mode=6&iconimage={2}&moredata=choose&module=ten)'.format(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(iconimage)))], moreData='best', module='ten', isFolder=False, isPlayable=True)
	name = 'מורשת 20'
	iconimage = os.path.join(imagesDir, "20.png")
	common.addDir(name, '', 10, iconimage, infos={"Title": name}, contextMenu=[(common.GetLocaleString(30005), 'XBMC.RunPlugin({0}?name={1}&mode=10&iconimage={2}&moredata=choose&module=twenty)'.format(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(iconimage)))], moreData='best', module='twenty', isFolder=False, isPlayable=True)
	name = 'מוזיקה 24'
	url = 'http://www.mako.co.il/mako-vod-live-tv/VOD-b3480d2eff3fd31006.htm'
	iconimage = 'http://img.mako.co.il/2016/07/11/eyal_c.jpg'
	common.addDir(name, url, 5, iconimage, infos={"Title": name}, contextMenu=[(common.GetLocaleString(30005), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=5&iconimage={3}&moredata=choose&module=keshet)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name), urllib.quote_plus(iconimage)))], moreData='best', module='keshet', isFolder=False, isPlayable=True)
	name = 'מכאן 33'
	url = 'http://www.kan.org.il/live/tv.aspx?stationId=14'
	iconimage = os.path.join(imagesDir, "33.png")
	common.addDir(name, url, 10, iconimage, infos={"Title": name}, contextMenu=[(common.GetLocaleString(30005), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=10&iconimage={3}&moredata=choose&module=kan)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name), urllib.quote_plus(iconimage)))], moreData='best', module='kan', isFolder=False, isPlayable=True)
	name = 'כנסת 99'
	iconimage = os.path.join(imagesDir, "knesset.png")
	common.addDir(name, '', 10, iconimage, infos={"Title": name}, contextMenu=[(common.GetLocaleString(30005), 'XBMC.RunPlugin({0}?name={1}&mode=10&iconimage={2}&moredata=choose&module=knesset)'.format(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(iconimage)))], moreData='best', module='knesset', isFolder=False, isPlayable=True)
	name = 'קשת המיטב'
	url = 'http://www.mako.co.il/mako-vod-live-tv/VOD-49a6215abae1b51006.htm'
	iconimage = 'http://img.mako.co.il/2017/03/30/meitav_i_c.jpg'
	common.addDir(name, url, 5, iconimage, infos={"Title": name}, contextMenu=[(common.GetLocaleString(30005), 'XBMC.RunPlugin({0}?url={1}&name={2}&mode=5&iconimage={3}&moredata=choose&module=keshet)'.format(sys.argv[0], urllib.quote_plus(url), urllib.quote_plus(name), urllib.quote_plus(iconimage)))], moreData='best', module='keshet', isFolder=False, isPlayable=True)
	
if module is None:
	if mode == -1:
		GetCategoriesList()
	elif mode == 1:
		LiveChannels()
else:
	moduleScript = __import__('resources.lib.{0}'.format(module), fromlist=[module])
	moduleScript.Run(name, url, mode, iconimage, moreData)

xbmcplugin.endOfDirectory(handle)