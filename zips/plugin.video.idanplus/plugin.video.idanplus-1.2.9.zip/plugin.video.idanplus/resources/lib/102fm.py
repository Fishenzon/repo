﻿# -*- coding: utf-8 -*-
import xbmcaddon
import sys, re
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = '102fm'
userAgent = common.GetUserAgent()

def WatchLive(name='', iconimage='', quality='best'):
	headers={"User-Agent": userAgent}
	text = common.OpenURL('http://102fm.co.il/scripts/scripts.min.js', headers=headers)
	link = re.compile("radioPlayerStream.+'(.+)'").findall(text)[0]
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 11:
		WatchLive(name, iconimage, moreData)
		
	common.SetViewMode('episodes')