﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import sys, re, json, urllib, urllib2, urlparse
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = '9tv'
baseUrl = 'http://9tv.co.il'
userAgent = common.GetUserAgent()
headers = {"User-Agent": userAgent}

def GetCategoriesList(iconimage):
	text = common.OpenURL(baseUrl)
	matches = re.compile('<nav id="tv-nav">(.*?)</nav>', re.S).findall(text)
	categories = re.compile('default;">(.*?)</a>').findall(matches[0])
	for category in categories:
		name = common.GetLabelColor(category, bold=True, color="none")
		common.addDir(name, category, 0, iconimage, infos={"Title": name, "Plot": name}, module=module)

def GetSeriesList(iconimage, category):
	text = common.OpenURL(baseUrl)
	matches = re.compile('<nav id="tv-nav">(.*?)</nav>', re.S).findall(text)
	matches = re.compile('{0}(.*?)</ul>'.format(category), re.S).findall(matches[0])
	series = re.compile('href="(.*?)">(.*?)</a>').findall(matches[0])
	for link, name in series:
		name = common.GetLabelColor(name, keyColor="prColor", bold=True)
		common.addDir(name, '{0}{1}'.format(baseUrl, link), 1, iconimage, infos={"Title": name, "Plot": name}, module=module)

def GetEpisodesList(url, image, progName=''):
	text = common.OpenURL(url)
	matches = re.compile('class=articlesList>(.*?)class="paging">(.*?)</div>', re.S).findall(text)
	i = url.find('?p=')
	if i > 0:
		page = int(url[i+3:])
		_url = url[:i+3]
	else:
		page = 1
		_url = '{0}?p='.format(url)
	match = re.compile("<a href='\?p=(.*?)'>.*?</a>").findall(matches[0][1])
	pages = 1 if len(match) < 1 else int(match[-1])
	episodes = re.compile('href="(.*?)".*?<img src=\'(.*?)\'.*?class="date-comments">(.*?)<a', re.S).findall(matches[0][0])
	for link, iconimage, name in episodes:
		name = common.GetLabelColor(common.UnEscapeXML(name), keyColor="chColor")
		common.addDir(name, link, 2, iconimage, infos={"Title": name, "Plot": progName}, module=module, isFolder=False, isPlayable=True)
	if page > 1:
		name = common.GetLabelColor(common.GetLocaleString(30011), color="green")
		common.addDir(name, '{0}{1}'.format(_url, page-1), 1, image, infos={"Title": name, "Plot": name}, module=module)
	if pages > page:
		name = common.GetLabelColor(common.GetLocaleString(30012), color="green")
		common.addDir(name, '{0}{1}'.format(_url, page+1), 1, image, infos={"Title": name, "Plot": name}, module=module)
	if pages > 1:
		name = common.GetLabelColor(common.GetLocaleString(30013), color="green")
		common.addDir(name, '{0}{1}&pages={2}'.format(_url, page, pages), 3, image, infos={"Title": name, "Plot": name}, module=module)

def Play(name, url, iconimage, quality='best'):
	text = common.OpenURL(url, headers=headers)
	match = re.compile("src:\s*'(.*?)'").findall(text)
	if match == []:
		match = re.compile('type="video/mp4"\s*src="(.*?)"').findall(text)
	if match == []:
		match = re.compile('file:\s*"(.*?)"').findall(text)
	final = '{0}|User-Agent={1}'.format(match[0], userAgent)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == -1:
		GetCategoriesList(iconimage)
	elif mode == 0:		#------------- Series: ---------------
		GetSeriesList(iconimage, url)
	elif mode == 1:		#------------- Episodes: -----------------
		GetEpisodesList(url, iconimage, name)
	elif mode == 2:		#------------- Playing episode  ----------
		Play(name, url, iconimage, moreData)
	elif mode == 3:		#--- Move to a specific episodes' page  --
		urlp = urlparse.urlparse(url)
		prms = urlparse.parse_qs(urlp.query)
		page = common.GetIndexFromUser(name, int(prms['pages'][0]))
		if page == 0:
			page = int(prms['p'][0])
		url = '{0}{1}?p={2}'.format(baseUrl, urlp.path, page)
		GetEpisodesList(url, iconimage)
		
	common.SetViewMode('episodes')
