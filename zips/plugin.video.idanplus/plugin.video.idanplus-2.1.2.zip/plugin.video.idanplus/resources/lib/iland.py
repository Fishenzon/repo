﻿# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import sys, re
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'iland'
userAgent = common.GetUserAgent()

def WatchLive(url, name='', iconimage='', quality='best'):
	headers={"User-Agent": userAgent}
	channels = {
		'iland': {'ch': 'https://www.iland.tv/', 'link': 'https://content.jwplatform.com/videos/IeBr7zQ6-640.mp4'}
	}
	link = channels[url]['link']
	text = common.OpenURL(channels[url]['ch'], headers=headers)
	if text is not None:
		match = re.compile('class="embed-responsive-item".*?src="(.*?)"').findall(text)
		if match[0] != '':
			referer = 'https:{0}'.format(match[0])
			text = common.OpenURL(referer, headers=headers)
			match = re.compile('player:stream".*?content="(.*?)"').findall(text)
			headers['Referer'] = referer
			link = common.GetRedirect(match[0], headers=headers)
	link = common.GetStreams(link, headers=headers, quality=quality)
	final = '{0}|User-Agent={1}&Referer={2}'.format(link, userAgent, referer)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 10:
		WatchLive(url, name, iconimage, moreData)
		
	common.SetViewMode('episodes')