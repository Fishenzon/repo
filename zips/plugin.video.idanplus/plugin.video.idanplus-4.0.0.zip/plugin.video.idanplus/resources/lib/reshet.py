# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcplugin
import sys, re, json, collections, time
import resources.lib.common as common
from resources.lib import cache as  cache

Addon = xbmcaddon.Addon(common.AddonID)
module = 'reshet'

baseUrl = 'https://13tv.co.il'
seriesUrl = 'https://13tv.co.il/_next/data/{0}/he/allshows/series/{1}.json?all=series&all={1}'
seasonsUrl = 'https://13tv.co.il/_next/data/{0}/he/allshows/series/{1}/season/{2}.json?all=series&all={1}&all=season&all={2}'
# 13tv WAF blocks browser Chrome UAs on HTML/API (HTTP 403). curl-like UA + Referer works.
pageHeaders = {
	"User-Agent": "curl/8.7.1",
	"Referer": "{0}/allshows/".format(baseUrl),
	"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
	"Accept-Language": "he-IL,he;q=0.9",
	"Accept-Encoding": "gzip, deflate",
}
# Client playback (Kaltura/Brightcove) still prefers a normal browser UA.
userAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
brvApi = 'https://edge.api.brightcove.com/playback/v1/accounts/1551111274001/videos/'
brvPk = 'application/json;pk=BCpkADawqM30eqkItS5d08jYUtMkbTKu99oEBllbfUaFKeknXu4iYsh75cRm2huJ_b1-pXEPuvItI-733TqJN1zENi-DcHlt7b4Dv6gCT8T3BS-ampD0XMnORQLoLvjvxD14AseHxvk0esW3'
cstApi = 'https://13tv-api.oplayer.io/api/getlink'
cstUserId = '45E4A9FB-FCE8-88BF-93CC-3650C39DDF28'
moduleIcon = common.GetIconFullPath("13.jpg")

def GetCategoriesList(iconimage):
	name = "{0}: {1}".format(common.GetLocaleString(30001), common.GetLocaleString(30002) if sortBy == 0 else common.GetLocaleString(30003))
	common.addDir(name, "toggleSortingMethod", 5, iconimage, {"title": name, "plot": "{0}[CR]{1}[CR]{2} / {3}".format(name, common.GetLocaleString(30004), common.GetLocaleString(30002), common.GetLocaleString(30003))}, module=module, isFolder=False)
	name = common.GetLabelColor("כל התכניות", bold=True, color="none")
	common.addDir(name, '{0}/allshows/screen/1170108/'.format(baseUrl), 0, iconimage, infos={"title": name, "plot": "צפיה בתכניות רשת 13"}, module=module)
	name = common.GetLabelColor("חדשות 13", bold=True, color="none")
	common.addDir(name, '', 10, iconimage, infos={"title": name, "plot": "צפיה בתכניות חדשות 13"}, module=module)
	name = common.GetLabelColor("ארכיון רשת 13", bold=True, color="none")
	common.addDir(name, '{0}/general/programs/'.format(baseUrl), 20, iconimage, infos={"title": name, "plot": "צפיה בתכניות מארכיון רשת 13"}, module=module)

def GetUrlJson(url, root=False):
	result = {}
	try:
		html = common.OpenURL(url, headers=pageHeaders)
		props = re.compile('"application/json">(.*?)</script>').findall(html)
		if len(props) == 0:
			return {}
		result = json.loads(props[0])
		if root == False:
			result = result['props']['pageProps']['page']
	except Exception as ex:
		xbmc.log(str(ex), xbmc.LOGERROR)
	return result

def GetSeriesListOld(url, iconimage):
	#result = GetUrlJson(url)
	result = cache.get(GetUrlJson, 24, url, table='pages')
	if result==[]:
		result = cache.get(GetUrlJson,0, url, table='pages')
	if len(result) < 1:
		return
	grids_arr = []
	seriesIDs = []
	series = {}
	grids = result.get('Content', {}).get('PageGrid', {})
	for grid in grids:
		for serie in grid.get('posts', {}):
			try:
				seriesID = serie.get('id')
				if seriesID in seriesIDs or seriesID == 170768:
					continue
				link = serie.get('link')
				'''
				postType = serie.get('postType', '')
				if postType == 'item':
					if '/movies/' in link:
						link = link[:link.find('/movies/') + 8].replace('/item', '')
					else:
						link = link[:link.find('/season') + 1].replace('/item', '')
					name = common.encode(serie['title'], 'utf-8')
					name = name[:name.find(',')]
				elif postType != 'page':
					continue
				else:
					if len(common.url_parse(link).path.split('/')) > 4 and 'channel2-news' not in link:
						continue
				'''
				video = serie.get('video')
				if video is not None:
					continue
					if '/movies/' in link:
						link = link[:link.find('/movies/') + 8].replace('/item', '')
					else:
						link = link[:link.find('/season') + 1].replace('/item', '')
				name = common.encode(serie['title'], 'utf-8')
				name = common.GetLabelColor(name, keyColor="prColor", bold=True)
				if link == '' or '/all-shows-' in link or link in series:
					continue
				series[link] = name
				seriesIDs.append(seriesID)
				image = serie['imageObj']['d']
				pageTitle = serie.get('secondaryTitle', {})
				description = '' if pageTitle is None else common.encode(pageTitle, 'utf-8')
				matches = [grids_arr.index(x) for x in grids_arr if link == x[1]]
				if len(matches) == 1:
					grids_arr[matches[0]] = (name, link, image, {"title": name, "plot": description,'mediatype': 'movie'})
				else:
					grids_arr.append((name, link, image, {"title": name, "plot": description,'mediatype': 'movie'}))
			except Exception as ex:
				xbmc.log('SerieID: {0}\n{1}'.format(seriesID, str(ex)), xbmc.LOGERROR)
	mainMenus = result.get('Header', {}).get('mainMenu', [])
	for mainMenu in mainMenus:
		if mainMenu['url'] == '/vod/':
			grids = mainMenu['children']
			for grid in grids:
				name = common.GetLabelColor(common.UnEscapeXML(common.encode(grid['title'], 'utf-8')), keyColor="prColor", bold=True)
				link = grid['url']
				if link == '' or link in series or link == '/vod/' or link == '/general/programs/signup-auditions/':
					continue
				series[link] = name
				grids_arr.append((name, link, iconimage, {"title": name}))
	grids_sorted = grids_arr if sortBy == 0 else sorted(grids_arr,key=lambda grids_arr: grids_arr[0])
	for name, link, icon, infos in grids_sorted:
		common.addDir(name, '{0}{1}'.format(baseUrl, link), 21, str(icon), infos=infos, module=module)

def GetSeasonListOld(url, iconimage):
	#result = GetUrlJson(url)
	result = cache.get(GetUrlJson, 24, url, table='pages')
	seasons, episodes = GetLinks(url, result, iconimage)
	if len(seasons) > 0:
		for link, title in common.items(seasons):
			name = common.GetLabelColor(title, keyColor="timesColor", bold=True)
			common.addDir(name, link, 21, iconimage, infos={"title": name}, module=module)
		if len(episodes) < 1:
			return
	ShowEpisodes(episodes, iconimage)
	ShowPaging(result, iconimage)

def GetEpisodesListOld(url, iconimage):
	#result = GetUrlJson(url)
	result = cache.get(GetUrlJson, 24, url, table='pages')
	if result==[]:
		result = cache.get(GetUrlJson, 0, url, table='pages')
	seasons, episodes = GetLinks(url, result, iconimage)
	ShowEpisodes(episodes, iconimage)
	ShowPaging(result, iconimage)

def IsLinkNotExist(url, link, seasons):
	if url[-1] == '/':
		url = url[:len(url)-1]
	if link[-1] == '/':
		link1 = link[:len(link)-1]
	return url != link and url != link1 and url in link and link.replace('episodes/', '') not in seasons and (link not in seasons or seasons[link] == '')

def GetTitleAndLink(element, t, l):
	title = '' if element is None else common.encode(element.get(t, '').strip(), 'utf-8')
	link = '' if element is None else element.get(l, '')
	link = '' if link is None else common.encode(str(link).strip(), 'utf-8')
	if len(link) > 0:
		if link[-1] != '/':
			link += '/'
		link = '{0}{1}'.format(baseUrl, link)
	return title, link

def GetSeasons(url, pageTitle, seasons, gridTitle, gridLink):
	if len(gridLink) > 0 and gridLink[-1] != '/':
		gridLink += '/'
	ending = gridLink[gridLink.rfind('/', 0, len(gridLink)-1):]
	if ('episodes' in ending or 'season' in ending) and IsLinkNotExist(url, gridLink, seasons):
	#if 'episodes' in gridLink and IsLinkNotExist(url, gridLink, seasons):
		#gridLink = GetLink(gridLink)
		seasons[gridLink] = gridTitle if gridTitle != '' else pageTitle
	elif gridLink != '' and gridTitle != '' and IsLinkNotExist(url, gridLink, seasons):
		gridLink = gridLink.replace('/episodes/', '')
		seasons[gridLink] = gridTitle
	return seasons

def GetEpisodes(posts, episodes, gridTitle, iconimage):
	for post in posts:
		try:
			video = post.get('video')
			if video is None:
				continue
			videoID = ''
			if video.get('kalturaId') is not None:
				videoID = '{0}--kaltura--{1}==='.format(videoID, video['kalturaId'])
			if video.get('cst_videoID') is not None:
				if video['cst_videoID'] == '-1':
					videoID = '{0}--cst--{1}==='.format(videoID, video['cst_videoID'])
				else:
					videoID = '{0}--cst--{1}==='.format(videoID, video.get('videoRef', videoID))
			if video.get('brv_videoID') is not None:
				videoID = '{0}--brv--{1}==='.format(videoID, video['brv_videoID'])	
			if videoID == '':
				continue
			icon = video.get('poster', iconimage)
			title = post.get('title')
			if title == None:
				title = ''
			secondaryTitle = post.get('secondaryTitle')
			if secondaryTitle == None:
				secondaryTitle = ''
			episodes.append((gridTitle, videoID, icon, common.encode(title.strip(), 'utf-8'), common.encode(secondaryTitle.strip(), 'utf-8'), post.get('publishDate')))
		except Exception as ex:
			xbmc.log(str(ex), xbmc.LOGERROR)
	return episodes

def GetLinks(url, result, iconimage):
	seasons = collections.OrderedDict() if common.NewerThanPyVer('2.6.99') else {}
	episodes = []
	subMenus = result.get('Header', {}).get('subMenu', {})
	if subMenus:
		for subMenu in subMenus:
			try:
				title = subMenu.get('title')
				link = subMenu.get('link')
				if len(link) > 0 and link[-1] != '/':
					link += '/'
				ending = link[link.rfind('/', 0, len(link)-1):]
				link = '{0}{1}'.format(baseUrl, link)
				if ('episodes' in ending or 'season' in ending) and IsLinkNotExist(url, link, seasons):
				#if IsLinkNotExist(url, link, seasons):
					#link = GetLink(link)
					seasons[link] = common.encode(title.strip(), 'utf-8')
			except Exception as ex:
				xbmc.log(str(ex), xbmc.LOGERROR)
	pageTitle = common.encode(result.get('PageMeta', {}).get('title', '').strip(), 'utf-8')
	for grid in result.get('Content', {}).get('PageGrid', {}):
		if grid["grid_type"] == "seven_with_banner_or_iframe":
			continue
		gridTitle, gridLink = GetTitleAndLink(grid.get('grid_title'), 'text', 'link')
		posts = grid.get('posts', [])
		if posts != []:
			#title, link = GetTitleAndLink(grid.get('grid_title'), 'text', 'link')
			#seasons = GetSeasons(url, pageTitle, seasons, title, link)
			#episodes = GetEpisodes(posts, episodes, title, iconimage)
			if gridLink != '':
				seasons = GetSeasons(url, pageTitle, seasons, gridTitle, gridLink)
			else:
				for post in posts:
					title, link = GetTitleAndLink(post, 'title', 'link')
					seasons = GetSeasons(url, pageTitle, seasons, title, link)
			episodes = GetEpisodes(posts, episodes, gridTitle, iconimage)
		else:
			elements = grid.get('matrix_elements', {})
			if elements != {}:
				for element in elements:
					title, link = GetTitleAndLink(element.get('matrix_title'), 'text', 'link')
					if link != '':
						seasons = GetSeasons(url, pageTitle, seasons, title, link)
					else:
						posts = element.get('posts', [])
						for post in posts:
							title, link = GetTitleAndLink(post, 'title', 'link')
							seasons = GetSeasons(url, pageTitle, seasons, title, link)
							episodes = GetEpisodes(posts, episodes, title, iconimage)
			else:
				gridLink = grid.get('link')
				if gridLink is not None and 'episodes' in gridLink and IsLinkNotExist(url, gridLink, seasons):
					seasons[gridLink] = common.encode(grid.get('imageObj', {}).get('alt_d', '').strip(), 'utf-8')
	return seasons, episodes

def ShowEpisodes(episodes, iconimage):
	if len(episodes) < 1:
		name = 'אין פרקים מלאים'
		common.addDir(name, '', 99, iconimage, infos={"title": name}, module=module, isFolder=False)
		return
	for gridTitle, link, icon, title, subtitle, publishDate in episodes:
		name = common.GetLabelColor(title, keyColor="chColor") if gridTitle is None or gridTitle == '' else common.getDisplayName(gridTitle, title, programNameFormat)
		link = str(link)
		common.addDir(name, link, 3, icon, infos={"title": name, "plot": subtitle, "aired": publishDate}, contextMenu=[(common.GetLocaleString(30005), 'RunPlugin({0}?url={1}&name={2}&mode=3&iconimage={3}&moredata=choose&module=reshet)'.format(sys.argv[0], common.quote_plus(link), common.quote_plus(name), common.quote_plus(icon))), (common.GetLocaleString(30023), 'RunPlugin({0}?url={1}&name={2}&mode=3&iconimage={3}&moredata=set_reshet_res&module=reshet)'.format(sys.argv[0], common.quote_plus(link), common.quote_plus(name), common.quote_plus(icon)))], moreData=bitrate, module=module, isFolder=False, isPlayable=True)

def ShowPaging(result, iconimage):
	grids = result.get('Content', {}).get('PageGrid', {})
	if len(grids) < 1:
		return
	paginationGrid = grids[-1]
	grid_type = paginationGrid.get('grid_type')
	if grid_type is None or grid_type != 'PaginationArray':
		return  
	else: 
		current_page = paginationGrid.get('current_page', 1)
	#if current_page > 0:
	page_url = '{0}{1}'.format(baseUrl, paginationGrid.get('base'))
	page_url = page_url[:page_url.find('%')]
	max_page = paginationGrid.get('max_page', 1)
	if current_page > 1:
		#prev_page = page_url + str(current_page-1) + '/' if current_page - 1 > 1 else page_url
		common.addDir(common.GetLabelColor(common.GetLocaleString(30011), color="green"), page_url + str(current_page-1) + '/', 22, iconimage, module=module)
	if max_page > current_page:
		common.addDir(common.GetLabelColor(common.GetLocaleString(30012), color="green"), page_url + str(current_page+1) + '/', 22, iconimage, module=module)
	if max_page > 2:
		name = common.GetLabelColor(common.GetLocaleString(30013), color="green")
		common.addDir(name, '{0}?p={1}&pages={2}'.format(page_url, current_page, max_page), 7, iconimage, infos={"title": name, "plot": name}, module=module)

def Play(video, name='', iconimage='', quality='best'):
	try:
		videos = video.split('===')
		kaltura = ''
		cst = ''
		brv = ''
		for vid in videos:
			if '--kaltura--' in vid:
				kaltura = vid.replace('--kaltura--', '')
			elif '--cst--' in vid:
				cst = vid.replace('--cst--', '')
			elif '--brv--' in vid:
				brv = vid.replace('--brv--', '')
		if kaltura != '':
			link = common.GetKaltura(kaltura, 2748741, baseUrl, userAgent, quality=quality)
		elif cst != '':
			headers={"User-Agent": userAgent}
			if common.isnumeric(cst):
				result = common.OpenURL('{0}/getVideoById?userId={1}&serverType=web&videoId={2}&callback=x'.format(cstApi, cstUserId, cst), headers=headers)
			else:
				result = common.OpenURL('{0}/getlink/getVideoByFileName?userId={1}&videoName={2}&serverType=web&callback=x'.format(cstApi, cstUserId, cst), headers=headers)
			if result is not None:
				source = json.loads(result)[0]
				link = '{0}{1}{2}{3}{4}.mp4{5}{6}'.format(source['ProtocolType'], source['ServerAddress'], source['MediaRoot'], source['MediaFile'][:source['MediaFile'].find('.mp4')], source['Bitrates'], source['StreamingType'], source['Token'])
				session = common.GetSession()
				link = common.GetStreams(link, headers=headers, session=session, quality=quality)
				final = '{0}|User-Agent={1}'.format(link, userAgent)
				cookies = "&".join(['Cookie={0}'.format(common.quote('{0}={1}'.format(_cookie.name, _cookie.value))) for _cookie in session.cookies])
				if cookies != '':
					final = '{0}&{1}'.format(final, cookies)
			else:
				result = common.OpenURL('{0}{1}'.format(brvApi, brv), headers={"Accept": brvPk, "User-Agent": userAgent})
				if result is None:
					link = 'https://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId={0}'.format(brv)
					link = common.GetStreams(link, headers=headers, quality=quality)
				else:
					sources = json.loads(result)['sources']
					link = ''
					avg_bitrate = 0
					for source in sources:
						if 'src' in source:
							if source['container'] == 'M2TS':
								link = common.GetStreams(source['src'], headers=headers, quality=quality)
								break
							if source['avg_bitrate'] > avg_bitrate:
								link = source['src']
								avg_bitrate = source['avg_bitrate']
				final = '{0}|User-Agent={1}'.format(link, userAgent)
		
		final = '{0}|User-Agent={1}'.format(link, userAgent)
		common.PlayStream(final, quality, name, iconimage)
	except Exception as ex:
		xbmc.log(str(ex), xbmc.LOGERROR)

def WatchLive(channelID, name='', iconimage='', quality='best'):
	channel = common.GetChannel(channelID)
	isAdaptive = common.GetChannelAdaptive(channel)
	linkDetails = channel.get('linkDetails')
	referer = linkDetails.get('referer')
	try:
		headers={"User-Agent": userAgent}
		if referer:
			headers['referer'] = referer
		link = common.GetStreams(linkDetails['link'], headers=headers, quality=quality)
	except Exception as ex:
		xbmc.log(str(ex), xbmc.LOGERROR)
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	if referer:
		final = '{0}&Referer={1}'.format(final, referer)
	common.PlayStream(final, quality, name, iconimage, adaptive=isAdaptive)

def GetNewsCategoriesList(iconimage):
	url = '{0}/news/13-programs/'.format(baseUrl)
	result = GetUrlJson(url)
	if len(result) < 1:
		return
	grids_arr = []
	grids = result.get('Content', {}).get('PageGrid', {})
	for grid in grids:
		gridType = grid.get('grid_type')
		if gridType is None or gridType == 'SpecialRef' or gridType == 'six_with_banners_or_poster':
			continue
		gridTitle = grid.get('grid_title')
		title = '' if gridTitle is None else common.GetLabelColor(common.UnEscapeXML(common.encode(gridTitle.get('text', '').strip(), 'utf-8')), keyColor="prColor", bold=True)
		link = None if gridTitle is None else gridTitle.get('link')
		if link is None or link == '':
			continue
		link = '{0}{1}'.format(baseUrl, link)
		posts = grid.get('posts', [])
		image = iconimage if posts is None or len(posts) < 1 else posts[0].get('imageObj', {}).get('d', '')
		grids_arr.append((title, link, image, {"title": title}))
	grids_sorted = grids_arr if sortBy == 0 else sorted(grids_arr,key=lambda grids_arr: grids_arr[0])
	for name, link, icon, infos in grids_sorted:
		common.addDir(name, link, 21, icon, infos=infos, module=module)

def UpgradeImageUrl(url, width, height, quality=90):
	"""Kaltura returns 120x90 by default; request an explicit size for sharp art."""
	if not url or 'GetImage' not in url:
		return url
	base = url.split('/width/')[0].rstrip('/')
	return '{0}/width/{1}/height/{2}/quality/{3}'.format(base, width, height, quality)

def FindImageUrl(images, preferredNames):
	for name in preferredNames:
		for img in images or []:
			if img.get('imageTypeName') == name or img.get('ratio') == name:
				return img.get('url')
	if images:
		return images[0].get('url')
	return None

def GetSeriesArt(images):
	"""Build high-res art; use vertical poster as the main series image."""
	if not images:
		return moduleIcon, None
	landscape = FindImageUrl(images, ('16x9', 'Landscape'))
	portrait = FindImageUrl(images, ('2x3', 'Portrait_9_16', '9x16')) or landscape
	poster = UpgradeImageUrl(portrait, 800, 1200) or moduleIcon
	fanart = UpgradeImageUrl(landscape, 1920, 1080) or poster
	# Prefer poster for thumb/icon so skins show vertical posters in the list.
	return poster, {'thumb': poster, 'icon': poster, 'poster': poster, 'fanart': fanart}

def GetEpisodeArt(images, fallback=''):
	if not images:
		return fallback or moduleIcon, None
	url = FindImageUrl(images, ('16x9', 'Landscape')) or images[0].get('url')
	thumb = UpgradeImageUrl(url, 1280, 720) or fallback or moduleIcon
	return thumb, {'thumb': thumb, 'icon': thumb, 'fanart': thumb, 'poster': thumb}

def CollectSeriesFromLeafs(leafs, series_map):
	for leaf in leafs or []:
		for serie in leaf.get('child') or []:
			try:
				metas = serie.get('metas') or {}
				seriesID = str(metas.get('SeriesID') or '')
				if seriesID == '' or seriesID == '0' or seriesID in series_map:
					continue
				mediaType = metas.get('MediaType') or serie.get('typeDescription') or ''
				# Homepage rails mix series with episodes/articles; keep series only.
				if mediaType != 'Series' and serie.get('type') != 1259:
					continue
				icon, arts = GetSeriesArt(serie.get('images') or [])
				rawName = common.encode(serie.get('name', ''), 'utf-8')
				name = common.GetLabelColor(rawName, keyColor="prColor", bold=True)
				description = common.encode(serie.get('description') or '', 'utf-8')
				createDate = int(serie.get('createDate') or 0)
				infos = {"title": rawName, "plot": description, 'mediatype': 'tvshow'}
				if createDate > 0:
					infos['aired'] = time.strftime("%Y-%m-%d", time.localtime(createDate))
				# (createDate, name, seriesID, icon, infos, arts)
				series_map[seriesID] = (createDate, name, seriesID, icon, infos, arts)
			except Exception as ex:
				xbmc.log('SerieID: {0}\n{1}'.format(serie.get('metas', {}).get('SeriesID'), str(ex)), xbmc.LOGERROR)
	return series_map

def InsertSeriesByCreateDate(grids_arr, item):
	"""Insert a series into the site-order list by createDate (newest first)."""
	createDate = item[0] or 0
	for i, existing in enumerate(grids_arr):
		if (existing[0] or 0) < createDate:
			grids_arr.insert(i, item)
			return
	grids_arr.append(item)

def GetSeriesList(url, iconimage):
	#result = GetUrlJson(url, root=True)
	root = True
	result = cache.get(GetUrlJson, 72, url, root, table='pages')
	if result==[]:
		result = cache.get(GetUrlJson, 0, url, root, table='pages')
	if len(result) < 1:
		return
	common.SetAddonSetting("reshetSiteBuildID", result['buildId'])
	primary = collections.OrderedDict() if common.NewerThanPyVer('2.6.99') else {}
	# Primary catalog: "כל התוכניות" (curated site order)
	CollectSeriesFromLeafs(result.get('props', {}).get('pageProps', {}).get('leafs'), primary)
	grids_arr = list(primary.values()) if common.NewerThanPyVer('2.6.99') else [primary[k] for k in primary]
	# Homepage rails include new shows (e.g. The Voice) before they appear in all-programs.
	# Insert them by createDate so "כמו באתר" keeps new shows near the top.
	homeUrl = '{0}/allshows/'.format(baseUrl)
	home = cache.get(GetUrlJson, 72, homeUrl, root, table='pages')
	if home == []:
		home = cache.get(GetUrlJson, 0, homeUrl, root, table='pages')
	if home:
		extra = collections.OrderedDict() if common.NewerThanPyVer('2.6.99') else {}
		CollectSeriesFromLeafs(home.get('props', {}).get('pageProps', {}).get('leafs'), extra)
		for seriesID, item in (extra.items() if common.NewerThanPyVer('2.6.99') else [(k, extra[k]) for k in extra]):
			if seriesID not in primary:
				InsertSeriesByCreateDate(grids_arr, item)
	grids_sorted = grids_arr if sortBy == 0 else sorted(grids_arr, key=lambda item: item[1])
	for createDate, name, link, icon, infos, arts in grids_sorted:
		common.addDir(name, link, 1, str(icon), infos=infos, module=module, arts=arts)
	# Keep plugin order for "כמו באתר"; let Kodi sort by label for "לפי א-ב".
	if sortBy == 0:
		xbmcplugin.addSortMethod(common.GetHandle(), xbmcplugin.SORT_METHOD_UNSORTED)
	else:
		xbmcplugin.addSortMethod(common.GetHandle(), xbmcplugin.SORT_METHOD_LABEL)

def GetPageJson(pageUrl, serieID, seasonNum=None):
	buildId = common.GetAddonSetting("reshetSiteBuildID")
	url = pageUrl.format(buildId, serieID) if seasonNum is None else pageUrl.format(buildId, serieID, seasonNum)
	result = common.OpenURL(url, headers=pageHeaders, responseMethod='json')
	if result is None:
		result = GetUrlJson('{0}/allshows/'.format(baseUrl), root=True)
		buildId = result['buildId']
		common.SetAddonSetting("reshetSiteBuildID", buildId)
		url = pageUrl.format(buildId, serieID) if seasonNum is None else pageUrl.format(buildId, serieID, seasonNum)
		result = common.OpenURL(url, headers=pageHeaders, responseMethod='json')
	return result['pageProps']['program']

def GetSeasonList(serieID, iconimage):
	result = GetPageJson(seriesUrl, serieID)
	seasons = result["seasonsList"]
	grids_arr = []
	for season in seasons:
		name = common.GetLabelColor(season["name"], keyColor="timesColor", bold=True)
		grids_arr.append((str(season["position"]), name))
	#grids_sorted = sorted(grids_arr,key=lambda grids_arr: grids_arr[1], reverse=True)
	#for key, name, link, icon, infos in grids_sorted:
	for seasonNum, name in grids_arr:
		common.addDir(name, serieID, 2, iconimage, infos={"title": name}, moreData=seasonNum, module=module)

def GetEpisodesList(serieID, iconimage, seasonNum):
	result = GetPageJson(seasonsUrl, serieID, seasonNum)
	episodes = result["episodes"]
	grids_arr = []
	for episode in episodes:
		name = common.GetLabelColor(episode["name"], keyColor="chColor")
		link = '--kaltura--{0}==='.format(episode['entryId'])
		icon, arts = GetEpisodeArt(episode.get("images") or [], iconimage)
		air_date = time.strftime("%d/%m/%Y", time.localtime(episode["createDate"]))
		grids_arr.append((episode["createDate"], name, link, icon, {"title": name, "plot": episode["description"], "aired": air_date}, arts))
	grids_sorted = sorted(grids_arr,key=lambda grids_arr: grids_arr[0], reverse=True)
	for air_date, name, link, icon, infos, arts in grids_sorted:
		common.addDir(name, link, 3, icon, infos=infos, contextMenu=[(common.GetLocaleString(30005), 'RunPlugin({0}?url={1}&name={2}&mode=3&iconimage={3}&moredata=choose&module=reshet)'.format(sys.argv[0], common.quote_plus(link), common.quote_plus(name), common.quote_plus(icon))), (common.GetLocaleString(30023), 'RunPlugin({0}?url={1}&name={2}&mode=3&iconimage={3}&moredata=set_reshet_res&module=reshet)'.format(sys.argv[0], common.quote_plus(link), common.quote_plus(name), common.quote_plus(icon)))], moreData=bitrate, module=module, isFolder=False, isPlayable=True, arts=arts)

def Run(name, url, mode, iconimage='', moreData=''):
	global sortBy, bitrate, programNameFormat
	sortBy = int(common.GetAddonSetting('{0}SortBy'.format(module)))
	bitrate = common.GetAddonSetting('{0}_res'.format(module))
	programNameFormat = int(common.GetAddonSetting("programNameFormat"))
	
	if mode == -1:
		GetCategoriesList(moduleIcon)
	elif mode == 0:
		GetSeriesList(url, moduleIcon)					# Series
	elif mode == 1:
		GetSeasonList(url, iconimage)					# Seasons
	elif mode == 2:
		GetEpisodesList(url, iconimage, moreData)		# Episodes
	elif mode == 3:
		Play(url, name, iconimage, moreData)			# Playing episode
	elif mode == 4:
		WatchLive(url, name, iconimage, moreData)		# Playing Live
	elif mode == 5:	
		common.ToggleSortMethod('reshetSortBy', sortBy)	# Toggle Lists' sorting method
	#elif mode == 6:
	#	GetGridList(moduleIcon, url)
	elif mode == 7:										#--- Move to a specific episodes' page  --
		urlp = common.url_parse(url)
		prms = common.parse_qs(urlp.query)
		page = common.GetIndexFromUser(name, int(prms['pages'][0]))
		if page < 0:
			page = int(prms['p'][0])
		url = '{0}{1}{2}/'.format(baseUrl, urlp.path, page)
		GetEpisodesListOld(url, iconimage)
	elif mode == 10:
		GetNewsCategoriesList(moduleIcon)				# News Shows
	elif mode == 20:
		GetSeriesListOld(url, moduleIcon)				# Series
	elif mode == 21:
		GetSeasonListOld(url, iconimage)				# Seasons
	elif mode == 22:
		GetEpisodesListOld(url, iconimage)				# Episodes
	
	if mode == 0:
		common.SetViewMode('tvshows')
	elif mode != 1:
		common.SetViewMode('episodes')
