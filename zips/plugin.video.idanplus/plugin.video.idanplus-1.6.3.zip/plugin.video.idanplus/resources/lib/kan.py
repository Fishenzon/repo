﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import sys, os, re, urlparse, time, datetime, json
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
imagesDir = xbmc.translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources', 'images')).decode("utf-8")
sortBy = int(Addon.getSetting("kanSortBy"))
module = 'kan'
baseUrl = 'https://www.kan.org.il'
userAgent = common.GetUserAgent()
headers={"User-Agent": userAgent}

def GetCategoriesList(iconimage):
	sortString = common.GetLocaleString(30002) if sortBy == 0 else common.GetLocaleString(30003)
	name = "{0}: {1}".format(common.GetLocaleString(30001), sortString)
	common.addDir(name, "toggleSortingMethod", 4, iconimage, {"Title": name, "Plot": "{0}[CR]{1}[CR]{2} / {3}".format(name, common.GetLocaleString(30004), common.GetLocaleString(30002), common.GetLocaleString(30003))}, module=module, isFolder=False)
	name = 'תוכניות בידור ותרבות'
	common.addDir(name, '{0}/Page.aspx?landingPageId=1039'.format(baseUrl), 1, iconimage, infos={"Title": name}, module=module)
	name = 'רצועת האקטואליה'
	common.addDir(name, '{0}/page.aspx?landingPageId=1037'.format(baseUrl), 1, iconimage, infos={"Title": name}, module=module)
	name = 'דיגיטל'
	common.addDir(name, '{0}/page.aspx?landingPageId=1041'.format(baseUrl), 1, iconimage, infos={"Title": name}, module=module)
	name = 'תכניות רדיו'
	common.addDir(name, '', 21, iconimage, infos={"Title": name}, module=module)
	name = 'מונדיאל 2018 - משחקים מלאים'
	common.addDir(name, '', 5, os.path.join(imagesDir, "wc2018.png"), infos={"Title": name}, module=module)

def GetSeriesList(url):
	text = common.OpenURL(url)
	matches = re.compile('class="component_sm_item news w-clearfix.+?href=\'.+?/program/\?catId=(.+?)\'.+?url\(\'(.+?)\'.+?<h3.+?>(.*?)</h3>.+?<p.+?>(.*?)</p>', re.S|re.I).findall(text)
	for id, iconimage, name, description in matches:
		name = '[B][COLOR {0}]{1}[/COLOR][/B]'.format(Addon.getSetting("prColor"), name.strip())
		common.addDir(name, id, 2, iconimage, infos={"Title": name, "Plot": description}, module=module)
	matches = re.compile('<div class="it_small_pictgroup.+?"background-image: url\(\'(.+?)\'\);.+?href=".+?/Program/\?catId=(.+?)".+?class="it_small_title">(.*?)</div>.+?class="it_small_txt">(.*?)</div>', re.S).findall(text)
	for iconimage, id, name, description in matches:
		name = '[B][COLOR {0}]{1}[/COLOR][/B]'.format(Addon.getSetting("prColor"), name.strip())
		common.addDir(name, id, 2, iconimage, infos={"Title": name, "Plot": description.strip()}, module=module)

def GetEpisodesList(catId):
	bitrate = Addon.getSetting('kan_res')
	if bitrate == '':
		bitrate = 'best'
	i = 0
	while True:
		i += 1
		url = '{0}/Program/getMoreProgram.aspx?count={1}&catId={2}'.format(baseUrl, i, catId)
		text = common.OpenURL(url)
		matches = re.compile('w-clearfix">.*?url\(\'(.+?)\'.+?<iframe.+?src="(.+?)".+?"content_title">(.+?)</.+?<p>(.+?)</p>', re.S).findall(text)
		if len(matches) == 0:
			break
		for iconimage, url, name, description in matches:
			name = '[COLOR {0}]{1}[/COLOR]'.format(Addon.getSetting("chColor"), name.strip())
			common.addDir(name, url, 3, iconimage, infos={"Title": name, "Plot": description.replace('&nbsp;', '').strip()}, module=module, moreData=bitrate, isFolder=False, isPlayable=True)

def GetRadioCategoriesList(iconimage):
	name = 'כאן ב'
	common.addDir(name, '{0}/live/radio.aspx?stationid=3'.format(baseUrl), 22, os.path.join(imagesDir, "bet.png"), infos={"Title": name}, module=module)
	name = 'כאן גימל'
	common.addDir(name, '{0}/live/radio.aspx?stationid=9'.format(baseUrl), 22, os.path.join(imagesDir, "gimel.png"), infos={"Title": name}, module=module)
	name = 'כאן 88'
	common.addDir(name, '{0}/live/radio.aspx?stationid=4'.format(baseUrl), 22, os.path.join(imagesDir, "88.png"), infos={"Title": name}, module=module)
	name = 'כאן תרבות'
	common.addDir(name, '{0}/live/radio.aspx?stationid=5'.format(baseUrl), 22, os.path.join(imagesDir, "culture.png"), infos={"Title": name}, module=module)
	name = 'כאן קול המוסיקה'
	common.addDir(name, '{0}/live/radio.aspx?stationid=7'.format(baseUrl), 22, os.path.join(imagesDir, "music.png"), infos={"Title": name}, module=module)
	name = 'כאן מורשת'
	common.addDir(name, '{0}/live/radio.aspx?stationid=6'.format(baseUrl), 22, os.path.join(imagesDir, "moreshet.png"), infos={"Title": name}, module=module)
	name = 'כאן Reka'
	common.addDir(name, '{0}/live/radio.aspx?stationid=10'.format(baseUrl), 22, os.path.join(imagesDir, "reka.png"), infos={"Title": name}, module=module)

def GetRadioSeriesList(url):
	text = common.OpenURL(url)
	matches = re.compile('class="radio_online_block">\s*?<a href=".*?progId=(.+?)" class="radio_online_pict.*?url\(\'(.*?)\'\);" alt="(.*?)">.*?station_future_name">(.*?)</div>', re.S).findall(text)
	for id, iconimage, name, description in matches:
		name = '[B][COLOR {0}]{1}[/COLOR][/B]'.format(Addon.getSetting("prColor"), name.strip())
		common.addDir(name, id, 23, iconimage, infos={"Title": name, "Plot": description}, module=module)

def GetRadioEpisodesList(progId, iconimage):
	i = 1
	while True:
		url = '{0}/Radio/getMoreItems.aspx?index={1}&progId={2}'.format(baseUrl, i, progId)
		text = common.OpenURL(url)
		matches = re.compile('class="radio_program_partgroup">.*?onclick="playItem\(\'(.*?)\'\)".*?class="radio_program_toggle top_plus.*?<div>(.*?)</div>', re.S).findall(text)
		for itemId, name in matches:
			name = '[COLOR {0}]{1}[/COLOR]'.format(Addon.getSetting("chColor"), name.strip())
			common.addDir(name, '{0}/radio/player.aspx?ItemId={1}'.format(baseUrl, itemId), 12, iconimage, infos={"Title": name}, module=module, moreData='best', isFolder=False, isPlayable=True)
		if len(matches) < 10:
			break
		i += 10

def Play(url, name='', iconimage='', quality='best'):
	if 'youtube' in url:
		video_id = url[url.rfind('/')+1:]
		if '?' in video_id:
			video_id = video_id[:video_id.find('?')]
		final = 'plugin://plugin.video.youtube/play/?video_id={0}'.format(video_id)
	else:
		final = GetPlayerKanUrl(url, headers=headers, quality=quality)
	listitem = xbmcgui.ListItem(path=final)
	xbmcplugin.setResolvedUrl(handle=handle, succeeded=True, listitem=listitem)

def GetPlayerKanUrl(url, headers={}, quality='best'):
	
	text = common.OpenURL(url, headers=headers)
	if len(re.compile('media\.(ma)?kan\.org\.il').findall(url)) > 0:
		match = re.compile('hls:\s*?"(.*?)"').findall(text)
		link = match[0]
	else:
		match = re.compile("var\s*metadataURL\s*?=\s*?'(.+?)'").findall(text)
		text = common.OpenURL(match[0].replace('https_streaming=true', 'https_streaming=false'), headers=headers)
		match = re.compile("<SmilURL.*>(.+)</SmilURL>").findall(text)
		smil = match[0].replace('amp;', '')
		match = re.compile("<Server priority=['\"]1['\"]>(.+)</Server>").findall(text)
		server = match[0]
		link = urlparse.urlunparse(urlparse.urlparse(smil)._replace(netloc=server))
	link = common.GetStreams(link, headers=headers, quality=quality)
	return '{0}|User-Agent={1}'.format(link, userAgent)

def WatchLive(url, name='', iconimage='', quality='best', type='video'):
	channels = {
		'11': '{0}/live/tv.aspx?stationid=2'.format(baseUrl),
		'33': 'https://www.makan.org.il/live/tv.aspx?stationid=3',
		'kan4K': '{0}/live/tv.aspx?stationid=18'.format(baseUrl),
		'bet': '{0}/live/radio.aspx?stationid=3'.format(baseUrl),
		'gimel': '{0}/live/radio.aspx?stationid=9'.format(baseUrl),
		'culture': '{0}/live/radio.aspx?stationid=5'.format(baseUrl),
		'88': '{0}/live/radio.aspx?stationid=4'.format(baseUrl),
		'moreshet':'{0}/live/radio.aspx?stationid=6'.format(baseUrl),
		'music': '{0}/live/radio.aspx?stationid=7'.format(baseUrl),
		'reka': '{0}/live/radio.aspx?stationid=10'.format(baseUrl),
		'makan': 'http://www.makan.org.il/live/radio.aspx?stationid=2',
		'persian': 'http://farsi.kan.org.il/',
		'80-90': '{0}/Radio/radio-80_90.aspx'.format(baseUrl),
		'alt': '{0}/Radio/radio-alt.aspx'.format(baseUrl),
		'classic': '{0}/Radio/radio-classic.aspx'.format(baseUrl),
		'hits': '{0}/Radio/radio-hits.aspx'.format(baseUrl),
		'nos': '{0}/Radio/radio-nos.aspx'.format(baseUrl),
		'regesh': '{0}/Radio/radio-regesh.aspx'.format(baseUrl),
		'oriental': '{0}/Radio/Oriental.aspx'.format(baseUrl)
	}
	channelUrl = url if type == 'radioProgram' else channels[url]
	text = common.OpenURL(channelUrl, headers=headers)
	if url == 'makan' or url == 'persian' or type == 'radioProgram':
		match = re.compile('id="playerFrame".*?src="(.*?)"', re.S).findall(text)
	elif type == 'video':
		match = re.compile('<iframe\s*class="embedly-embed".*src="(.+?)"').findall(text)
	else:
		match = re.compile('iframeLink\s*?=\s*?"(.*)"').findall(text)
	link = GetPlayerKanUrl(match[0], headers=headers, quality=quality)
	common.PlayStream(link, quality, name, iconimage)

def GetWC2018(iconimage=''):
	end = datetime.datetime.today()
	GetMatches(end.strftime("%Y-%m-%d"))
	start = datetime.datetime(2018, 6, 14) 
	for date in [end - datetime.timedelta(days=x) for x in range(1, (end-start).days+1)]:
		day = date.strftime("%Y-%m-%d")
		name = '[B][COLOR {0}]{1}[/COLOR][/B]'.format(Addon.getSetting("timesColor"), day)
		common.addDir(name, day, 6, iconimage, infos={"Title": name}, module=module)

def GetMatches(date):
	ts = time.time()
	tz = (datetime.datetime.fromtimestamp(ts) - datetime.datetime.utcfromtimestamp(ts)).seconds//3600
	url = 'https://hbsipbc.deltatre.net/hbs/api/cup/fifawc/season/2018/date/{0}/matches?timezoneoffset={1}'.format(date, tz)
	text = common.OpenURL(url)
	matches = json.loads(text)
	for match in matches['modules'].get('matches', []):
		for video in match['videos']:
			if video['kindId'] == 111 or video['kindId'] == 112:
				video_id = video['vId']
				title = video['title'].encode('utf-8')
				status = video['kind'].encode('utf-8')
				iconimage = video['thumbLarge']
				configurationFileUrl = video['settings']
				name = '[COLOR {0}]{1}[/COLOR] - [COLOR {2}]{3}[/COLOR]'.format(Addon.getSetting("prColor"), title, Addon.getSetting("chColor"), status)
				common.addDir(name, '{0}|{1}'.format(video_id, configurationFileUrl), 7, iconimage, infos={"Title": name}, module=module, isFolder=False, isPlayable=True)

def PlayMatch(url, name, iconimage):
	params = url.split('|')
	video_id = params[0]
	configurationFileUrl = params[1]
	text = common.OpenURL('https://hbsipbc.deltatre.net/divauni/IPBC/fe/video/videodata/{0}.xml'.format(video_id))
	match = re.compile('<uri><\!\[CDATA\[(.*?)\]\]>').findall(text) 
	divaplayer = 'https://hbsipbc.deltatre.net/components/divahtml5/divaplayer.html'
	referer = "{0}?videoid={1}&configurationFileUrl={2}&useCredential=true".format(divaplayer, video_id, configurationFileUrl)
	tokenizeUrl = 'https://hbsipbc.deltatre.net/api/api-akamai/tokenize'
	headers = {
		"content-type": "application/json",
		"Referer": referer
	}
	user_data = {
		"Type": 1,
		"User": "",
		"VideoId": video_id,
		"VideoSource": match[0],
		"VideoKind": "",
		"AssetState": "3",
		"PlayerType": "HTML5",
		"VideoSourceFormat": "HLS",
		"VideoSourceName": "HLS",
		"DRMType": "",
		"AuthType": "",
		"ContentKeyData": "",
		"Other": video_id
	}
	text = common.OpenURL(tokenizeUrl, headers=headers, user_data=str(user_data).replace("'", '"'))
	link = '{0}|Referer={1}&User-Agent=Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36'.format(json.loads(text)["ContentUrl"], referer)
	listitem = xbmcgui.ListItem(path=link)
	xbmcplugin.setResolvedUrl(handle=handle, succeeded=True, listitem=listitem)
	
def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 0:	#------------- Categories: ----------------------
		GetCategoriesList(iconimage)
	elif mode == 1:	#------------- Series: --------------------------
		GetSeriesList(url)
	elif mode == 2:	#------------- Episodes: ------------------------
		GetEpisodesList(url)
	elif mode == 3:	#------------- Playing episode  -----------------
		Play(url, name, iconimage, moreData)
	elif mode == 4:	#------------- Toggle Lists' sorting method -----
		common.ToggleSortMethod('kanSortBy', sortBy)
	elif mode == 5:	#------------- Worldcup 2008 days List ----------
		GetWC2018(iconimage)
	elif mode == 6:	#------------- Worldcup 2008 day matches ---------
		GetMatches(url)
	elif mode == 7:	#------------- Play worldcup 2008 matche ---------
		PlayMatch(url, name, iconimage)
	elif mode == 21: #------------- Radio Categories: ---------------
		GetRadioCategoriesList(iconimage)
	elif mode == 22: #------------- Radio Series: -------------------
		GetRadioSeriesList(url)
	elif mode == 23: #------------- Radio Episodes: -----------------
		GetRadioEpisodesList(url, iconimage)
	elif mode == 12:
		WatchLive(url, name, iconimage, moreData, type='radioProgram')
	elif mode == 10:
		WatchLive(url, name, iconimage, moreData, type='video')
	elif mode == 11:
		WatchLive(url, name, iconimage, moreData, type='radio')
		
	if mode != 0:
		common.SetViewMode('episodes')
	if sortBy == 1 and mode == 1:
		xbmcplugin.addSortMethod(handle, 1)