# -*- coding: utf-8 -*-
import sys, os, urlparse, urllib, datetime, json
import xbmc, xbmcplugin, xbmcaddon
import resources.lib.common as common
import resources.lib.epg as epg
import resources.lib.iptv as iptv

reload(sys)
sys.setdefaultencoding('utf-8')

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
AddonName = Addon.getAddonInfo("name")
icon = Addon.getAddonInfo('icon')
imagesDir = xbmc.translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources', 'images')).decode("utf-8")
profileDir = common.profileDir
favoritesFile = os.path.join(profileDir, 'favorites.json')
if not os.path.isfile(favoritesFile):
	common.WriteList(favoritesFile, [])
params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
url = urllib.unquote_plus(params.get('url', ''))
mode = int(params.get('mode','-1'))
name = urllib.unquote_plus(params.get('name', ''))
iconimage = urllib.unquote_plus(params.get('iconimage', ''))
module = params.get('module')
moreData = urllib.unquote_plus(params.get('moredata', ''))

def GetCategoriesList():
	name = common.GetLabelColor("מועדפי עידן פלוס", bold=True, color="none")
	common.addDir(name, '', 10, icon, infos={"Title": name}, addFav=False)
	name = common.GetLabelColor("חיפוש תכניות", bold=True, color="none")
	common.addDir(name, '', 4, icon, infos={"Title": name}, addFav=False)
	name = common.GetLabelColor("שידורים חיים", bold=True, color="none")
	common.addDir(name, '', 1, icon, infos={"Title": name})
	name = common.GetLabelColor("VOD", bold=True, color="none")
	common.addDir(name, '', 2, icon, infos={"Title": name})
	name = common.GetLabelColor("רדיו", bold=True, color="none")
	common.addDir(name, '', 3, icon, infos={"Title": name})
	name = common.GetLabelColor("תכניות רדיו", bold=True, color="none")
	common.addDir(name, '', 21, icon, infos={"Title": name}, module='kan')
	name = common.GetLabelColor("הגדרות", bold=True, color="none")
	common.addDir(name, 'Addon.OpenSettings', 6, icon, infos={"Title": name}, moreData=AddonID, isFolder=False)

def GetUserTVChannels():
	userChannels = []
	channels = [{'ch': 'ch_11', 'index': 1}, {'ch': 'ch_12', 'index': 2}, {'ch': 'ch_13', 'index': 3}, {'ch': 'ch_14', 'index': 4}, {'ch': 'ch_20', 'index': 5}, {'ch': 'ch_21', 'index': 6}, {'ch': 'ch_23', 'index': 7}, {'ch': 'ch_24', 'index': 8}, {'ch': 'ch_bb', 'index': 9}, {'ch': 'ch_33', 'index': 10}, {'ch': 'ch_66', 'index': 11}, {'ch': 'ch_97', 'index': 12}, {'ch': 'ch_99', 'index': 13}, {'ch': 'ch_2news2', 'index': 14}, {'ch': 'ch_2news', 'index': 14}, {'ch': 'ch_ynet', 'index': 15}, {'ch': 'ch_walla', 'index': 16}, {'ch': 'ch_keshetBest', 'index': 19}, {'ch': 'ch_refresh', 'index': 100}]
	for channel in channels:
		channel['index'] = common.GetIntSetting(channel['ch'], channel['index'])
	channels = sorted(channels, key=lambda k: k['index']) 
	for channel in channels:
		if channel['index'] == 0:
			continue
		ch = channel['ch']
		ind = channel['index']
		if ch == 'ch_11': userChannels.append({'index': ind, 'nameID': 30602, 'channelID': '11', 'mode': 10, 'image': 'kan.jpg', 'module': 'kan', 'resKey': 'ch_11_res', 'tvgID': '11', 'type': 'tv'})
		elif ch == 'ch_12': userChannels.append({'index': ind, 'nameID': 30603, 'channelID': '12', 'mode': 10, 'image': 'keshet.jpg', 'module': 'keshet', 'resKey': 'ch_12_res', 'tvgID': '12', 'type': 'tv'})
		elif ch == 'ch_13': userChannels.append({'index': ind, 'nameID': 30604, 'channelID': '13', 'mode': 4, 'image': '13.png', 'module': 'reshet', 'resKey': 'ch_13_res', 'tvgID': '13', 'type': 'tv'})
		elif ch == 'ch_14': userChannels.append({'index': ind, 'nameID': 30605, 'channelID': '14', 'mode': 6, 'image': 'ten.png', 'module': 'ten', 'resKey': 'ch_14_res', 'tvgID': '14', 'type': 'tv'})
		elif ch == 'ch_20': userChannels.append({'index': ind, 'nameID': 30606, 'channelID': '20', 'mode': 10, 'image': '20.png', 'module': 'twenty', 'resKey': 'ch_20_res', 'tvgID': '20', 'type': 'tv'})
		elif ch == 'ch_21': userChannels.append({'index': ind, 'nameID': 30619, 'channelID': '21', 'mode': 10, 'image': '21tv.jpg', 'module': '21tv', 'resKey': 'ch_21_res', 'tvgID': '21', 'type': 'tv'})
		elif ch == 'ch_23': userChannels.append({'index': ind, 'nameID': 30607, 'channelID': '23', 'mode': 10, 'image': '23tv.jpg', 'module': 'kan', 'resKey': 'ch_23_res', 'tvgID': '23', 'type': 'tv'})
		elif ch == 'ch_24': userChannels.append({'index': ind, 'nameID': 30608, 'channelID': '24', 'mode': 10, 'image': '24.jpg', 'module': 'keshet', 'resKey': 'ch_24_res', 'tvgID': '24', 'type': 'tv'})
		#elif ch == 'ch_bb': userChannels.append({'index': ind, 'nameID': 30621, 'channelID': 'bb', 'mode': 4, 'image': 'bb.jpg', 'module': 'reshet', 'resKey': 'ch_bb_res', 'tvgID': '', 'type': 'tv'})
		elif ch == 'ch_33': userChannels.append({'index': ind, 'nameID': 30609, 'channelID': '33', 'mode': 10, 'image': 'makan.png', 'module': 'kan', 'resKey': 'ch_33_res', 'tvgID': '33', 'type': 'tv'})
		elif ch == 'ch_66': userChannels.append({'index': ind, 'nameID': 30610, 'channelID': '66', 'mode': 10, 'image': 'kabbalah.jpg', 'module': 'kabbalah', 'resKey': 'cch_66_res', 'tvgID': '66', 'type': 'tv'})
		elif ch == 'ch_97': userChannels.append({'index': ind, 'nameID': 30612, 'channelID': '97', 'mode': 10, 'image': 'hidabroot.jpg', 'module': 'hidabroot', 'resKey': 'ch_97_res', 'tvgID': '97', 'type': 'tv'})
		elif ch == 'ch_99': userChannels.append({'index': ind, 'nameID': 30613, 'channelID': '99', 'mode': 10, 'image': 'knesset.png', 'module': 'knesset', 'resKey': 'ch_99_res', 'tvgID': '99', 'type': 'tv'})
		elif ch == 'ch_2news2': userChannels.append({'index': ind, 'nameID': 30625, 'channelID': '2news', 'mode': 10, 'image': '2news.jpg', 'module': 'tv', 'resKey': 'ch_2news2_res', 'tvgID': '', 'type': 'tv'})
		elif ch == 'ch_2news': userChannels.append({'index': ind, 'nameID': 30620, 'channelID': 'news', 'mode': 4, 'image': '2news.jpg', 'module': 'reshet', 'resKey': 'ch_2news_res', 'tvgID': '', 'type': 'tv'})
		elif ch == 'ch_ynet': userChannels.append({'index': ind, 'nameID': 30622, 'channelID': 'live', 'mode': 10, 'image': 'ynet.jpg', 'module': 'ynet', 'resKey': 'ch_ynet_res', 'tvgID': '', 'type': 'tv'})
		elif ch == 'ch_walla': userChannels.append({'index': ind, 'nameID': 30624, 'channelID': 'live', 'mode': 10, 'image': 'wallanews.png', 'module': 'walla', 'resKey': 'ch_walla_res', 'tvgID': '', 'type': 'tv'})
		elif ch == 'ch_keshetBest': userChannels.append({'index': ind, 'nameID': 30617, 'channelID': 'keshetBest', 'mode': 10, 'image': 'keshet_best.jpg', 'module': 'keshet', 'resKey': 'ch_keshetBest_res', 'tvgID': '', 'type': 'tv'})
		elif ch == 'ch_refresh': userChannels.append({'index': ind, 'nameID': 30618, 'channelID': 'refresh', 'mode': 6, 'image': icon, 'module': '', 'resKey': '', 'tvgID': '', 'type': 'refresh'})
	userChannels = sorted(userChannels, key=lambda k: k['index'])
	return userChannels

def GetUserRadios():
	userChannels = []
	channels = [{'ch': 'rd_glglz', 'index': 1}, {'ch': 'rd_88', 'index': 2}, {'ch': 'rd_90', 'index': 3}, {'ch': 'rd_97', 'index': 4}, {'ch': 'rd_99', 'index': 5}, {'ch': 'rd_100', 'index': 6}, {'ch': 'rd_101', 'index': 7}, {'ch': 'rd_1015', 'index': 8}, {'ch': 'rd_102', 'index': 9}, {'ch': 'rd_102Eilat', 'index': 10}, {'ch': 'rd_103', 'index': 11}, {'ch': 'rd_1045', 'index': 12}, {'ch': 'rd_1075', 'index': 13}, {'ch': 'rd_glz', 'index': 14}, {'ch': 'rd_bet', 'index': 15}, {'ch': 'rd_gimel', 'index': 16}, {'ch': 'rd_culture', 'index': 17}, {'ch': 'rd_music', 'index': 18}, {'ch': 'rd_moreshet', 'index': 19}, {'ch': 'rd_reka', 'index': 20}, {'ch': 'rd_makan', 'index': 21}, {'ch': 'rd_persian', 'index': 22}, {'ch': 'rd_80_90', 'index': 23}, {'ch': 'rd_alt', 'index': 24}, {'ch': 'rd_classic', 'index': 25}, {'ch': 'rd_hits', 'index': 26}, {'ch': 'rd_nos', 'index': 27}, {'ch': 'rd_regesh', 'index': 28}, {'ch': 'rd_oriental', 'index': 29}, {'ch': 'rd_refresh', 'index': 100}]
	for channel in channels:
		channel['index'] = common.GetIntSetting(channel['ch'], channel['index'])
	channels = sorted(channels, key=lambda k: k['index']) 
	for channel in channels:
		if channel['index'] == 0:
			continue
		ch = channel['ch']
		ind = channel['index']
		if ch == 'rd_glglz': userChannels.append({'index': ind, 'nameID': 30702, 'channelID': 'glglz', 'mode': 11, 'image': 'glglz.jpg', 'module': 'glz', 'tvgID': 'glglz', 'type': 'radio'})
		elif ch == 'rd_88': userChannels.append({'index': ind, 'nameID': 30703, 'channelID': '88', 'mode': 11, 'image': '88.png', 'module': 'kan', 'tvgID': '88', 'type': 'radio'})
		elif ch == 'rd_90': userChannels.append({'index': ind, 'nameID': 30724, 'channelID': '90fm', 'mode': 11, 'image': '90fm.jpg', 'module': 'radio', 'tvgID': '90fm', 'type': 'radio'})
		elif ch == 'rd_97': userChannels.append({'index': ind, 'nameID': 30725, 'channelID': '97fm', 'mode': 11, 'image': '97fm.jpg', 'module': 'radio', 'tvgID': '97fm', 'type': 'radio'})
		elif ch == 'rd_99': userChannels.append({'index': ind, 'nameID': 30704, 'channelID': '99fm', 'mode': 11, 'image': '99fm.png', 'module': '99fm', 'tvgID': '99fm', 'type': 'radio'})
		elif ch == 'rd_100': userChannels.append({'index': ind, 'nameID': 30726, 'channelID': '100fm', 'mode': 11, 'image': '100fm.jpg', 'module': 'radio', 'tvgID': '100fm', 'type': 'radio'})
		elif ch == 'rd_101': userChannels.append({'index': ind, 'nameID': 30727, 'channelID': '101fm', 'mode': 11, 'image': '101fm.png', 'module': 'radio', 'tvgID': '101fm', 'type': 'radio'})
		elif ch == 'rd_1015': userChannels.append({'index': ind, 'nameID': 30728, 'channelID': '1015fm', 'mode': 11, 'image': '1015fm.jpg', 'module': 'radio', 'tvgID': '1015fm', 'type': 'radio'})
		elif ch == 'rd_102': userChannels.append({'index': ind, 'nameID': 30705, 'channelID': '102fm', 'mode': 11, 'image': '102fm.jpg', 'module': 'radio', 'tvgID': '102fm', 'type': 'radio'})
		elif ch == 'rd_102Eilat': userChannels.append({'index': ind, 'nameID': 30729, 'channelID': '102fmEilat', 'mode': 11, 'image': '102fmEilat.jpg', 'module': 'radio', 'tvgID': '102fmEilat', 'type': 'radio'})
		elif ch == 'rd_103': userChannels.append({'index': ind, 'nameID': 30706, 'channelID': '103fm', 'mode': 11, 'image': '103fm.png', 'module': 'radio', 'tvgID': '103fm', 'type': 'radio'})
		elif ch == 'rd_1045': userChannels.append({'index': ind, 'nameID': 30730, 'channelID': '1045fm', 'mode': 11, 'image': '1045fm.jpg', 'module': 'radio', 'tvgID': '1045fm', 'type': 'radio'})
		elif ch == 'rd_1075': userChannels.append({'index': ind, 'nameID': 30731, 'channelID': '1075fm', 'mode': 11, 'image': '1075fm.jpg', 'module': 'radio', 'tvgID': '1075fm', 'type': 'radio'})
		elif ch == 'rd_glz': userChannels.append({'index': ind, 'nameID': 30707, 'channelID': 'glz', 'mode': 11, 'image': 'glz.jpg', 'module': 'glz', 'tvgID': 'glz', 'type': 'radio'})
		elif ch == 'rd_bet': userChannels.append({'index': ind, 'nameID': 30708, 'channelID': 'bet', 'mode': 11, 'image': 'bet.png', 'module': 'kan', 'tvgID': 'bet', 'type': 'radio'})
		elif ch == 'rd_gimel': userChannels.append({'index': ind, 'nameID': 30709, 'channelID': 'gimel', 'mode': 11, 'image': 'gimel.png', 'module': 'kan', 'tvgID': 'gimel', 'type': 'radio'})
		elif ch == 'rd_culture': userChannels.append({'index': ind, 'nameID': 30710, 'channelID': 'culture', 'mode': 11, 'image': 'culture.png', 'module': 'kan', 'tvgID': 'culture', 'type': 'radio'})
		elif ch == 'rd_music': userChannels.append({'index': ind, 'nameID': 30711, 'channelID': 'music', 'mode': 11, 'image': 'music.png', 'module': 'kan', 'tvgID': 'music', 'type': 'radio'})
		elif ch == 'rd_moreshet': userChannels.append({'index': ind, 'nameID': 30712, 'channelID': 'moreshet', 'mode': 11, 'image': 'moreshet.png', 'module': 'kan', 'tvgID': 'moreshet', 'type': 'radio'})
		elif ch == 'rd_reka': userChannels.append({'index': ind, 'nameID': 30713, 'channelID': 'reka', 'mode': 11, 'image': 'reka.png', 'module': 'kan', 'tvgID': 'reka', 'type': 'radio'})
		elif ch == 'rd_makan': userChannels.append({'index': ind, 'nameID': 30714, 'channelID': 'makan', 'mode': 11, 'image': 'makan.png', 'module': 'kan', 'tvgID': 'makan', 'type': 'radio'})
		elif ch == 'rd_persian': userChannels.append({'index': ind, 'nameID': 30715, 'channelID': 'persian', 'mode': 11, 'image': 'persian.png', 'module': 'kan', 'tvgID': 'persian', 'type': 'radio'})
		elif ch == 'rd_80_90': userChannels.append({'index': ind, 'nameID': 30716, 'channelID': '80-90', 'mode': 11, 'image': '80_90.png', 'module': 'kan', 'tvgID': '', 'type': 'radio'})
		elif ch == 'rd_alt': userChannels.append({'index': ind, 'nameID': 30717, 'channelID': 'alt', 'mode': 11, 'image': 'alt.png', 'module': 'kan', 'tvgID': '', 'type': 'radio'})
		elif ch == 'rd_classic': userChannels.append({'index': ind, 'nameID': 30718, 'channelID': 'classic', 'mode': 11, 'image': 'classic.png', 'module': 'kan', 'tvgID': '', 'type': 'radio'})
		elif ch == 'rd_hits': userChannels.append({'index': ind, 'nameID': 30719, 'channelID': 'hits', 'mode': 11, 'image': 'hits.png', 'module': 'kan', 'tvgID': '', 'type': 'radio'})
		elif ch == 'rd_nos': userChannels.append({'index': ind, 'nameID': 30720, 'channelID': 'nos', 'mode': 11, 'image': 'nos.png', 'module': 'kan', 'tvgID': '', 'type': 'radio'})
		elif ch == 'rd_regesh': userChannels.append({'index': ind, 'nameID': 30721, 'channelID': 'regesh', 'mode': 11, 'image': 'regesh.png', 'module': 'kan', 'tvgID': '', 'type': 'radio'})
		elif ch == 'rd_oriental': userChannels.append({'index': ind, 'nameID': 30722, 'channelID': 'oriental', 'mode': 11, 'image': 'oriental.png', 'module': 'kan', 'tvgID': '', 'type': 'radio'})
		elif ch == 'rd_refresh': userChannels.append({'index': ind, 'nameID': 30723, 'channelID': 'refresh', 'mode': 6, 'image': icon, 'module': '', 'tvgID': '', 'type': 'refresh'})
	userChannels = sorted(userChannels, key=lambda k: k['index'])
	return userChannels
	
def LiveChannels():
	if common.GetKodiVer() >= 18 and Addon.getSetting("useIPTV") == 'true':
		name = common.GetLabelColor(common.GetLocaleString(30652), bold=True, color="none")
		common.addDir(name, 'ActivateWindow', 6, icon, infos={"Title": name}, moreData='tvchannels', isFolder=False)
	nowEPG = epg.GetNowEPG()
	channels = GetUserTVChannels()
	for channel in channels:
		if channel.get('type') == 'refresh': 
			name = common.GetLabelColor(common.GetLocaleString(channel['nameID']), bold=True, color="none")
			common.addDir(name, 'Container.Refresh', channel['mode'], channel['image'], infos={"Title": name}, moreData=';noexit', isFolder=False)
		else:
			programs = [] if channel['tvgID'] == '' else nowEPG.get(channel['tvgID'], [])
			LiveChannel(common.GetLocaleString(channel['nameID']), channel['channelID'], channel['mode'], channel['image'], channel['module'], contextMenu=[], resKey=channel['resKey'], programs=programs, tvgID=channel['tvgID'])

def LiveChannel(name, url, mode, iconimage, module, contextMenu=[], choose=True, resKey='', bitrate='', programs=[], tvgID='', addFav=True):
	channelNameFormat = int(Addon.getSetting("channelNameFormat"))
	displayName = common.GetLabelColor(name, keyColor="chColor", bold=True)
	description = ''
	iconimage = os.path.join(imagesDir, iconimage)
	
	if len(programs) > 0:
		contextMenu.insert(0, (common.GetLocaleString(30030), 'Container.Update({0}?url={1}&name={2}&mode=2&iconimage={3}&module=epg)'.format(sys.argv[0], url, urllib.quote_plus(name), urllib.quote_plus(iconimage))))
		programTime = common.GetLabelColor("[{0}-{1}]".format(datetime.datetime.fromtimestamp(programs[0]["start"]).strftime('%H:%M'), datetime.datetime.fromtimestamp(programs[0]["end"]).strftime('%H:%M')), keyColor="timesColor")
		programName = common.GetLabelColor(programs[0]["name"].encode('utf-8'), keyColor="prColor", bold=True)
		displayName = GetChannelName(programName, programTime, displayName, channelNameFormat)
		description = '{0}[CR]{1}'.format(programName, programs[0]["description"].encode('utf-8'))
		if len(programs) > 1:
			nextProgramName = common.GetLabelColor(programs[1]["name"].encode('utf-8'), keyColor="prColor", bold=True)
			nextProgramTime = common.GetLabelColor("[{0}-{1}]".format(datetime.datetime.fromtimestamp(programs[1]["start"]).strftime('%H:%M'), datetime.datetime.fromtimestamp(programs[1]["end"]).strftime('%H:%M')), keyColor="timesColor")
			description = GetDescription(description, nextProgramTime, nextProgramName, channelNameFormat)
	if resKey == '' and bitrate == '':
		bitrate = 'best'
	else:
		if bitrate == '':
			bitrate = Addon.getSetting(resKey)
			if bitrate == '':
				bitrate = 'best'
		if addFav:
			contextMenu.insert(0, (common.GetLocaleString(30023), 'RunPlugin({0}?url={1}&name={2}&mode={3}&iconimage={4}&moredata=set_{5}&module={6})'.format(sys.argv[0], url, urllib.quote_plus(displayName), mode, urllib.quote_plus(iconimage), resKey, module)))
	if choose:
		contextMenu.insert(0, (common.GetLocaleString(30005), 'RunPlugin({0}?url={1}&name={2}&mode={3}&iconimage={4}&moredata=choose&module={5})'.format(sys.argv[0], url, urllib.quote_plus(displayName), mode, urllib.quote_plus(iconimage), module)))
	if contextMenu == []:
		contextMenu = None
	favData = {'name': common.GetLabelColor(name, keyColor="chColor", bold=True), 'tvgID': tvgID} if addFav else None
	common.addDir(displayName, url, mode, iconimage, infos={"Title": displayName, "Plot": description}, contextMenu=contextMenu, moreData=bitrate, module=module, isFolder=False, isPlayable=True, addFav=addFav, favData=favData)

def GetChannelName(programName, programTime, displayName, channelNameFormat):
	if channelNameFormat == 0:
		chName = " {0} - {1} {2} ".format(displayName, programName, programTime)
	elif channelNameFormat == 1:
		chName = " {0}  {1}  {2} ".format(displayName, programTime, programName)
	elif channelNameFormat == 2:
		chName = " {0} {1} - {2} ".format(programTime, programName, displayName)
	elif channelNameFormat == 3:
		chName = "  {0}  {1}  {2} ".format(programName, programTime, displayName)
	return chName
	
def GetDescription(description, nextProgramTime, nextProgramName, channelNameFormat):
	if channelNameFormat == 0 or channelNameFormat == 1:
		description = ' {0}[CR][CR]{1} {2} '.format(description, nextProgramTime, nextProgramName)
	elif channelNameFormat == 2 or channelNameFormat == 3:
		description = ' {0}[CR][CR]{1} {2} '.format(description, nextProgramName, nextProgramTime)
	return description

def VODs():
	name = 'כאן 11'
	common.addDir(name, '', 0, os.path.join(imagesDir, "kan.jpg"), infos={"Title": name}, module='kan')
	name = 'קשת 12'
	common.addDir(name, '', 0, os.path.join(imagesDir, "mako.png"), infos={"Title": name}, module='keshet')
	name = 'רשת 13'
	common.addDir(name, '', -1, os.path.join(imagesDir, "13.png"), infos={"Title": name}, module='reshet')
	name = 'עשר 14'
	common.addDir(name, '', 0, os.path.join(imagesDir, "ten.png"), infos={"Title": name}, module='ten')
	name = 'מורשת 20'
	common.addDir(name, '', -1, os.path.join(imagesDir, "20.png"), infos={"Title": name}, module='twenty')

def Radios():
	if common.GetKodiVer() >= 18 and Addon.getSetting("useIPTV") == 'true':
		name = common.GetLabelColor(common.GetLocaleString(30732), bold=True, color="none")
		common.addDir(name, 'ActivateWindow', 6, icon, infos={"Title": name}, moreData='radiochannels', isFolder=False)
	nowEPG = epg.GetNowEPG()
	channels = GetUserRadios() 
	for channel in channels:
		if channel.get('type') == 'refresh': 
			name = common.GetLabelColor(common.GetLocaleString(channel['nameID']), bold=True, color="none")
			common.addDir(name, 'Container.Refresh', channel['mode'], channel['image'], infos={"Title": name}, moreData=';noexit', isFolder=False)
		else:
			programs = [] if channel['tvgID'] == '' else nowEPG.get(channel['tvgID'], [])
			LiveChannel(common.GetLocaleString(channel['nameID']), channel['channelID'], channel['mode'], channel['image'], channel['module'], contextMenu=[], choose=False, programs=programs, tvgID=channel['tvgID'])

def MakeIPTVfiles():
	iptv.MakeIPTVlist(GetUserTVChannels() + GetUserRadios())
	if common.isFileOld(common.epgFile):
		epg.GetEPG()
	else:
		iptv.MakeChannelsGuide()

def AddFavorite(url):
	favoritesList = common.ReadList(favoritesFile)
	if any(u == url for u in favoritesList):
		return
	favoritesList.append(url.decode("utf-8"))
	common.WriteList(favoritesFile, favoritesList)
	xbmc.executebuiltin("Notification({0}, {1}, 5000, {2})".format(AddonName, common.GetLocaleString(30028), icon))

def RemoveFavortie(index):
	favoritesList = common.ReadList(favoritesFile)
	if index < 0 or index >= len(favoritesList):
		return
	favoritesList.remove(favoritesList[index])
	common.WriteList(favoritesFile, favoritesList)
	xbmc.executebuiltin("Notification({0}, {1}, 5000, {2})".format(AddonName, common.GetLocaleString(30029), icon))
	xbmc.executebuiltin("XBMC.Container.Refresh()")

def ShowFavorties():
	favoritesList = common.ReadList(favoritesFile)
	nowEPG = []
	i = -1
	for favorite in favoritesList:
		i += 1
		u = favorite.encode("utf-8")
		prms = dict(urlparse.parse_qsl(u[u.find('?')+1:]))
		url = urllib.unquote_plus(prms.get('url', ''))
		mode = int(prms.get('mode','-1'))
		name = urllib.unquote_plus(prms.get('name', ''))
		iconimage = urllib.unquote_plus(prms.get('iconimage', ''))
		module = prms.get('module')
		moreData = urllib.unquote_plus(prms.get('moredata', ''))
		isFolder = prms.get('isFolder', 'False') == 'True'
		isPlayable = prms.get('isPlayable', 'False') == 'True'
		tvgID = prms.get('tvgID', '')
		contextMenu = [(common.GetLocaleString(30027), 'XBMC.RunPlugin({0}?url={1}&mode=9)'.format(sys.argv[0], i)),
			(common.GetLocaleString(30031), 'XBMC.RunPlugin({0}?mode=11&url={1}&moredata=-1)'.format(sys.argv[0], i)),
			(common.GetLocaleString(30032), 'XBMC.RunPlugin({0}?mode=11&url={1}&moredata=1)'.format(sys.argv[0], i)),
			(common.GetLocaleString(30033), 'XBMC.RunPlugin({0}?mode=11&url={1}&moredata=0)'.format(sys.argv[0], i))]
		if tvgID != '':
			if nowEPG == []:
				nowEPG = epg.GetNowEPG()
			programs = nowEPG.get(tvgID, [])
			LiveChannel(common.GetUnColor(name), url, mode, iconimage, module, contextMenu=contextMenu, bitrate=moreData, programs=programs, addFav=False)
		else:
			common.addDir(name, url, mode, iconimage, infos={"Title": name}, contextMenu=contextMenu, moreData=moreData, module=module, isFolder=isFolder, isPlayable=isPlayable, addFav=False)

def Search():
	series = common.GetUpdatedList(common.seriesFile, common.seriesUrl, zip=True, sort=True)
	filteredSeries = []
	seriesLinks = []
	searchText = common.GetKeyboardText('מילים לחיפוש', '').strip()
	if searchText == '':
		filteredSeries = series
	else:
		for serie in series:
			if serie['name'].startswith(searchText):
				filteredSeries.append(serie)
				seriesLinks.append(serie['name'])
		for serie in series:
			if searchText in serie['name'] and serie['name'] not in seriesLinks:
				filteredSeries.append(serie)
				seriesLinks.append(serie['name'])
	programNameFormat = int(Addon.getSetting("programNameFormat"))
	for serie in filteredSeries:
		moduleName = ''
		if serie['module'] == 'kan': 		moduleName = 'כאן 11'
		elif serie['module'] == 'keshet': 	moduleName = 'קשת 12'
		elif serie['module'] == 'reshet': 	moduleName = 'רשת 13'
		elif serie['module'] == 'ten': 		moduleName = 'עשר 14'
		elif serie['module'] == 'twenty': 	moduleName = 'מורשת 20'
		name = common.getDisplayName(serie['name'], moduleName, programNameFormat, bold=True)
		infos = {"Title": name, "Plot": serie['desc']}
		common.addDir(name, serie['url'], serie['mode'], serie['icon'].encode('utf-8'), infos, module=serie['module'], totalItems=len(serie))

if module is None:
	if mode == -1:
		GetCategoriesList()
	elif mode == 1:
		LiveChannels()
	elif mode == 2:
		VODs()
	elif mode == 3:
		Radios()
	elif mode == 4:
		Search()
	elif mode == 6:
		p = moreData.split(';')
		xbmc.executebuiltin('{0}({1})'.format(url, p[0]))
		if p[-1] != 'noexit':
			sys.exit()
	elif mode == 7:
		MakeIPTVfiles()
		sys.exit()
	elif mode == 8:
		AddFavorite(url)
		sys.exit()
	elif mode == 9:
		RemoveFavortie(int(url))
		sys.exit()
	elif mode == 10:
		ShowFavorties()
	elif mode == 11:
		common.MoveInList(int(url), int(moreData), favoritesFile)
	if mode == 1 or mode == 3 or mode == 10:
		common.SetViewMode('episodes')
else:
	try:
		moduleScript = __import__('resources.lib.{0}'.format(module), fromlist=[module])
		moduleScript.Run(name, url, mode, iconimage, moreData)
	except Exception as ex:
		xbmc.log(str(ex), 3)

xbmcplugin.endOfDirectory(handle)