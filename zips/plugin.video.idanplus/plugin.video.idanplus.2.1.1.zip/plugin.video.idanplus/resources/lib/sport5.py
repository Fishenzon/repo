﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import sys, re, json, urllib, urllib2, urlparse, time
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'sport5'
sortBy = int(Addon.getSetting('{0}SortBy'.format(module)))
vodUrl = 'https://vod.sport5.co.il/'
radioUrl = 'http://radio.sport5.co.il/'
userAgent = common.GetUserAgent()
headers = {"User-Agent": userAgent}
bitrate = Addon.getSetting('{0}_res'.format(module))
if bitrate == '':
	bitrate = 'best'

def GetMainList(iconimage):
	sortString = common.GetLocaleString(30002) if sortBy == 0 else common.GetLocaleString(30003)
	name = "{0}: {1}".format(common.GetLocaleString(30001), sortString)
	common.addDir(name, "toggleSortingMethod", 6, iconimage, {"Title": name, "Plot": "{0}[CR]{1}[CR]{2} / {3}".format(name, common.GetLocaleString(30004), common.GetLocaleString(30002), common.GetLocaleString(30003))}, module=module, isFolder=False)
	name = common.GetLabelColor("כל התכניות", bold=True, color="none")
	common.addDir(name, '', 0, iconimage, infos={"Title": name, "Plot": "צפיה בתכניות מאתר ספורט 5"}, module=module)
	name = common.GetLabelColor("תכניות רדיו", bold=True, color="none")
	common.addDir(name, '', 20, iconimage, infos={"Title": name, "Plot": "צפיה בתכניות רדיו מאתר ספורט 5"}, module=module)

def GetCategories(url='{0}?Vc=147'.format(vodUrl)):
	text = common.OpenURL(url, headers=headers)
	match = re.compile('<div class="navbar big-nav">(.*?)<div id="vb-items-container', re.S).findall(text)
	categories = re.compile('<li>\s*:?<a href="(.*?)".*?>(.*?)</a>|<h3>(.*?)</h3>\s*<ul class="ulToOpen">(.*?)</ul>\s*</div>\s*</li>', re.S).findall(match[0]) if len(match) > 0 else []
	videosSection = re.compile('VideoBrowserItems Start(.*?)VideoBrowserItems Start', re.S).findall(text)[0]
	return categories, videosSection
	
def GetCategoriesList(iconimage):
	categories, videosSection = GetCategories() 
	grids_arr = []
	for link, name1, name2, extra in categories:
		if link != '':
			name = name1
			mode = 3
		else:
			link = name = name2
			mode = 1
		name = common.GetLabelColor(common.UnEscapeXML(name.decode('cp1255')), keyColor="prColor", bold=True)
		grids_arr.append((name, link, mode, iconimage, {"Title": name}))
	
	grids_sorted = grids_arr if sortBy == 0 else sorted(grids_arr,key=lambda grids_arr: grids_arr[0])
	for name, link, mode, icon, infos in grids_sorted:
		common.addDir(name, link, mode, icon, infos=infos, module=module)

def GetSeasonList(url, iconimage):
	categories, videosSection = GetCategories()
	for link, name1, name2, extra in categories:
		if url == name2:
			seasons = re.compile('<li.*?<a href="(.*?)".*?>(.*?)</a>(.*?)</li>', re.S).findall(extra)
			for link, name, extra in seasons:
				name = common.GetLabelColor(name.decode('cp1255'), keyColor="timesColor", bold=True)
				mode = 2 if extra.strip() != '' else 3
				common.addDir(name, link, mode, iconimage, infos={"Title": name}, module=module)
			break

def GetSeriesList(url, iconimage):
	categories, videosSection = GetCategories(url)
	name = re.compile('class="mark">(.*?)</span>', re.S).findall(videosSection)[0].strip()
	name = common.GetLabelColor(common.UnEscapeXML(name.decode('cp1255')), keyColor="prColor", bold=True)
	common.addDir(name, url, 3, iconimage, infos={"Title": name}, module=module)
	for link, name1, name2, extra in categories:
		seasons = re.compile('<li.*?<a href="(.*?)".*?>(.*?)</a>(.*?)</li>', re.S).findall(extra)
		for link, name, extra in seasons:
			if url == link:
				if extra.strip() != '':
					programs = re.compile('<select(.*?)</select>', re.S).findall(extra)
					for program in programs:
						seasions = re.compile("<option url='(.*?)'>(.*?)</option>", re.S).findall(program)
						if len(seasions) > 0:
							title = re.compile('<option>(.*?)</option>', re.S).findall(program)[0].decode('cp1255') + ':'
							common.addDir(title, '', 99, iconimage, infos={"Title": title}, module=module, isFolder=False)
							for seasion in seasions:
								name3 = common.GetLabelColor(seasion[1].decode('cp1255'), keyColor="prColor", bold=True)
								common.addDir(name3, seasion[0], 3, iconimage, infos={"Title": name3}, module=module)
				break

def GetEpisodesList(url, image):
	categories, videosSection = GetCategories(url)
	match = re.compile('<ul id="directions">(.*?)</ul', re.S).findall(videosSection)
	directions = re.compile('<li.*?sort-dir="(.*?)"(.*?)>(.*?)</a>', re.S).findall(match[0]) if len(match) > 0 else ['']
	match = re.compile('<ul class="news-list">(.*?)</ul', re.S).findall(videosSection)
	episodes = re.compile('<li.*?href="(.*?)".*?img src="(.*?)".*?<h3>.*?>(.*?)</a>.*?<p>.*?>(.*?)</a>', re.S).findall(match[0]) if len(match) > 0 else ['']
	pager = re.compile('class="pager" total-pages="(\d*?)" curr-page="(\d*?)" curr-type="(.*?)"(:? | sort-dir="(.*?)" )vc="(.*?)"').findall(videosSection)
	
	if len(pager) > 0:
		pages = int(pager[0][0])
		page = int(pager[0][1])
		link_type = pager[0][2]
		SortDir = 'MO' if pager[0][4] == '' else pager[0][4]
		Vc = pager[0][5]
		for direction, active, name in directions:
			if active == '':
				name = 'מיין לפי: {0}'.format(name.strip().decode('cp1255'))
				mode = 3
				isFolder=True
			else:
				name = 'מיין לפי: {0} (פעיל)'.format(name.strip().decode('cp1255'))
				mode = 99
				isFolder=False
			link = '{0}/Ajax/GetVideos.aspx?Type={1}&Page=1&SortDir={2}&Vc={3}'.format(vodUrl, link_type, direction, Vc)
			common.addDir(name, link, mode, image, {"Title": name}, module=module, isFolder=isFolder)
	
	for link, iconimage, name, desc in episodes:
		name = common.GetLabelColor(common.UnEscapeXML(name.decode('cp1255')), keyColor="chColor")
		desc = common.UnEscapeXML(desc.strip().decode('cp1255'))
		common.addDir(name, link, 4, iconimage, infos={"Title": name, "Plot": desc}, contextMenu=[(common.GetLocaleString(30005), 'RunPlugin({0}?url={1}&name={2}&mode=4&iconimage={3}&moredata=choose&module={4})'.format(sys.argv[0], urllib.quote_plus(link), name, urllib.quote_plus(iconimage), module)), (common.GetLocaleString(30023), 'RunPlugin({0}?url={1}&name={2}&mode=4&iconimage={3}&moredata=set_{4}_res&module={4})'.format(sys.argv[0], urllib.quote_plus(link), name, urllib.quote_plus(iconimage), module))], module=module, moreData=bitrate, isFolder=False, isPlayable=True)
	
	if len(pager) < 1:
		return
	
	pageUrl = '{0}/Ajax/GetVideos.aspx?Type={1}&Page={{0}}&SortDir={2}&Vc={3}'.format(vodUrl, link_type, SortDir, Vc)
	
	if page > 1:
		name = common.GetLabelColor(common.GetLocaleString(30011), color="green")
		common.addDir(name, pageUrl.format(page - 1), 3, image, infos={"Title": name, "Plot": name}, module=module)
	if pages > page:
		name = common.GetLabelColor(common.GetLocaleString(30012), color="green")
		common.addDir(name, pageUrl.format(page + 1), 3, image, infos={"Title": name, "Plot": name}, module=module)
	if pages > 1:
		name = common.GetLabelColor(common.GetLocaleString(30013), color="green")
		common.addDir(name, '{0}?pages={1}'.format(pageUrl, pages), 5, image, infos={"Title": name, "Plot": name}, module=module)

def Play(name, url, iconimage, quality='best'):
	text = common.OpenURL(url, headers=headers)
	match = re.compile('VideoPlayer Start(.*?)VideoPlayer End', re.S).findall(text)
	match = re.compile('iframeVideo.*?src="(.*?)"', re.S).findall(match[0])
	referer = match[0].replace(' ', '%20')
	headers['Referer'] = referer
	match = re.compile('videoUrl=(.*?)&').findall(referer)
	if len(match) > 0:
		link = match[0]
	else:
		match = re.compile('clipId=(.*?)&').findall(referer)
		link = 'https://sport5-vh.akamaihd.net/i/{0}video{1}.csmil/master.m3u8'.format('UEFA/' if '/UCL2017' in referer else '', match[0])
	link = common.GetStreams(link, headers=headers, quality=quality)
	final = '{0}|User-Agent={1}&Referer={2}'.format(link, userAgent, referer)
	common.PlayStream(final, quality, name, iconimage)

def GetRadioData(node='data'):
	headers['Referer'] = radioUrl
	result = common.OpenURL('{0}data/data.json?v={1}'.format(radioUrl, int(time.time() * 1000)), headers=headers)
	return json.loads(result)[node]

def WatchLive(url, name='', iconimage='', quality='best'):
	channels = {
		'5live': {'ch': 'liveurl', 'link': 'https://sport5-lh.akamaihd.net/i/radio5_0@65353/master.m3u8'},
		'5studio': {'ch': 'studioUrl', 'link': 'https://sport5-lh.akamaihd.net/i/radiolivev_0@698733/master.m3u8'}
	}
	link = channels[url]['link']
	try:
		link = GetRadioData(channels[url]['ch'])
	except Exception as ex:
		xbmc.log(str(ex), 3)
	link = common.GetStreams(link, headers=headers, quality=quality)
	final = '{0}|User-Agent={1}&Referer={2}'.format(link, userAgent, radioUrl)
	common.PlayStream(final, quality, name, iconimage)

def GetRadioCategoriesList(iconimage):
	grids_arr = []
	data = GetRadioData()
	for id in data['root']['children']:
		category = data[id]
		name = common.GetLabelColor(category['name'], keyColor="timesColor", bold=True)
		grids_arr.append((name, id, '{0}{1}'.format(radioUrl, category['imageUrl']), {"Title": name}))
	grids_sorted = grids_arr if sortBy == 0 else sorted(grids_arr,key=lambda grids_arr: grids_arr[0])
	for name, link, icon, infos in grids_sorted:
		common.addDir(name, link, 21, icon, infos=infos, module=module)

def GetRadioSeriesList(url):
	grids_arr = []
	data = GetRadioData()
	for id in data[url]['children']:
		serie = data[id]
		name = common.GetLabelColor(serie['name'], keyColor="prColor", bold=True)
		grids_arr.append((name, id, '{0}{1}'.format(radioUrl, serie['imageUrl']), {"Title": name}))
	grids_sorted = grids_arr if sortBy == 0 else sorted(grids_arr,key=lambda grids_arr: grids_arr[0])
	for name, link, icon, infos in grids_sorted:
		common.addDir(name, link, 22, icon, infos=infos, module=module)
		
def GetRadioEpisodesList(url):
	data = GetRadioData()
	for id in data[url]['children']:
		episode = data[id]
		name = common.GetLabelColor(episode['name'], keyColor="chColor")
		desc = episode.get('description', '')
		link = episode['url']
		iconimage = '{0}{1}'.format(radioUrl, episode['imageUrl'])
		common.addDir(name, link, 23, iconimage, infos={"Title": name, "Plot": desc, "Aired": episode['time']}, contextMenu=[(common.GetLocaleString(30005), 'RunPlugin({0}?url={1}&name={2}&mode=4&iconimage={3}&moredata=choose&module={4})'.format(sys.argv[0], urllib.quote_plus(link), name, urllib.quote_plus(iconimage), module)), (common.GetLocaleString(30023), 'RunPlugin({0}?url={1}&name={2}&mode=4&iconimage={3}&moredata=set_{4}_res&module={4})'.format(sys.argv[0], urllib.quote_plus(link), name, urllib.quote_plus(iconimage), module))], module=module, moreData=bitrate, isFolder=False, isPlayable=True)

def PlayRadioEpisode(name, url, iconimage, quality='best'):
	link = common.GetStreams(url, headers=headers, quality=quality)
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == -1:
		GetMainList(iconimage)
	elif mode == 0:		
		GetCategoriesList(iconimage)
	elif mode == 1:
		GetSeasonList(url, iconimage)					
	elif mode == 2:
		GetSeriesList(url, iconimage)
	elif mode == 3:
		GetEpisodesList(url, iconimage)
	elif mode == 4:
		Play(name, url, iconimage, moreData)
	elif mode == 5:
		url, pages = url.split('?pages=')
		page = common.GetIndexFromUser(name, pages)
		url = url.format(page)
		GetEpisodesList(url, iconimage)
	elif mode == 6:
		common.ToggleSortMethod('{0}SortBy'.format(module), sortBy)
	elif mode == 10:
		WatchLive(url, name, iconimage, moreData)
	elif mode == 20:
		GetRadioCategoriesList(iconimage)
	elif mode == 21:
		GetRadioSeriesList(url)
	elif mode == 22:
		GetRadioEpisodesList(url)
	elif mode == 23:
		PlayRadioEpisode(name, url, iconimage, moreData)
		
	common.SetViewMode('episodes')
