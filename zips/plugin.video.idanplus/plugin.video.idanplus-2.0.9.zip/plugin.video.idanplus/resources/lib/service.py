import xbmc

refreshCommand = 'XBMC.RunPlugin(plugin://plugin.video.idanplus/?mode=7)'
xbmc.executebuiltin(refreshCommand)
xbmc.executebuiltin('XBMC.AlarmClock({0},{1},{2},silent)'.format('idanplus', refreshCommand, 720))