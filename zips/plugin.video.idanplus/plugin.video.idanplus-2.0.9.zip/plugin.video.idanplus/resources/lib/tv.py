﻿# -*- coding: utf-8 -*-
import xbmcaddon
import sys, re
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'tv'
userAgent = common.GetUserAgent()

def WatchLive(url, name='', iconimage='', quality='best'):
	channels = {
		'2news': { 'link': 'http://ch2live-i.akamaihd.net/hls/live/252343/252343/playlist.m3u8'},
		'891fm': { 'link': 'https://www.oles.tv/891fm/player/', 'regex': "streamSource\s*=\s*'(.*?)'"},
	}
	headers={"User-Agent": userAgent}
	regex = channels[url].get('regex')
	if regex:
		text = common.OpenURL(channels[url]['link'], headers=headers)
		link = re.compile(regex).findall(text)[0]
	else:
		link = channels[url]['link']
	link = common.GetStreams(link, headers=headers, quality=quality)
	common.PlayStream('{0}|User-Agent={1}'.format(link, userAgent), quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 10:
		WatchLive(url, name, iconimage, moreData)
		
	common.SetViewMode('episodes')