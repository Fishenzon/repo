﻿# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import sys, re, json, urllib, urllib2
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'glz'
apiUrl = 'https://glz.co.il/umbraco/api/'
userAgent = common.GetUserAgent()
headers = {"User-Agent": userAgent}
channels = {
		'glz': {'rootId': '1051', 'live': 'http://glzwizzlv.bynetcdn.com/glz_mp3?awCollectionId=misc&awEpisodeId=glz'},
		'glglz': {'rootId': '1920', 'live': 'http://glzwizzlv.bynetcdn.com/glglz_mp3?awCollectionId=misc&awEpisodeId=glglz'}
	}

class SmartRedirectHandler(urllib2.HTTPRedirectHandler):
	def http_error_301(self, req, fp, code, msg, headers):
		result = urllib2.HTTPRedirectHandler.http_error_301(self, req, fp, code, msg, headers)
		return result

	def http_error_302(self, req, fp, code, msg, headers):
		result = urllib2.HTTPRedirectHandler.http_error_302(self, req, fp, code, msg, headers)
		return result

def WatchLive(url, name='', iconimage='', quality='best'):
	link = channels[url]['live']
	try:
		url = '{0}player/getplayerdata?rootId={1}'.format(apiUrl, channels[url]['rootId'])
		text = common.OpenURL(url, headers=headers)
		data = json.loads(text)
		req = urllib2.Request(data['liveBroadcast']['fileUrl'], headers=headers)
		opener = urllib2.build_opener(SmartRedirectHandler())
		res = opener.open(req)
		link = res.url
	except Exception as ex:
		xbmc.log(str(ex), 3)
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 11:
		WatchLive(url, name, iconimage, moreData)
		
	common.SetViewMode('episodes')