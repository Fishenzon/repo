# -*- coding: utf-8 -*-
import sys, os, urlparse, urllib, datetime
import xbmc, xbmcplugin, xbmcaddon
import resources.lib.common as common
import resources.lib.epg as epg

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
imagesDir = xbmc.translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources', 'images')).decode("utf-8")

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
url = urllib.unquote_plus(params.get('url', ''))
mode = int(params.get('mode','-1'))
name = urllib.unquote_plus(params.get('name', ''))
iconimage = urllib.unquote_plus(params.get('iconimage', ''))
module = params.get('module')
moreData = urllib.unquote_plus(params.get('moredata', ''))

def GetCategoriesList():
	name = common.GetLabelColor("שידורים חיים", bold=True, color="none")
	common.addDir(name, '', 1, icon, {"Title": name})
	name = common.GetLabelColor("VOD", bold=True, color="none")
	common.addDir(name, '', 2, icon, {"Title": name})
	name = common.GetLabelColor("רדיו", bold=True, color="none")
	common.addDir(name, '', 3, icon, {"Title": name})
	name = common.GetLabelColor("תכניות רדיו", bold=True, color="none")
	common.addDir(name, '', 21, icon, {"Title": name}, module='kan')
	name = common.GetLabelColor("הגדרות", bold=True, color="none")
	common.addDir(name, '', 6, icon, {"Title": name})

def LiveChannels():
	nowEPG = epg.GetNowEPG()
	channels = [{'ch': 'ch_11', 'index': 1}, {'ch': 'ch_12', 'index': 2}, {'ch': 'ch_13', 'index': 3}, {'ch': 'ch_14', 'index': 4}, {'ch': 'ch_20', 'index': 5}, {'ch': 'ch_21', 'index': 6}, {'ch': 'ch_23', 'index': 7}, {'ch': 'ch_24', 'index': 8}, {'ch': 'ch_bb', 'index': 9}, {'ch': 'ch_33', 'index': 10}, {'ch': 'ch_66', 'index': 11}, {'ch': 'ch_97', 'index': 12}, {'ch': 'ch_99', 'index': 13}, {'ch': 'ch_2news2', 'index': 14}, {'ch': 'ch_2news', 'index': 14}, {'ch': 'ch_ynet', 'index': 15}, {'ch': 'ch_walla', 'index': 16}, {'ch': 'ch_keshetBest', 'index': 19}, {'ch': 'ch_refresh', 'index': 100}]
	for channel in channels:
		channel['index'] = common.GetIntSetting(channel['ch'], channel['index'])
	channels = sorted(channels, key=lambda k: k['index']) 
	for channel in channels:
		if channel['index'] == 0:
			continue
		ch = channel['ch']
		if ch == 'ch_11': LiveChannel(common.GetLocaleString(30602), '11', 10, os.path.join(imagesDir, "kan.jpg"), 'kan', resKey='ch_11_res', programs=nowEPG.get('11', []))
		elif ch == 'ch_12': LiveChannel(common.GetLocaleString(30603), '12', 10, os.path.join(imagesDir, "keshet.jpg"), 'keshet', resKey='ch_12_res', programs=nowEPG.get('12', []))
		elif ch == 'ch_13': LiveChannel(common.GetLocaleString(30604), '13', 4, os.path.join(imagesDir, "13.png"), 'reshet', resKey='ch_13_res', programs=nowEPG.get('13', []))
		elif ch == 'ch_14': LiveChannel(common.GetLocaleString(30605), '14', 6, os.path.join(imagesDir, "ten.png"), 'ten', resKey='ch_14_res', programs=nowEPG.get('14', []))
		elif ch == 'ch_20': LiveChannel(common.GetLocaleString(30606), '20', 10, os.path.join(imagesDir, "20.png"), 'twenty', resKey='ch_20_res', programs=nowEPG.get('20', []))
		elif ch == 'ch_21': LiveChannel(common.GetLocaleString(30619), '21', 10, os.path.join(imagesDir, "21tv.jpg"), '21tv', resKey='ch_21_res', programs=nowEPG.get('21', []))
		elif ch == 'ch_23': LiveChannel(common.GetLocaleString(30607), '23', 10, os.path.join(imagesDir, "23tv.jpg"), 'kan', resKey='ch_23_res', programs=nowEPG.get('23', []))
		elif ch == 'ch_24': LiveChannel(common.GetLocaleString(30608), '24', 10, os.path.join(imagesDir, "24.jpg"), 'keshet', resKey='ch_24_res', programs=nowEPG.get('24', []))
		elif ch == 'ch_bb': LiveChannel(common.GetLocaleString(30621), 'bb', 4, os.path.join(imagesDir, "bb.jpg"), 'reshet', resKey='ch_bb_res')
		elif ch == 'ch_33': LiveChannel(common.GetLocaleString(30609), '33', 10, os.path.join(imagesDir, "makan.png"), 'kan', resKey='ch_33_res', programs=nowEPG.get('33', []))
		elif ch == 'ch_66': LiveChannel(common.GetLocaleString(30610), '66', 10, os.path.join(imagesDir, "kabbalah.jpg"), 'kabbalah', resKey='cch_66_res', programs=nowEPG.get('66', []))
		elif ch == 'ch_97': LiveChannel(common.GetLocaleString(30612), '97', 10, os.path.join(imagesDir, "hidabroot.jpg"), 'hidabroot', resKey='ch_97_res', programs=nowEPG.get('97', []))
		elif ch == 'ch_99': LiveChannel(common.GetLocaleString(30613), '99', 10, os.path.join(imagesDir, "knesset.png"), 'knesset', resKey='ch_99_res', programs=nowEPG.get('99', []))
		elif ch == 'ch_2news2': LiveChannel(common.GetLocaleString(30625), '2news', 10, os.path.join(imagesDir, "2news.jpg"), 'tv', resKey='ch_2news2_res')
		elif ch == 'ch_2news': LiveChannel(common.GetLocaleString(30620), 'news', 4, os.path.join(imagesDir, "2news.jpg"), 'reshet', resKey='ch_2news_res')
		elif ch == 'ch_ynet': LiveChannel(common.GetLocaleString(30622), 'live', 10, os.path.join(imagesDir, "ynet.jpg"), 'ynet', resKey='ch_ynet_res')
		elif ch == 'ch_walla': LiveChannel(common.GetLocaleString(30624), 'live', 10, os.path.join(imagesDir, "wallanews.png"), 'walla', resKey='ch_walla_res')
		elif ch == 'ch_keshetBest': LiveChannel(common.GetLocaleString(30617), 'keshetBest', 10, os.path.join(imagesDir, "keshet_best.jpg"), 'keshet', resKey='ch_keshetBest_res')
		elif ch == 'ch_refresh':
			name = common.GetLabelColor(common.GetLocaleString(30618), bold=True, color="none")
			common.addDir(name, '', 4, icon, infos={"Title": name}, isFolder=False)

def LiveChannel(name, url, mode, iconimage, module, choose=True, resKey='', programs=[]):
	channelNameFormat = int(Addon.getSetting("channelNameFormat"))
	displayName = common.GetLabelColor(name, keyColor="chColor", bold=True)
	description = ''
	contextMenu = []
	if len(programs) > 0:
		contextMenu.insert(0, ('EPG', 'Container.Update({0}?url={1}&name={2}&mode=2&iconimage={3}&module=epg)'.format(sys.argv[0], url, urllib.quote_plus(name), urllib.quote_plus(iconimage))))
		programTime = common.GetLabelColor("[{0}-{1}]".format(datetime.datetime.fromtimestamp(programs[0]["start"]).strftime('%H:%M'), datetime.datetime.fromtimestamp(programs[0]["end"]).strftime('%H:%M')), keyColor="timesColor")
		programName = common.GetLabelColor(programs[0]["name"].encode('utf-8'), keyColor="prColor", bold=True)
		displayName = getChannelName(programName, programTime, displayName, channelNameFormat)
		description = '{0}[CR]{1}'.format(programName, programs[0]["description"].encode('utf-8'))
		if len(programs) > 1:
			nextProgramName = common.GetLabelColor(programs[1]["name"].encode('utf-8'), keyColor="prColor", bold=True)
			nextProgramTime = common.GetLabelColor("[{0}-{1}]".format(datetime.datetime.fromtimestamp(programs[1]["start"]).strftime('%H:%M'), datetime.datetime.fromtimestamp(programs[1]["end"]).strftime('%H:%M')), keyColor="timesColor")
			description = getDescription(description, nextProgramTime, nextProgramName, channelNameFormat)
	if resKey == '':
		bitrate = 'best'
	else:
		bitrate = Addon.getSetting(resKey)
		if bitrate == '':
			bitrate = 'best'
		contextMenu.insert(0, (common.GetLocaleString(30023), 'RunPlugin({0}?url={1}&name={2}&mode={3}&iconimage={4}&moredata=set_{5}&module={6})'.format(sys.argv[0], url, urllib.quote_plus(displayName), mode, urllib.quote_plus(iconimage), resKey, module)))
	if choose:
		contextMenu.insert(0, (common.GetLocaleString(30005), 'RunPlugin({0}?url={1}&name={2}&mode={3}&iconimage={4}&moredata=choose&module={5})'.format(sys.argv[0], url, urllib.quote_plus(displayName), mode, urllib.quote_plus(iconimage), module)))
	if contextMenu == []:
		contextMenu = None
	common.addDir(displayName, url, mode, iconimage, infos={"Title": displayName, "Plot": description}, contextMenu=contextMenu, moreData=bitrate, module=module, isFolder=False, isPlayable=True)

def getChannelName(programName, programTime, displayName, channelNameFormat):
	if channelNameFormat == 0:
		chName = " {0} - {1} {2} ".format(displayName, programName, programTime)
	elif channelNameFormat == 1:
		chName = " {0}  {1}  {2} ".format(displayName, programTime, programName)
	elif channelNameFormat == 2:
		chName = " {0} {1} - {2} ".format(programTime, programName, displayName)
	elif channelNameFormat == 3:
		chName = "  {0}  {1}  {2} ".format(programName, programTime, displayName)
	return chName
	
def getDescription(description, nextProgramTime, nextProgramName, channelNameFormat):
	if channelNameFormat == 0 or channelNameFormat == 1:
		description = ' {0}[CR][CR]{1} {2} '.format(description, nextProgramTime, nextProgramName)
	elif channelNameFormat == 2 or channelNameFormat == 3:
		description = ' {0}[CR][CR]{1} {2} '.format(description, nextProgramName, nextProgramTime)
	return description

def VODs():
	name = 'כאן 11'
	common.addDir(name, '', 0, os.path.join(imagesDir, "kan.jpg"), infos={"Title": name}, module='kan')
	name = 'קשת 12'
	common.addDir(name, '', 0, os.path.join(imagesDir, "mako.png"), infos={"Title": name}, module='keshet')
	name = 'רשת 13'
	common.addDir(name, '', -1, os.path.join(imagesDir, "13.png"), infos={"Title": name}, module='reshet')
	name = 'עשר 14'
	common.addDir(name, '', 0, os.path.join(imagesDir, "ten.png"), infos={"Title": name}, module='ten')
	name = 'מורשת 20'
	common.addDir(name, '', -1, os.path.join(imagesDir, "20.png"), infos={"Title": name}, module='twenty')

def Radios():
	nowEPG = epg.GetNowEPG()
	channels = [{'ch': 'rd_glglz', 'index': 1}, {'ch': 'rd_88', 'index': 2}, {'ch': 'rd_90', 'index': 3}, {'ch': 'rd_97', 'index': 4}, {'ch': 'rd_99', 'index': 5}, {'ch': 'rd_100', 'index': 6}, {'ch': 'rd_101', 'index': 7}, {'ch': 'rd_1015', 'index': 8}, {'ch': 'rd_102', 'index': 9}, {'ch': 'rd_102Eilat', 'index': 10}, {'ch': 'rd_103', 'index': 11}, {'ch': 'rd_1045', 'index': 12}, {'ch': 'rd_1075', 'index': 13}, {'ch': 'rd_glz', 'index': 14}, {'ch': 'rd_bet', 'index': 15}, {'ch': 'rd_gimel', 'index': 16}, {'ch': 'rd_culture', 'index': 17}, {'ch': 'rd_music', 'index': 18}, {'ch': 'rd_moreshet', 'index': 19}, {'ch': 'rd_reka', 'index': 20}, {'ch': 'rd_makan', 'index': 21}, {'ch': 'rd_persian', 'index': 22}, {'ch': 'rd_80_90', 'index': 23}, {'ch': 'rd_alt', 'index': 24}, {'ch': 'rd_classic', 'index': 25}, {'ch': 'rd_hits', 'index': 26}, {'ch': 'rd_nos', 'index': 27}, {'ch': 'rd_regesh', 'index': 28}, {'ch': 'rd_oriental', 'index': 29}, {'ch': 'rd_refresh', 'index': 100}]
	for channel in channels:
		channel['index'] = common.GetIntSetting(channel['ch'], channel['index'])
	channels = sorted(channels, key=lambda k: k['index']) 
	for channel in channels:
		if channel['index'] == 0:
			continue
		ch = channel['ch']
		if ch == 'rd_glglz': LiveChannel(common.GetLocaleString(30702), 'glglz', 11, os.path.join(imagesDir, "glglz.jpg"), 'glz', choose=False, programs=nowEPG.get('glglz', []))
		elif ch == 'rd_88': LiveChannel(common.GetLocaleString(30703), '88', 11, os.path.join(imagesDir, "88.png"), 'kan', choose=False, programs=nowEPG.get('88', []))
		elif ch == 'rd_90': LiveChannel(common.GetLocaleString(30724), '90fm', 11, os.path.join(imagesDir, "90fm.jpg"), 'radio', choose=False, programs=nowEPG.get('90fm', []))
		elif ch == 'rd_97': LiveChannel(common.GetLocaleString(30725), '97fm', 11, os.path.join(imagesDir, "97fm.jpg"), 'radio', choose=False, programs=nowEPG.get('97fm', []))
		elif ch == 'rd_99': LiveChannel(common.GetLocaleString(30704), '99fm', 11, os.path.join(imagesDir, "99fm.png"), '99fm', choose=False, programs=nowEPG.get('99fm', []))
		elif ch == 'rd_100': LiveChannel(common.GetLocaleString(30726), '100fm', 11, os.path.join(imagesDir, "100fm.jpg"), 'radio', choose=False, programs=nowEPG.get('100fm', []))
		elif ch == 'rd_101': LiveChannel(common.GetLocaleString(30727), '101fm', 11, os.path.join(imagesDir, "101fm.png"), 'radio', choose=False, programs=nowEPG.get('101fm', []))
		elif ch == 'rd_1015': LiveChannel(common.GetLocaleString(30728), '1015fm', 11, os.path.join(imagesDir, "1015fm.jpg"), 'radio', choose=False, programs=nowEPG.get('1015fm', []))
		elif ch == 'rd_102': LiveChannel(common.GetLocaleString(30705), '102fm', 11, os.path.join(imagesDir, "102fm.jpg"), 'radio', choose=False, programs=nowEPG.get('102fm', []))
		elif ch == 'rd_102Eilat': LiveChannel(common.GetLocaleString(30729), '102fmEilat', 11, os.path.join(imagesDir, "102fmEilat.jpg"), 'radio', choose=False, programs=nowEPG.get('102fmEilat', []))
		elif ch == 'rd_103': LiveChannel(common.GetLocaleString(30706), '103fm', 11, os.path.join(imagesDir, "103fm.png"), 'radio', choose=False, programs=nowEPG.get('103fm', []))
		elif ch == 'rd_1045': LiveChannel(common.GetLocaleString(30730), '1045fm', 11, os.path.join(imagesDir, "1045fm.jpg"), 'radio', choose=False, programs=nowEPG.get('1045fm', []))
		elif ch == 'rd_1075': LiveChannel(common.GetLocaleString(30731), '1075fm', 11, os.path.join(imagesDir, "1075fm.jpg"), 'radio', choose=False, programs=nowEPG.get('1075fm', []))
		elif ch == 'rd_glz': LiveChannel(common.GetLocaleString(30707), 'glz', 11, os.path.join(imagesDir, "glz.jpg"), 'glz', choose=False, programs=nowEPG.get('glz', []))
		elif ch == 'rd_bet': LiveChannel(common.GetLocaleString(30708), 'bet', 11, os.path.join(imagesDir, "bet.png"), 'kan', choose=False, programs=nowEPG.get('bet', []))
		elif ch == 'rd_gimel': LiveChannel(common.GetLocaleString(30709), 'gimel', 11, os.path.join(imagesDir, "gimel.png"), 'kan', choose=False, programs=nowEPG.get('gimel', []))
		elif ch == 'rd_culture': LiveChannel(common.GetLocaleString(30710), 'culture', 11, os.path.join(imagesDir, "culture.png"), 'kan', choose=False, programs=nowEPG.get('culture', []))
		elif ch == 'rd_music': LiveChannel(common.GetLocaleString(30711), 'music', 11, os.path.join(imagesDir, "music.png"), 'kan', choose=False, programs=nowEPG.get('music', []))
		elif ch == 'rd_moreshet': LiveChannel(common.GetLocaleString(30712), 'moreshet', 11, os.path.join(imagesDir, "moreshet.png"), 'kan', choose=False, programs=nowEPG.get('moreshet', []))
		elif ch == 'rd_reka': LiveChannel(common.GetLocaleString(30713), 'reka', 11, os.path.join(imagesDir, "reka.png"), 'kan', choose=False, programs=nowEPG.get('reka', []))
		elif ch == 'rd_makan': LiveChannel(common.GetLocaleString(30714), 'makan', 11, os.path.join(imagesDir, "makan.png"), 'kan', choose=False, programs=nowEPG.get('makan', []))
		elif ch == 'rd_persian': LiveChannel(common.GetLocaleString(30715), 'persian', 11, os.path.join(imagesDir, "persian.png"), 'kan', choose=False, programs=nowEPG.get('persian', []))
		elif ch == 'rd_80_90': LiveChannel(common.GetLocaleString(30716), '80-90', 11, os.path.join(imagesDir, "80_90.png"), 'kan', choose=False)
		elif ch == 'rd_alt': LiveChannel(common.GetLocaleString(30717), 'alt', 11, os.path.join(imagesDir, "alt.png"), 'kan', choose=False)
		elif ch == 'rd_classic': LiveChannel(common.GetLocaleString(30718), 'classic', 11, os.path.join(imagesDir, "classic.png"), 'kan', choose=False)
		elif ch == 'rd_hits': LiveChannel(common.GetLocaleString(30719), 'hits', 11, os.path.join(imagesDir, "hits.png"), 'kan', choose=False)
		elif ch == 'rd_nos': LiveChannel(common.GetLocaleString(30720), 'nos', 11, os.path.join(imagesDir, "nos.png"), 'kan', choose=False)
		elif ch == 'rd_regesh': LiveChannel(common.GetLocaleString(30721), 'regesh', 11, os.path.join(imagesDir, "regesh.png"), 'kan', choose=False)
		elif ch == 'rd_oriental': LiveChannel(common.GetLocaleString(30722), 'oriental', 11, os.path.join(imagesDir, "oriental.png"), 'kan', choose=False)
		elif ch == 'rd_refresh':
			name = common.GetLabelColor(common.GetLocaleString(30723), bold=True, color="none")
			common.addDir(name, '', 4, icon, infos={"Title": name}, isFolder=False)

if module is None:
	if mode == -1:
		GetCategoriesList()
	elif mode == 1:
		LiveChannels()
	elif mode == 2:
		VODs()
	elif mode == 3:
		Radios()
	elif mode == 4:
		xbmc.executebuiltin("Container.Refresh()")
	elif mode == 5:
		epg.GetEPG(deltaInSec=0)
	elif mode == 6:
		Addon.openSettings()
		sys.exit()
	if mode == 1 or mode == 3:
		common.SetViewMode('episodes')
else:
	try:
		moduleScript = __import__('resources.lib.{0}'.format(module), fromlist=[module])
		moduleScript.Run(name, url, mode, iconimage, moreData)
	except Exception as ex:
		xbmc.log(str(ex), 3)

xbmcplugin.endOfDirectory(handle)