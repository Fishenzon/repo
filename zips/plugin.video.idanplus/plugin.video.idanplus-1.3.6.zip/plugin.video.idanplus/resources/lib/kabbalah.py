﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import sys, re, json, urllib, urllib2, urlparse
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = 'kabbalah'
userAgent = common.GetUserAgent()

def WatchLive(name='', iconimage='', quality='best'):
	headers={"User-Agent": userAgent}
	text = common.OpenURL('http://www.kab.co.il/kabbalah/%D7%98%D7%9C%D7%95%D7%95%D7%99%D7%96%D7%99%D7%94', headers=headers)
	match = re.compile('sources: \[(.*?)\]', re.S).findall(text)
	match = re.compile("file:\s*?'(.*?)'").findall(match[0])
	link = common.GetStreams(match[0], headers=headers, quality=quality)
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 10:
		WatchLive(name, iconimage, moreData)
		
	common.SetViewMode('episodes')