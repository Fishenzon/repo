# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import sys, os, io, random, re, json, urllib, shutil, time

try:
	# For Python 3.0 and later
	import urllib.parse as urlparse
	py2 = False
except ImportError:
	# Fall back to Python 2
	py2 = True
	import urlparse

AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
AddonVer = Addon.getAddonInfo('version')
AddonName = "Idan Plus"

def decode(text, dec, force=False):
	if py2:
		text = text.decode(dec)
	elif force:
		text= bytearray(text, 'utf-8').decode(dec)
	return text

def encode(text, dec):
	if py2:
		text = text.encode(dec)
	return text

def translatePath(path):
	if py2:
		text = xbmc.translatePath(path)
	else:
		import xbmcvfs
		text = xbmcvfs.translatePath(path)
	return text

resourcesDir = decode(translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources')), "utf-8")
profileDir = decode(translatePath(Addon.getAddonInfo("profile")), "utf-8")
if not os.path.exists(profileDir):
	os.makedirs(profileDir)

iconKan = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/kan.jpg'
iconKan23 = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/23tv.jpg'
iconKeshet = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/mako.png'
iconReshet = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/13tv.jpg'
icon14tv = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/14tv.png'
icon24tv = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/24tv.jpg'
iconI24news = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/i24news.png'
icon9tv = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/9tv.png'
iconSport5 = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/Sport5.png'
icon99fm = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/99fm.png'
iconGlglz = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/glglz.jpg'
icon100fm = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/100fm.jpg'
icon891fm = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/891fm.png'
icon1064fm = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/1064fm.jpg'
iconSport1 = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/images/sport1.jpg'

epgFile = os.path.join(profileDir, 'epg.json')
seriesFile = os.path.join(profileDir, 'series.json')
seriesUrl = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/series.json.zip'
youtubePlugin = 'plugin://plugin.video.youtube'
displayChannelsFile = os.path.join(profileDir, 'displayChannels.json')
channelsLogosDir = os.path.join(profileDir, 'logos', 'channels')
if not os.path.exists(channelsLogosDir):
    os.makedirs(channelsLogosDir)

userAgents = [
	# Windows (Chrome, Edge, Firefox)
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36 Edg/127.0.2651.74',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0',
	'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 OPR/112.0.0.0',
	
	# macOS (Chrome, Safari, Firefox)
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
	'Mozilla/5.0 (Macintosh; Intel Mac OS X 14.5; rv:128.0) Gecko/20100101 Firefox/128.0',
	
	# Linux
	'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0',
	
	# Mobile - iOS (iPhone / iPad)
	'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
	'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/128.0.6613.99 Mobile/15E148 Safari/604.1',
	'Mozilla/5.0 (iPad; CPU OS 17_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
	
	# Mobile - Android
	'Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.88 Mobile Safari/537.36',
	'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.88 Mobile Safari/537.36',
	'Mozilla/5.0 (Linux; Android 14; SAMSUNG SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/25.0 Chrome/121.0.0.0 Mobile Safari/537.36',
	'Mozilla/5.0 (Android 14; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0'
]
userAgent = random.choice(userAgents)


def GetAddon():
	Addon = xbmcaddon.Addon(AddonID)
	return Addon

def GetAddonSetting(key):
	value = Addon.getSetting(key)
	if '_res' in key:
		if value == '':
			value = 'best'
	return value

def SetAddonSetting(key, value):
	Addon.setSetting(key, value)

def GetHandle():
	try:
		handle = int(sys.argv[1])
	except:
		handle = -1
	return handle

def GetKodiVer():
	return float(re.split(' |\-',xbmc.getInfoLabel('System.BuildVersion'))[0])

def NewerThanPyVer(ver):
	runnigVer = ver.split('.')
	for i in range(len(runnigVer)):
		if sys.version_info[i] > int(runnigVer[i]):
			return True
	return False

def IsAddonInstalled(addonid):
	return xbmc.getCondVisibility('System.HasAddon({0})'.format(addonid)) == 1

def InstallAddon(addonid):
	xbmc.executebuiltin('InstallAddon({0})'.format(addonid))

def IsAddonEnabled(addonid):
	return json.loads(xbmc.executeJSONRPC('{{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{{"addonid":"{0}", "properties": ["enabled"]}},"id":1}}'.format(addonid)))['result']['addon']['enabled']

def EnableAddon(addonid):
	if GetKodiVer() >= 19:
		xbmc.executebuiltin('EnableAddon({0})'.format(addonid))
	else:
		xbmc.executeJSONRPC('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":true}},"id":1}}'.format(addonid))

def DisableAddon(addonid):
	xbmc.executeJSONRPC('{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{{"addonid":"{0}","enabled":false}},"id":1}}'.format(addonid))

def GetTextFile(filename):
	content = ''
	if os.path.isfile(filename):
		with io.open(filename, 'r', encoding="utf-8") as f:
			content = f.read()
	return content

def ReadList(fileName):
	import collections
	try:
		with io.open(fileName, 'r', encoding='utf-8') as f:
			content = json.load(f, object_pairs_hook=collections.OrderedDict) if NewerThanPyVer('2.6.99') else json.load(f)
	except Exception as ex:
		xbmc.log(str(ex), xbmc.LOGERROR)
		content=[]
	return content

def WriteList(filename, list):
	try:
		with io.open(filename, 'w', encoding='utf-8') as f:
			f.write(uni_code(json.dumps(list, indent='\t', ensure_ascii=False)))
		success = True
	except Exception as ex:
		xbmc.log(str(ex), xbmc.LOGERROR)
		success = False
	return success

def isFileOld(filename, deltaInSec=86400):
	import time
	lastUpdate = 0 if not os.path.isfile(filename) else int(os.path.getmtime(filename))
	return (time.time() - lastUpdate) > deltaInSec

def GetUserAgent():
	return userAgent

def GetSession():
	import requests
	return requests.session()

def OpenURL(url, headers={}, user_data=None, session=None, cookies=None, retries=1, responseMethod='text', verify=True):
	link = ""
	import requests
	if headers.get('Accept-encoding', '') == '':
		headers['Accept-encoding'] = 'gzip'
	if headers.get('User-Agent', '') == '':
		headers['User-Agent'] = userAgent
	for i in range(retries):
		try:
			if session is None:
				if user_data is None:
					response = requests.get(url, headers=headers, cookies=cookies, verify=verify)
				else:
					response = requests.post(url, headers=headers, cookies=cookies, data=user_data, verify=verify)
			else:
				if user_data is None:
					response = session.get(url, headers=headers, cookies=cookies, verify=verify)
				else:
					response = session.post(url, data=user_data, headers=headers, cookies=cookies, verify=verify)
			if responseMethod == 'text':
				if int(response.status_code) > 400:
					xbmc.log('{0}  -  response {1}.'.format(url, response.status_code), xbmc.LOGERROR)
					continue
				link = response.text
			elif responseMethod == 'content':
				link = response.content
			elif responseMethod == 'json':
				link = response.json()
			break
		except Exception as ex:
			xbmc.log(str(ex), xbmc.LOGERROR)
			return None
	return link

def GetRedirect(url, headers={}):
	try:
		import requests
		response = requests.head(url, headers=headers, allow_redirects=False)
		if response.status_code in set([301, 302, 303, 307]) and 'location' in response.headers:
			url = response.headers['location']
		if response.status_code >= 400 and response.status_code < 500:
			url = None
	except Exception as ex:
		xbmc.log(str(ex), xbmc.LOGERROR)
	return url

def addDir(name, url, mode, iconimage='DefaultFolder.png', infos=None, contextMenu=None, module='', moreData='', totalItems=None, isFolder=True, isPlayable=False, addFav=True, urlParamsData={}, arts=None, noResume=False):
	urlParams = {'name': name.replace('?', '|||'), 'url': quote_plus(url), 'mode': mode, 'iconimage': quote_plus(iconimage), 'module': module, 'moredata': quote_plus(moreData)}
	u = '{0}?{1}'.format(sys.argv[0], urlencode(urlParams))
	try:
		listitem = xbmcgui.ListItem(name)
		art = {'thumb': iconimage, 'fanart': iconimage, 'icon': iconimage}
		if arts:
			art.update(arts)
		listitem.setArt(art)
	except:
		listitem = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
	if infos is not None:
		setInfo(listitem, infos)
	if isPlayable:
		listitem.setProperty("IsPlayable", "true")
	if noResume and GetKodiVer() >= 20:
		# an explicit resume point (time 0, a length) on the row: a click is then not asked "Resume from ... / Play from beginning", which Kodi does for a row without
		# one whenever its video database holds a bookmark for the row's url (VideoUtils.cpp GetNonFolderItemResumeInformation). The play route resumes by the addon's own record.
		listitem.getVideoInfoTag().setResumePoint(0.0, 1.0)
	for param in list(urlParamsData.keys()):
		urlParams[param] = urlParamsData[param].replace('?', '|||')
	if addFav:
		urlParams['isFolder'] = isFolder
		urlParams['isPlayable'] = isPlayable
		item = (GetLocaleString(30026), 'RunPlugin({0}?url={1}&mode=8)'.format(sys.argv[0], quote_plus(urlencode(urlParams))))
		if contextMenu is None:
			contextMenu = [item]
		else:
			contextMenu.append(item)
	item = (GetLocaleString(32004), 'RunPlugin({0}?mode=16)'.format(sys.argv[0]))
	if contextMenu is None:
		contextMenu = [item]
	else:
		contextMenu.append(item)
	if contextMenu is not None:
		listitem.addContextMenuItems(items=contextMenu)
	handle = GetHandle()
	if totalItems is None:
		xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=listitem, isFolder=isFolder)
	else:
		xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=listitem, isFolder=isFolder, totalItems=totalItems)

def DelFile(aFile):
	try:
		if os.path.isfile(aFile):
			os.unlink(aFile)
	except Exception as ex:
		xbmc.log(str(ex), xbmc.LOGERROR)

def DelCookies():
	tempDir = decode(translatePath('special://temp/'), "utf-8")
	for the_file in os.listdir(tempDir):
		if not '.fi' in the_file and the_file != 'cookies.dat':
			continue
		DelFile(os.path.join(tempDir, the_file))

def GetStreams(url, headers={}, user_data=None, session=None, retries=1, quality='best', strict=False):
	"""The stream url for `quality` read from the master playlist at `url`. With `strict` a playlist that comes back EMPTY (a CDN can answer
	HTTP 200 with no body) gives None instead of `url`, so the caller can try another CDN; without it the old behaviour is kept for every other caller."""
	if quality.startswith('set'):
		addonKey = quality[4:]
		quality = 'set'
	base = urlparse.urlparse(url)
	baseUrl = '{0}://{1}{2}'.format(base.scheme, base.netloc, base.path)
	text = OpenURL(url, headers=headers, user_data=user_data, session=session, retries=retries)
	if text is None:
		return url
	if strict and not text.strip():
		return None
	resolutions = [x for x in re.compile('^#EXT-X-STREAM-INF:.*?BANDWIDTH=(\d+)(.*?)\n(.*?)$', re.M).findall(text)]
	resolutions = sorted(resolutions,key=lambda resolutions: int(resolutions[0]), reverse=True)
	link = url
	if quality == 'best':
		for resolution in resolutions:
			link = resolution[2].strip()
			if not link.startswith('http'): 
				link = urlparse.urljoin(baseUrl, link)
				if base.query != '':
					link = '{0}?{1}'.format(link, base.query)
			check = OpenURL(link, headers=headers, user_data=user_data, session=session, retries=retries)
			if check is not None:
				break
	elif quality == 'choose' or quality == 'set':
		if quality == 'set':
			resolutions.insert(0, (GetLocaleString(30024), '', ''))
		resNames = []
		for item in resolutions:
			resNames.append(item[0]) 
			if 'RESOLUTION' in item[1]:
				resNames[-1] += '  [{0}]'.format(re.compile('RESOLUTION=(\d+)x(\d+)').findall(item[1])[0][1])
			elif 'NAME' in item[1]:
				resNames[-1] += '  [{0}]'.format(re.compile('NAME="(.*?)"').findall(item[1])[0])
		qualityInd = xbmcgui.Dialog().select(GetLocaleString(30005), resNames)
		if qualityInd > -1:
			if quality == 'set':
				SetChannel(addonKey, 'my_bitrate', '' if qualityInd == 0 else resolutions[qualityInd][0])
			link = resolutions[qualityInd][2]
	else:
		quality = int(quality)
		res = 0
		for resolution in resolutions:
			_res = int(resolution[0])
			if _res >=  res and _res <=  quality:
				res = _res
				link = resolution[2]
	if not link.startswith('http'): 
		link = urlparse.urljoin(baseUrl, link)
	if base.query != '' and base.query not in link:
		link = '{0}?{1}'.format(link, base.query)
	return link

def PlayStream(url, quality='best', name='', iconimage='', adaptive=False, props=None, resume=None, details=None):
	"""Resolve or play `url`. `props` is an optional dict of ListItem properties (the watch-history key). `resume` is `(seconds, total)` to start from:
	Kodi resumes silently from the video tag's resume point (for a resolved plugin item `StartOffset` is NOT carried over, only the resume point is;
	Kodi 19 and older get `StartOffset`). `details` is an optional dict of video info (title, tvshowtitle, season, episode, plot, aired, duration,
	mediatype) that replaces the defaults taken from the list row."""
	if 'dailymotion' in url:
		url = GetDailymotion(url)
	if adaptive:
		if "|" in url:
			url, headers_str = url.split("|", 1)
		else:
			headers_str = ""
	try:
		listitem = xbmcgui.ListItem(name, path=url)
		listitem.setArt({'thumb' : iconimage, 'fanart': iconimage, 'icon': iconimage})
	except:
		listitem = xbmcgui.ListItem(name, path=url, iconImage=iconimage, thumbnailImage=iconimage)
	plot = xbmc.getInfoLabel("ListItem.Plot")
	year = xbmc.getInfoLabel("ListItem.Year")
	infos = {"title": name, "plot": plot, u'mpaa': 'heb'}
	if year != "":
		infos["year"] = year
	infos.update(details or {})
	setInfo(listitem, infos)
	if adaptive:
		listitem.setProperty('inputstream', 'inputstream.adaptive')
		listitem.setProperty('inputstream.adaptive.manifest_headers', headers_str)
		listitem.setProperty('inputstream.adaptive.stream_headers', headers_str)
	for propKey, propValue in (props or {}).items():
		listitem.setProperty(propKey, propValue)
	if resume:
		if GetKodiVer() >= 20:
			listitem.getVideoInfoTag().setResumePoint(float(resume[0]), float(resume[1]))
		else:
			listitem.setProperty('StartOffset', str(resume[0]))
	if (quality == 'choose' or quality.startswith('set')) and '.m3u8' in url:
		xbmc.Player().play(url, listitem)
	else:
		xbmcplugin.setResolvedUrl(handle=GetHandle(), succeeded=True, listitem=listitem)

def GetLocaleString(id):
	return encode(Addon.getLocalizedString(id), 'utf-8')

def EscapeXML(text):
	return text.replace('&', '&amp;').replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#39;")

def UnEscapeXML(st):
	import xml.parsers.expat as expat
	if st is None:
		return ''
	st = st.replace("&hellip;", "").replace("&nbsp;", " ")
	want_unicode = False
	if py2 and isinstance(st, unicode):
		st = encode(st, "utf-8")
		want_unicode = True
	# the rest of this assumes that `st` is UTF-8
	list = []
	# create and initialize a parser object
	p = expat.ParserCreate("utf-8")
	p.buffer_text = True
	if py2:
		p.returns_unicode = want_unicode
	p.CharacterDataHandler = list.append
	# parse the data wrapped in a dummy element
	# (needed so the "document" is well-formed)
	p.Parse("<e>", 0)
	p.Parse(st, 0)
	p.Parse("</e>", 1)
	# join the extracted strings and return
	es = ""
	if want_unicode:
		es = u""
	return es.join(list)

def XmlToDict(text):
	import xmltodict
	return xmltodict.parse(text)

def GetLabelColor(text, keyColor=None, bold=False, color=None):
	if not color:
		color = Addon.getSetting(keyColor)
	if bold and Addon.getSetting("boldLables") == "true":
		text = '[B]{0}[/B]'.format(text)
	return text if color == 'none' else '[COLOR {0}]{1}[/COLOR]'.format(color, text)

def getDisplayName(title, subtitle, programNameFormat, bold=False):
	if programNameFormat == 0:
		displayName = ' {0} - {1} '.format(GetLabelColor(title, keyColor="prColor", bold=bold) , GetLabelColor(subtitle, keyColor="chColor"))
	elif programNameFormat == 1:
		displayName = ' {0} - {1} '.format(GetLabelColor(subtitle, keyColor="chColor") , GetLabelColor(title, keyColor="prColor", bold=bold))
	return displayName

def GetUnColor(text):
	regex = re.compile("(\[/?(?:COLOR|B).*?\])", re.IGNORECASE)
	return regex.sub('', text).strip()

def GetImageUrl(iconimage):
	if iconimage is not None:
		i = iconimage.find('://')
		iconimage = iconimage[:i+3] + quote(encode(iconimage[i+3:], "utf-8"))
	return iconimage

def SetViewMode(content):
	xbmcplugin.setContent(GetHandle(), content)
	viewMode = Addon.getSetting("viewModeEpisodes").strip()
	if viewMode != 'Auto' and viewMode != '':
		xbmc.executebuiltin("Container.SetViewMode({0})".format(viewMode))

def ToggleSortMethod(id, sortBy):
	if sortBy == 0:
		Addon.setSetting(id, "1")
	else:
		Addon.setSetting(id, "0")
	xbmc.executebuiltin("Container.Refresh()")

def MoveInList(index, step, listFile):
	theList = ReadList(listFile)
	if index + step >= len(theList) or index + step < 0:
		return
	if step == 0:
		step = GetIndexFromUser(GetLabelColor(GetLocaleString(30034), bold=True, color="none"), len(theList))
		if step != 0:
			step = step - 1 - index
	if step < 0:
		tempList = theList[0:index + step] + [theList[index]] + theList[index + step:index] + theList[index + 1:]
	elif step > 0:
		tempList = theList[0:index] + theList[index +  1:index + 1 + step] + [theList[index]] + theList[index + 1 + step:]
	else:
		return
	WriteList(listFile, tempList)
	xbmc.executebuiltin("Container.Refresh()")

def GetNumFromUser(title, defaultt=''):
	dialog = xbmcgui.Dialog()
	choice = dialog.input(title, defaultt=defaultt, type=xbmcgui.INPUT_NUMERIC)
	return None if choice is None or choice == '' else int(choice)

def GetIndexFromUser(title, listLen):
	location = GetNumFromUser('{0} (1-{1})'.format(title, listLen))
	return -1 if location is None or location > listLen or location <= 0 else location

def GetUpdatedList(listFile, listUrl, headers={}, deltaInSec=86400, isZip=False, sort=False, decode_text=None):
	if isFileOld(listFile, deltaInSec=deltaInSec):
		try:
			if isZip:
				aFile = '{0}.zip'.format(listFile)
				DelFile(aFile)
			else:
				aFile = listFile
			data = OpenURL(listUrl, headers=headers, responseMethod='content')
			with io.open(aFile, 'wb') as f:
				if decode_text is not None:
					data = data.decode(decode_text).encode('utf-8')
				f.write(data)
			if isZip:
				xbmc.executebuiltin("Extract({0}, {1})".format(aFile, profileDir), True)
				DelFile(aFile)
		except Exception as ex:
			xbmc.log("{0}".format(ex), xbmc.LOGERROR)
	items = ReadList(listFile)
	return sorted(items,key=lambda items: items['name']) if sort else items

def GetDisplayChannels(displayChannelsFile):
	if not os.path.isfile(displayChannelsFile):
		WriteList(displayChannelsFile, {})
	return ReadList(displayChannelsFile)

def GetChannels(type=None, downloadOnly=False):
	deltaInSec = 0 if downloadOnly else Addon.getSettingInt("updateChannelsLinksInterval")*3600
	if downloadOnly or isFileOld(displayChannelsFile, deltaInSec=deltaInSec):
		fileName = 'channels.json'
		channelsFile = os.path.join(profileDir, fileName)
		channelsUrl = 'https://raw.githubusercontent.com/Fishenzon/repo/master/plugin.video.idanplus/{0}'.format(fileName)
		channels = GetUpdatedList(channelsFile, channelsUrl, deltaInSec=deltaInSec)
		if len(channels) == 0:
			channels = ReadList(os.path.join(resourcesDir, fileName))
			if len(channels) == 0:
				return {}
		displayChannels = GetDisplayChannels(displayChannelsFile)
		for channelID, channel in items(channels):
			displayChannel = displayChannels.get(channelID)
			if displayChannel is None:
				displayChannels[channelID] = channel
			else:
				for key, value in channel.items():
					#if displayChannels[channelID].get(key) != value:
					displayChannels[channelID][key] = value
		channelsToDel = []
		for channelID, channel in items(displayChannels):
			if channels.get(channelID) is None:
				channelsToDel.append(channelID)
		for channelID in channelsToDel:
			displayChannels.pop(channelID, None)
		WriteList(displayChannelsFile, displayChannels)
	if (downloadOnly):
		return
	displayChannels = GetDisplayChannels(displayChannelsFile)
	if type is None:
		return displayChannels
	return [[chID, item] for chID, item in items(displayChannels) if item['type'] == type]

def GetChannel(channelID):
	channels = GetChannels()
	return channels.get(channelID)
	
def GetChannelLinkDetails(channelID):
	channels = GetChannels()
	return channels.get(channelID, {}).get('linkDetails')

def SetChannel(channelID, key, value):
	displayChannels = GetChannels()
	displayChannel = displayChannels.get(channelID)
	if displayChannel is None:
		return
	displayChannels[channelID][key] = value
	WriteList(displayChannelsFile, displayChannels)

def GetKeyboardText(title = '', defaultText = ''):
	keyboard = xbmc.Keyboard(defaultText, title)
	keyboard.doModal()
	return None if not keyboard.isConfirmed() else keyboard.getText()

def GetSourceLocation(title, choiceList):
	return xbmcgui.Dialog().select(title, choiceList)

def GetChoice(choiceTitle, fileTitle, urlTitle, choiceFile, choiceUrl, choiceNone=None, fileType=1, fileMask=None, defaultText=None):
	choice = None	# None - for choice cancel
	choiceList = [GetLocaleString(choiceFile), GetLocaleString(choiceUrl)]
	if choiceNone != None:
		choiceList = [GetLocaleString(choiceNone)] + choiceList
	method = GetSourceLocation(GetLocaleString(choiceTitle), choiceList)
	if choiceNone != None and method == 0:
		choice = ''
	elif choiceNone == None and method == 0 or choiceNone != None and method == 1:
		if defaultText != None and not defaultText.startswith('http'):
			defaultText = ''
		choice = GetKeyboardText(GetLocaleString(fileTitle), defaultText)
		if choice != None:
			choice = choice.strip()
	elif choiceNone == None and method == 1 or choiceNone != None and method == 2:
		if defaultText != None and defaultText.startswith('http'):
			defaultText = ''
		choice = xbmcgui.Dialog().browse(fileType, GetLocaleString(urlTitle), '', fileMask, False, False, defaultText)
		if choice == '':
			choice = None
	return choice

def SaveLogo(logoSource, logoDir, filename, isFromUrl):
	logoPath = url_parse(logoSource).path if isFromUrl else logoSource
	root, extension = os.path.splitext(logoPath)
	logoFullName = '{0}_{1}{2}'.format(filename, int(time.time()), extension)
	logoFile = os.path.join(logoDir, logoFullName)
	if isFromUrl:
		data = OpenURL(logoSource, responseMethod='content')
		with io.open(logoFile, 'wb') as f:
			f.write(data)
	else:
		shutil.copyfile(logoSource, logoFile)
	return logoFullName

def GetChannelIconFullPath(channel):
	if channel.get('my_image', '') == '':
		return channel['image']
	else:
		return os.path.join(channelsLogosDir, channel['my_image'])

def GetChannelName(channel):
	return channel['name'] if channel.get('my_name', '') == '' else channel['my_name']

def GetChannelTvgId(channel):
	return channel['tvgID'] if channel.get('my_tvgID', '') == '' else channel['my_tvgID']

def GetChannelAdaptive(channel):
	return channel['linkDetails'].get('adaptive', False) if channel.get('my_adaptive', '') == '' else channel['my_adaptive']

def quote(text):
	if py2:
		return urllib.quote(text)
	else:
		return urlparse.quote(text)

def quoteNonASCII(text):
	t = ''
	for i in range(len(text)):
		t += text[i] if ord(text[i]) < 128 else quote(text[i])
	return t

def unquote(text):
	if py2:
		return urllib.unquote(text)
	else:
		return urlparse.unquote(text)

def quote_plus(text):
	if py2:
		return urllib.quote_plus(text)
	else:
		return urlparse.quote_plus(text)

def unquote_plus(text):
	if py2:
		return urllib.unquote_plus(text)
	else:
		return urlparse.unquote_plus(text)

def urlencode(text):
	if py2:
		return urllib.urlencode(text)
	else:
		return urlparse.urlencode(text)

def parse_qs(text):
	return urlparse.parse_qs(text)

def parse_qsl(text):
	return urlparse.parse_qsl(text)

def url_parse(text):
	return urlparse.urlparse(text)

def urlunparse(text):
	return urlparse.urlunparse(text)

def uni_code(text):
	if py2:
		return unicode(text)
	else:
		return str(text)

def items(d):
	if py2:
		return d.iteritems()
	else:
		return d.items()

def isnumeric(text):
	return uni_code(text).isnumeric()

def GetKaltura(entryId, partnerId, baseUrl, userAgent, quality='best'):
	headers = {
		'accept': '*/*',
		'accept-language': 'en',
		'content-type': 'application/json',
		'sec-fetch-dest': 'empty',
		'sec-fetch-mode': 'cors',
		'sec-fetch-site': 'cross-site',
		'referrer': baseUrl,
		'referrerPolicy': 'strict-origin-when-cross-origin',
		'User-Agent': userAgent
	}
	payload = json.dumps({"1":{"service":"session","action":"startWidgetSession","widgetId":"_{0}".format(partnerId)},"2":{"service":"baseEntry","action":"list","ks":"{1:result:ks}","filter":{"redirectFromEntryId":entryId},"responseProfile":{"type":1,"fields":"id,referenceId,name,description,thumbnailUrl,dataUrl,duration,msDuration,flavorParamsIds,mediaType,type,tags,dvrStatus,externalSourceType,status"}},"3":{"service":"baseEntry","action":"getPlaybackContext","entryId":"{2:result:objects:0:id}","ks":"{1:result:ks}","contextDataParams":{"objectType":"KalturaContextDataParams","flavorTags":"all"}},"4":{"service":"metadata_metadata","action":"list","filter":{"objectType":"KalturaMetadataFilter","objectIdEqual":entryId,"metadataObjectTypeEqual":"1"},"ks":"{1:result:ks}"},"apiVersion":"3.3.0","format":1,"ks":"","clientTag":"html5:v0.56.1","partnerId":partnerId})
	link = ''
	try:
		response = OpenURL("https://cdnapisec.kaltura.com/api_v3/service/multirequest", headers=headers, user_data=payload, responseMethod='json')
		#xbmc.log(str(response[2]["sources"]), 5)
		for s in response[2]["sources"]:
			if s["format"] == "applehttp":
				link = s["url"]
				break
		link = GetStreams(link, quality=quality)
	except Exception as ex:
		xbmc.log(str(ex), xbmc.LOGERROR)
	return link

def s(elem):
	if elem[0] == "auto":
		return 1
	else:
		return int(elem[0].split("@")[0])

def GetDailymotion(url):
	vid = re.compile('.*?video/(.*?)[\?|]').findall(url)
	if len(vid) < 1:
		return ''
	vid = vid[0]
	headers = {'User-Agent': 'Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.91 Mobile Safari/537.36',
	   'Origin': 'https://www.dailymotion.com',
	   'Referer': 'https://www.dailymotion.com/'}
	cookie = {'lang': 'en_US', 'ff': 'off'}
	session = GetSession()
	content = OpenURL("https://www.dailymotion.com/player/metadata/video/{0}".format(vid), session=session, headers=headers, cookies=cookie, responseMethod='json')
	if content.get('error') is not None:
		return ''
	else:
		cc = content['qualities']
		cc = list(cc.items())
		cc = sorted(cc, key=s, reverse=True)
		for source, json_source in cc:
			for item in json_source:
				m_url = item.get('url', None)
				if m_url:
					m_url = m_url.replace('dvr=true&', '')
					if '.m3u8?sec' in m_url:
						text = OpenURL(m_url, headers=headers, cookies=session.cookies.get_dict())
						mb = re.findall('NAME="([^"]+)"\n(.+)', text)
						mb = sorted(mb, key=s, reverse=True)
						for quality, strurl in mb:
							quality = quality.split("@")[0]
							if not strurl.startswith('http'):
								strurl1 = re.findall('(.+/)', m_url)[0]
								strurl = strurl1 + strurl
							strurl = '{0}|{1}'.format(strurl.split('#cell')[0], urlencode(headers))
							return strurl

def GetYouTube(url):
	if url.endswith('/'):
		url = url[:-1]
	video_id = url[url.rfind('/')+1:]
	if '?' in video_id:
		video_id = video_id[:video_id.find('?')]
	return '{0}/play/?video_id={1}'.format(youtubePlugin, video_id)

_cfSession = {'scraper': None, 'time': 0, 'home': ''}

def ResetCFSession():
	global _cfSession
	_cfSession = {'scraper': None, 'time': 0, 'home': ''}

def _warmCfSession(scraper, home, reqHeaders, browseReferer=None):
	try:
		scraper.get(home, headers=reqHeaders, timeout=15)
	except Exception:
		pass
	if browseReferer and browseReferer.rstrip('/') != home.rstrip('/'):
		try:
			stepHeaders = dict(reqHeaders)
			stepHeaders['Referer'] = home
			scraper.get(browseReferer, headers=stepHeaders, timeout=15)
		except Exception:
			pass

def _newCfSession(home, reqHeaders, browseReferer=None):
	import resources.lib.cloudscraper as cloudscraper
	scraper = cloudscraper.create_scraper(interpreter='native')
	_warmCfSession(scraper, home, reqHeaders, browseReferer)
	return scraper
													   
def GetCF(url, ua=None, retries=8, responseMethod='text', referer=None):
	import resources.lib.cloudscraper as cloudscraper
	global _cfSession
	ua = ua or userAgent
	home = 'https://www.kankids.org.il/' if 'kankids' in url else 'https://www.kan.org.il/'
	browseReferer = referer or home
	reqHeaders = {
		'User-Agent': ua,
		'Referer': browseReferer,
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
		'Sec-Fetch-Dest': 'document',
		'Sec-Fetch-Mode': 'navigate',
		'Sec-Fetch-Site': 'same-origin' if browseReferer.startswith(home.rstrip('/')) else 'none',
		'Upgrade-Insecure-Requests': '1',
	}
	if _cfSession['scraper'] is None or (time.time() - _cfSession['time']) > 300 or _cfSession['home'] != home:
		_cfSession = {'scraper': _newCfSession(home, reqHeaders, browseReferer), 'time': time.time(), 'home': home}
	scraper = _cfSession['scraper']
	for i in range(retries):
		try:
			fetchHeaders = dict(reqHeaders)
			fetchHeaders['Referer'] = browseReferer
			response = scraper.request('get', url, headers=fetchHeaders, timeout=20)
			if response.status_code == 403:
				xbmc.sleep(400 if i < 2 else 800)
				xbmc.log('CF - {0}  -  response {1}.'.format(url, response.status_code), xbmc.LOGINFO)
				if i >= 1:
					ResetCFSession()
					scraper = _newCfSession(home, reqHeaders, browseReferer)
					_cfSession = {'scraper': scraper, 'time': time.time(), 'home': home}
				continue
			if responseMethod == 'json':
				return response.json()
			elif responseMethod == 'full':
				return response
			else:
				return response.text
		except Exception as ex:
			xbmc.log(str(ex), xbmc.LOGERROR)
			xbmc.sleep(300)
	if responseMethod == 'full':
		return None
	fallbackHeaders = dict(reqHeaders)
	fallbackHeaders['Referer'] = browseReferer
	fallback = OpenURL(url, headers=fallbackHeaders, retries=2, responseMethod=responseMethod if responseMethod in ('text', 'json') else 'text')
	if not fallback:
		ResetCFSession()
	return fallback if fallback else ''

def GetCFheaders(url, ua=None, retries=10):
	import resources.lib.cloudscraper as cloudscraper
	for i in range(retries):
		try:
			scraper = cloudscraper.create_scraper(interpreter = 'native')
			response = scraper.request('get', url)
			if response.status_code == 403:
				xbmc.sleep(1000)
				xbmc.log('{0}  -  response {1}.'.format(url, response.status_code), xbmc.LOGINFO)
				continue
			return response.headers
		except Exception as ex:
			xbmc.log(str(ex), xbmc.LOGERROR)
			#return None
	return ''

def SaveImage(logoUrl, logoFile):
	try:
		if not os.path.isfile(logoFile):
			import threading
			threading.Thread(target=GetImageLinkBackground, args=(logoUrl, logoFile, )).start()
	except Exception as ex:
		xbmc.log("{0}".format(ex), xbmc.LOGERROR)
	
def GetImageLinkBackground(logoUrl, logoFile):
	response = GetCF(logoUrl, responseMethod='full')
	if response.status_code == 200:
		with open(logoFile, 'wb') as f:
			for chunk in response:
				f.write(chunk)

def slugify(value, allow_unicode=False):
	import unicodedata
	value = str(value)
	if allow_unicode:
		value = unicodedata.normalize('NFKC', value)
	else:
		value = unicodedata.normalize('NFKD', value).encode('ascii', 'ignore').decode('ascii')
	value = re.sub(r'[^\w\s-]', '', value.lower())
	return re.sub(r'[-\s]+', '-', value).strip('-_')

def setInfo(listitem, infos, type="Video"):
	if GetKodiVer() >= 20:
		vinfo = listitem.getVideoInfoTag()
		for key, value in infos.items():
			if value is None:
				continue
			if key.lower() == 'title':
				vinfo.setTitle(value)
			elif key.lower() == 'plot':
				vinfo.setPlot(value)
			elif key.lower() == 'mediatype':
				vinfo.setMediaType(value)
			elif key.lower() == 'mpaa':
				vinfo.setMpaa(value)
			elif key.lower() == 'aired':
				vinfo.setFirstAired(value)
			elif key.lower() == 'year':
				vinfo.setYear(int(value))
			elif key.lower() == 'duration':
				vinfo.setDuration(int(value))
			elif key.lower() == 'tvshowtitle':
				vinfo.setTvShowTitle(value)
			elif key.lower() == 'season':
				vinfo.setSeason(int(value))
			elif key.lower() == 'episode':
				vinfo.setEpisode(int(value))
			else:
				xbmc.log('--------- {0} ---------'.format(key), xbmc.LOGWARNING)
	else:
		listitem.setInfo(type=type, infoLabels=infos)