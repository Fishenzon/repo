# -*- coding: utf-8 -*-
import sys, os, urlparse, urllib, datetime
import xbmc, xbmcplugin, xbmcaddon
import resources.lib.common as common
import resources.lib.epg as epg

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
imagesDir = xbmc.translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources', 'images')).decode("utf-8")

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
url = urllib.unquote_plus(params.get('url', ''))
mode = int(params.get('mode','-1'))
name = urllib.unquote_plus(params.get('name', ''))
iconimage = urllib.unquote_plus(params.get('iconimage', ''))
module = params.get('module')
moreData = urllib.unquote_plus(params.get('moredata', ''))

def GetCategoriesList():
	name = '[B]שידורים חיים[/B]'
	common.addDir(name, '', 1, icon, {"Title": name})
	name = '[B]VOD[/B]'
	common.addDir(name, '', 2, icon, {"Title": name})
	name = '[B]רדיו[/B]'
	common.addDir(name, '', 3, icon, {"Title": name})
	name = '[B]תכניות רדיו[/B]'
	common.addDir(name, '', 21, icon, {"Title": name}, module='kan')
	name = '[B]הגדרות[/B]'
	common.addDir(name, '', 6, icon, {"Title": name})

def LiveChannels():
	nowEPG = epg.GetNowEPG()
	channels = [{'ch': 'ch_11', 'index': 1}, {'ch': 'ch_12', 'index': 2}, {'ch': 'ch_13', 'index': 3}, {'ch': 'ch_14', 'index': 4}, {'ch': 'ch_20', 'index': 5}, {'ch': 'ch_21', 'index': 6}, {'ch': 'ch_23', 'index': 7}, {'ch': 'ch_24', 'index': 8}, {'ch': 'ch_bb', 'index': 9}, {'ch': 'ch_33', 'index': 10}, {'ch': 'ch_66', 'index': 11}, {'ch': 'ch_96', 'index': 12}, {'ch': 'ch_97', 'index': 13}, {'ch': 'ch_99', 'index': 14}, {'ch': 'ch_2news', 'index': 15}, {'ch': 'ch_i24en', 'index': 16}, {'ch': 'ch_i24fr', 'index': 17}, {'ch': 'ch_i24ar', 'index': 18}, {'ch': 'ch_keshetBest', 'index': 19}, {'ch': 'ch_refresh', 'index': 20}]
	for channel in channels:
		channel['index'] = common.GetIntSetting(channel['ch'], channel['index'])
	channels = sorted(channels, key=lambda k: k['index']) 
	for channel in channels:
		if channel['index'] == 0:
			continue
		ch = channel['ch']
		if ch == 'ch_11': LiveChannel('כאן 11', '11', 10, os.path.join(imagesDir, "kan.jpg"), 'kan', programs=nowEPG.get('11', []))
		elif ch == 'ch_12': LiveChannel('קשת 12', '12', 10, os.path.join(imagesDir, "keshet.jpg"), 'keshet', programs=nowEPG.get('12', []))
		elif ch == 'ch_13': LiveChannel('רשת 13', '13', 4, os.path.join(imagesDir, "13.png"), 'reshet', programs=nowEPG.get('13', []))
		elif ch == 'ch_14': LiveChannel('עשר 14', '14', 6, os.path.join(imagesDir, "ten.png"), 'ten', programs=nowEPG.get('14', []))
		elif ch == 'ch_20': LiveChannel('מורשת 20', '20', 10, os.path.join(imagesDir, "20.png"), 'twenty', programs=nowEPG.get('20', []))
		elif ch == 'ch_21': LiveChannel('ערוץ הקניות 21', '21', 10, os.path.join(imagesDir, "21tv.jpg"), '21tv', programs=nowEPG.get('21', []))
		elif ch == 'ch_23': LiveChannel('חינוכית 23', '23', 10, os.path.join(imagesDir, "23tv.png"), '23tv', programs=nowEPG.get('23', []))
		elif ch == 'ch_24': LiveChannel('מוזיקה 24', '24', 10, os.path.join(imagesDir, "24.jpg"), 'keshet', programs=nowEPG.get('24', []))
		elif ch == 'ch_bb': LiveChannel('האח הגדול 26', 'bb', 4, os.path.join(imagesDir, "bb.jpg"), 'reshet')
		elif ch == 'ch_33': LiveChannel('מכאן 33', '33', 10, os.path.join(imagesDir, "makan.png"), 'kan', programs=nowEPG.get('33', []))
		elif ch == 'ch_66': LiveChannel('קבלה 66', '66', 10, os.path.join(imagesDir, "kabbalah.jpg"), 'kabbalah', programs=nowEPG.get('66', []))
		elif ch == 'ch_96': LiveChannel('מאיר 96', '96', 10, os.path.join(imagesDir, "meirtv.jpg"), 'meirtv', programs=nowEPG.get('96', []))
		elif ch == 'ch_97': LiveChannel('הידברות 97', '97', 10, os.path.join(imagesDir, "hidabroot.jpg"), 'hidabroot', programs=nowEPG.get('97', []))
		elif ch == 'ch_99': LiveChannel('כנסת 99', '99', 10, os.path.join(imagesDir, "knesset.png"), 'knesset', programs=nowEPG.get('99', []))
		elif ch == 'ch_2news': LiveChannel('ערוץ החדשות', 'news', 4, os.path.join(imagesDir, "2news.jpg"), 'reshet')
		elif ch == 'ch_i24en': LiveChannel('i24 English', 'i24en', 10, os.path.join(imagesDir, "i24.png"), 'i24', programs=nowEPG.get('i24en', []))
		elif ch == 'ch_i24fr': LiveChannel('i24 French', 'i24fr', 10, os.path.join(imagesDir, "i24.png"), 'i24', programs=nowEPG.get('i24fr', []))
		elif ch == 'ch_i24ar': LiveChannel('i24 Arabic', 'i24ar', 10, os.path.join(imagesDir, "i24.png"), 'i24', programs=nowEPG.get('i24ar', []))
		elif ch == 'ch_keshetBest': LiveChannel('קשת המיטב', 'keshetBest', 10, os.path.join(imagesDir, "keshet_best.jpg"), 'keshet')
		elif ch == 'ch_refresh':
			name = '[B]רענון רשימה[/B]'
			common.addDir(name, '', 4, icon, infos={"Title": name}, isFolder=False)

def LiveChannel(name, url, mode, iconimage, module, choose=True, programs=[]):
	displayName = "[COLOR {0}][B]{1}[/B][/COLOR]".format(Addon.getSetting("chColor"), name)
	description = ''
	contextMenu = []
	if len(programs) > 0:
		contextMenu.append(('EPG', 'Container.Update({0}?url={1}&name={2}&mode=2&iconimage={3}&module=epg)'.format(sys.argv[0], url, urllib.quote_plus(name), urllib.quote_plus(iconimage))))
		start_time = datetime.datetime.fromtimestamp(programs[0]["start"]).strftime('%H:%M')
		end_time = datetime.datetime.fromtimestamp(programs[0]["end"]).strftime('%H:%M')
		programName = "[COLOR {0}][B]{1}[/B][/COLOR] [COLOR {2}][{3}-{4}][/COLOR]".format(Addon.getSetting("prColor"), programs[0]["name"].encode('utf-8'), Addon.getSetting("timesColor"), start_time, end_time)
		displayName = "{0} - {1}".format(displayName, programName)
		description = '{0}[CR]{1}'.format(programName, programs[0]["description"].encode('utf-8'))
		if len(programs) > 1:
			description = '{0}[CR][CR]Next: [COLOR {1}][B]{2}[/B][/COLOR] [COLOR {3}][{4}-{5}][/COLOR]'.format(description, Addon.getSetting("prColor"), programs[1]["name"].encode('utf-8'), Addon.getSetting("timesColor"), datetime.datetime.fromtimestamp(programs[1]["start"]).strftime('%H:%M'), datetime.datetime.fromtimestamp(programs[1]["end"]).strftime('%H:%M'))
	if choose:
		contextMenu.insert(0, (common.GetLocaleString(30005), 'RunPlugin({0}?url={1}&name={2}&mode={3}&iconimage={4}&moredata=choose&module={5})'.format(sys.argv[0], url, urllib.quote_plus(displayName), mode, urllib.quote_plus(iconimage), module)))
	if contextMenu == []:
		contextMenu = None
	common.addDir(displayName, url, mode, iconimage, infos={"Title": displayName, "Plot": description}, contextMenu=contextMenu, moreData='best', module=module, isFolder=False, isPlayable=True)

def VODs():
	name = 'כאן 11'
	common.addDir(name, '', 0, os.path.join(imagesDir, "kan.jpg"), infos={"Title": name}, module='kan')
	name = 'קשת 12'
	common.addDir(name, '', 0, os.path.join(imagesDir, "mako.png"), infos={"Title": name}, module='keshet')
	name = 'רשת 13'
	common.addDir(name, '', 0, os.path.join(imagesDir, "13.png"), infos={"Title": name}, module='reshet')
	name = 'עשר 14'
	common.addDir(name, '', 0, os.path.join(imagesDir, "ten.png"), infos={"Title": name}, module='ten')
	name = 'מורשת 20'
	common.addDir(name, '', 0, os.path.join(imagesDir, "20.png"), infos={"Title": name}, module='twenty')

def Radios():
	nowEPG = epg.GetNowEPG()
	channels = [{'ch': 'rd_glglz', 'index': 1}, {'ch': 'rd_88', 'index': 2}, {'ch': 'rd_99', 'index': 3}, {'ch': 'rd_102', 'index': 4}, {'ch': 'rd_103', 'index': 5}, {'ch': 'rd_glz', 'index': 6}, {'ch': 'rd_bet', 'index': 7}, {'ch': 'rd_gimel', 'index': 8}, {'ch': 'rd_culture', 'index': 9}, {'ch': 'rd_music', 'index': 10}, {'ch': 'rd_moreshet', 'index': 11}, {'ch': 'rd_reka', 'index': 12}, {'ch': 'rd_makan', 'index': 13}, {'ch': 'rd_persian', 'index': 14}, {'ch': 'rd_80_90', 'index': 15}, {'ch': 'rd_alt', 'index': 16}, {'ch': 'rd_classic', 'index': 17}, {'ch': 'rd_hits', 'index': 18}, {'ch': 'rd_nos', 'index': 19}, {'ch': 'rd_regesh', 'index': 20}, {'ch': 'rd_oriental', 'index': 21}, {'ch': 'rd_refresh', 'index': 22}]
	for channel in channels:
		channel['index'] = common.GetIntSetting(channel['ch'], channel['index'])
	channels = sorted(channels, key=lambda k: k['index']) 
	for channel in channels:
		if channel['index'] == 0:
			continue
		ch = channel['ch']
		if ch == 'rd_glglz': LiveChannel('גלגל"צ', 'glglz', 11, os.path.join(imagesDir, "glglz.jpg"), 'glz', choose=False, programs=nowEPG.get('glglz', []))
		elif ch == 'rd_88': LiveChannel('כאן 88', '88', 11, os.path.join(imagesDir, "88.png"), 'kan', choose=False, programs=nowEPG.get('88', []))
		elif ch == 'rd_99': LiveChannel('ECO 99FM', '99fm', 11, os.path.join(imagesDir, "99fm.png"), '99fm', choose=False, programs=nowEPG.get('99fm', []))
		elif ch == 'rd_102': LiveChannel('102FM רדיו תל אביב', '102fm', 11, os.path.join(imagesDir, "102fm.jpg"), '102fm', choose=False, programs=nowEPG.get('102fm', []))
		elif ch == 'rd_103': LiveChannel('103FM רדיו ללא הפסקה', '103fm', 11, os.path.join(imagesDir, "103fm.png"), '103fm', choose=False, programs=nowEPG.get('103fm', []))
		elif ch == 'rd_glz': LiveChannel('גלי צה"ל', 'glz', 11, os.path.join(imagesDir, "glz.jpg"), 'glz', choose=False, programs=nowEPG.get('glz', []))
		elif ch == 'rd_bet': LiveChannel('כאן ב', 'bet', 11, os.path.join(imagesDir, "bet.png"), 'kan', choose=False, programs=nowEPG.get('bet', []))
		elif ch == 'rd_gimel': LiveChannel('כאן גימל', 'gimel', 11, os.path.join(imagesDir, "gimel.png"), 'kan', choose=False, programs=nowEPG.get('gimel', []))
		elif ch == 'rd_culture': LiveChannel('כאן תרבות', 'culture', 11, os.path.join(imagesDir, "culture.png"), 'kan', choose=False, programs=nowEPG.get('culture', []))
		elif ch == 'rd_music': LiveChannel('כאן קול המוסיקה', 'music', 11, os.path.join(imagesDir, "music.png"), 'kan', choose=False, programs=nowEPG.get('music', []))
		elif ch == 'rd_moreshet': LiveChannel('כאן מורשת', 'moreshet', 11, os.path.join(imagesDir, "moreshet.png"), 'kan', choose=False, programs=nowEPG.get('moreshet', []))
		elif ch == 'rd_reka': LiveChannel('כאן Reka', 'reka', 11, os.path.join(imagesDir, "reka.png"), 'kan', choose=False, programs=nowEPG.get('reka', []))
		elif ch == 'rd_makan': LiveChannel('כאן مكان', 'makan', 11, os.path.join(imagesDir, "makan.png"), 'kan', choose=False, programs=nowEPG.get('makan', []))
		elif ch == 'rd_persian': LiveChannel('כאן فارسی', 'persian', 11, os.path.join(imagesDir, "persian.png"), 'kan', choose=False, programs=nowEPG.get('persian', []))
		elif ch == 'rd_80_90': LiveChannel("כאן 80-90", '80-90', 11, os.path.join(imagesDir, "80_90.png"), 'kan', choose=False)
		elif ch == 'rd_alt': LiveChannel("כאן קצת אחרת", 'alt', 11, os.path.join(imagesDir, "alt.png"), 'kan', choose=False)
		elif ch == 'rd_classic': LiveChannel("כאן קלאסי", 'classic', 11, os.path.join(imagesDir, "classic.png"), 'kan', choose=False)
		elif ch == 'rd_hits': LiveChannel("כאן להיטים", 'hits', 11, os.path.join(imagesDir, "hits.png"), 'kan', choose=False)
		elif ch == 'rd_nos': LiveChannel("כאן נוסטלגי", 'nos', 11, os.path.join(imagesDir, "nos.png"), 'kan', choose=False)
		elif ch == 'rd_regesh': LiveChannel("כאן שיא הרגש", 'regesh', 11, os.path.join(imagesDir, "regesh.png"), 'kan', choose=False)
		elif ch == 'rd_oriental': LiveChannel('כאן ים תיכוני', 'oriental', 11, os.path.join(imagesDir, "oriental.png"), 'kan', choose=False)
		elif ch == 'rd_refresh':
			name = '[B]רענון רשימה[/B]'
			common.addDir(name, '', 4, icon, infos={"Title": name}, isFolder=False)

if module is None:
	if mode == -1:
		GetCategoriesList()
	elif mode == 1:
		LiveChannels()
	elif mode == 2:
		VODs()
	elif mode == 3:
		Radios()
	elif mode == 4:
		xbmc.executebuiltin("Container.Refresh()")
	elif mode == 5:
		epg.GetEPG(deltaInSec=0)
	elif mode == 6:
		Addon.openSettings()
		sys.exit()
	if mode == 1 or mode == 3:
		common.SetViewMode('episodes')
else:
	try:
		moduleScript = __import__('resources.lib.{0}'.format(module), fromlist=[module])
		moduleScript.Run(name, url, mode, iconimage, moreData)
	except Exception as ex:
		xbmc.log(str(ex), 3)

xbmcplugin.endOfDirectory(handle)