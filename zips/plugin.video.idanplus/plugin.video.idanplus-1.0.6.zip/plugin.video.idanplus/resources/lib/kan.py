﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, os
import sys, re, json, urllib, urllib2, urlparse
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
sortBy = int(Addon.getSetting("kanSortBy"))
module = 'kan'
baseUrl = 'http://www.kan.org.il'
seriesConvUrl = 'https://raw.githubusercontent.com/Fishenzon/repo/master/zips/plugin.video.idanplus/kanSeries.json'
userAgent = common.GetUserAgent()

def GetCategoriesList(iconimage):
	sortString = common.GetLocaleString(30002) if sortBy == 0 else common.GetLocaleString(30003)
	name = "{0}: {1}".format(common.GetLocaleString(30001), sortString)
	common.addDir(name, "toggleSortingMethod", 4, iconimage, {"Title": name, "Plot": "{0}[CR]{1}[CR]{2} / {3}".format(name, common.GetLocaleString(30004), common.GetLocaleString(30002), common.GetLocaleString(30003))}, module=module, isFolder=False)
	name = 'תוכניות טלויזיה'
	common.addDir(name, '{0}/video/programs.aspx'.format(baseUrl), 1, iconimage, infos={"Title": name}, module=module, moreData='TV')
	name = 'תוכניות רשת'
	common.addDir(name, '{0}/video/digital.aspx'.format(baseUrl), 1, iconimage, infos={"Title": name}, module=module, moreData='Net')

def GetSeriesList(url, seriesType):
	try:
		text = common.OpenURL(seriesConvUrl)
		seriesConv = json.loads(text)
	except:
		seriesConv = {"TV":{}, "Net":{}}
	text = common.OpenURL(url)
	matches = re.compile('class="it_small".+?url\(\'(.+?)\'.+?href="/Program/\?catId=(.+?)"', re.S).findall(text)
	for iconimage, id in matches:
		name = seriesConv[seriesType].get(id, '').encode('utf-8')
		if name == '':
			xbmc.log('--{0}--'.format(id), 5)
		name = '[B][COLOR {0}]{1}[/COLOR][/B]'.format(Addon.getSetting("prColor"), name)
		common.addDir(name, id, 2, '{0}{1}'.format(baseUrl, iconimage), infos={"Title": name}, module=module)

def GetEpisodesList(id):
	i = 0
	while True:
		i += 1
		url = '{0}/Program/getMoreProgram.aspx?count={1}&catId={2}'.format(baseUrl, i, id)
		text = common.OpenURL(url)
		matches = re.compile('w-clearfix">.*?url\(\'(.+?)\'.+?<iframe.+?src="(.+?)".+?"content_title">(.+?)</.+?<p>(.+?)</p>', re.S).findall(text)
		if len(matches) == 0:
			break
		for iconimage, url, name, description in matches:
			name = '[COLOR {0}]{1}[/COLOR]'.format(Addon.getSetting("chColor"), name.strip())
			common.addDir(name, url, 3, '{0}{1}'.format(baseUrl, iconimage), infos={"Title": name, "Plot": description.replace('&nbsp;', '').strip()}, module=module, isFolder=False, isPlayable=True)

def Play(url, name='', iconimage='', quality='best'):
	if 'youtube' in url:
		final = 'plugin://plugin.video.youtube/play/?video_id={0}'.format(url[url.rfind('/')+1:])
	else:
		headers={"User-Agent": userAgent}
		link = GetPlayerKanUrl(url, headers=headers)
		final = '{0}|User-Agent={1}'.format(link, userAgent)
	listitem = xbmcgui.ListItem(path=final)
	xbmcplugin.setResolvedUrl(handle=handle, succeeded=True, listitem=listitem)

def GetPlayerKanUrl(url, headers={}):
	text = common.OpenURL(url, headers=headers)
	match = re.compile("var\s*metadataURL\s*?=\s*?'(.+?)'").findall(text)
	text = common.OpenURL(match[0], headers=headers)
	match = re.compile("<SmilURL.*>(.+)</SmilURL>").findall(text)
	smil = match[0].replace('amp;', '')
	match = re.compile("<Server priority='1'>(.+)</Server>").findall(text)
	server = match[0]
	link = urlparse.urlunparse(urlparse.urlparse(smil)._replace(netloc=server))
	return link

def WatchLive(url, name='', iconimage='', quality='best'):
	channels = {
		'11': '{0}/live/tv.aspx?stationId=2'.format(baseUrl),
		'33': '{0}/live/tv.aspx?stationId=14'.format(baseUrl)
	}
	headers={"User-Agent": userAgent}
	text = common.OpenURL(channels[url], headers=headers)
	match = re.compile('<iframe\s*class="embedly-embed"\s*src="(.+?)"').findall(text)
	link = GetPlayerKanUrl(match[0], headers=headers)
	link = common.GetStreams(link, headers=headers, quality=quality)
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 0:	#----------- Categories: ------------------------
		GetCategoriesList(iconimage)
	elif mode == 1:	#------------- Series: --------------------------
		GetSeriesList(url, seriesType=moreData)
	elif mode == 2:	#------------- Episodes: ------------------------
		GetEpisodesList(url)
	elif mode == 3:	#------------- Playing episode  -----------------
		Play(url, name, iconimage, moreData)
	elif mode == 4:	#------------- Toggle Lists' sorting method -----
		common.ToggleSortMethod('kanSortBy', sortBy)
	elif mode == 10:
		WatchLive(url, name, iconimage, moreData)
		
	if mode == 1:
		common.SetViewMode('videos')
	elif mode != 0:
		common.SetViewMode('episodes')
	if sortBy == 1 and mode == 1:
		xbmcplugin.addSortMethod(handle, 1)