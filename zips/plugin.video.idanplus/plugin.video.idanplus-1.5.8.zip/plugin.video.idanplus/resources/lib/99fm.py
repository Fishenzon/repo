﻿# -*- coding: utf-8 -*-
import xbmcaddon
import sys, re
import resources.lib.common as common

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
module = '99fm'
userAgent = common.GetUserAgent()

def WatchLive(name='', iconimage='', quality='best'):
	headers={"User-Agent": userAgent}
	text = common.OpenURL('http://eco99fm.maariv.co.il/Chart/LiveBrodcast.aspx', headers=headers)
	match = re.compile('<div class="eco99Body">(.*?)</div>', re.S).findall(text)
	match = re.compile('<iframe src="(.*?)"').findall(match[0])
	text = common.OpenURL('http://eco99fm.maariv.co.il{0}'.format(match[0].replace('index.html', 'data.json')), headers=headers)
	link = re.compile('radiolink_aac":"(.*?)"').findall(text)[0]
	final = '{0}|User-Agent={1}'.format(link, userAgent)
	common.PlayStream(final, quality, name, iconimage)

def Run(name, url, mode, iconimage='', moreData=''):
	if mode == 11:
		WatchLive(name, iconimage, moreData)
		
	common.SetViewMode('episodes')