# -*- coding: utf-8 -*-
import sys, os, urlparse, urllib, datetime
import xbmc, xbmcplugin, xbmcaddon
import resources.lib.common as common
import resources.lib.epg as epg

handle = int(sys.argv[1])
AddonID = 'plugin.video.idanplus'
Addon = xbmcaddon.Addon(AddonID)
icon = Addon.getAddonInfo('icon')
imagesDir = xbmc.translatePath(os.path.join(Addon.getAddonInfo('path'), 'resources', 'images')).decode("utf-8")

params = dict(urlparse.parse_qsl(sys.argv[2].replace('?','')))
url = urllib.unquote_plus(params.get('url', ''))
mode = int(params.get('mode','-1'))
name = urllib.unquote_plus(params.get('name', ''))
iconimage = urllib.unquote_plus(params.get('iconimage', ''))
module = params.get('module')
moreData = urllib.unquote_plus(params.get('moredata', ''))

def GetCategoriesList():
	name = '[B]שידורים חיים[/B]'
	common.addDir(name, '', 1, icon, {"Title": name})
	name = '[B]VOD[/B]'
	common.addDir(name, '', 2, icon, {"Title": name})
	name = '[B]רדיו[/B]'
	common.addDir(name, '', 3, icon, {"Title": name})
	name = '[B]תכניות רדיו[/B]'
	common.addDir(name, '', 21, icon, {"Title": name}, module='kan')
	name = '[B]הגדרות[/B]'
	common.addDir(name, '', 6, icon, {"Title": name})

def LiveChannels():
	nowEPG = epg.GetNowEPG()
	if Addon.getSetting("ch_11") == 'true': LiveChannel('כאן 11', '11', 10, os.path.join(imagesDir, "kan.jpg"), 'kan', programs=nowEPG.get('11', []))
	if Addon.getSetting("ch_12") == 'true': LiveChannel('קשת 12', '12', 10, os.path.join(imagesDir, "keshet.jpg"), 'keshet', programs=nowEPG.get('12', []))
	if Addon.getSetting("ch_13") == 'true': LiveChannel('רשת 13', '13', 4, os.path.join(imagesDir, "13.png"), 'reshet', programs=nowEPG.get('13', []))
	if Addon.getSetting("ch_14") == 'true': LiveChannel('עשר 14', '14', 6, os.path.join(imagesDir, "ten.png"), 'ten', programs=nowEPG.get('14', []))
	if Addon.getSetting("ch_20") == 'true': LiveChannel('מורשת 20', '20', 10, os.path.join(imagesDir, "20.png"), 'twenty', programs=nowEPG.get('20', []))
	if Addon.getSetting("ch_21") == 'true': LiveChannel('ערוץ הקניות 21', '21', 10, os.path.join(imagesDir, "21tv.jpg"), '21tv', programs=nowEPG.get('21', []))
	if Addon.getSetting("ch_23") == 'true': LiveChannel('חינוכית 23', '23', 10, os.path.join(imagesDir, "23tv.png"), '23tv', programs=nowEPG.get('23', []))
	if Addon.getSetting("ch_24") == 'true': LiveChannel('מוזיקה 24', '24', 10, os.path.join(imagesDir, "24.jpg"), 'keshet', programs=nowEPG.get('24', []))
	if Addon.getSetting("ch_bb") == 'true': LiveChannel('האח הגדול 26', 'bb', 4, os.path.join(imagesDir, "bb.jpg"), 'reshet')
	if Addon.getSetting("ch_33") == 'true': LiveChannel('מכאן 33', '33', 10, os.path.join(imagesDir, "makan.png"), 'kan', programs=nowEPG.get('33', []))
	if Addon.getSetting("ch_66") == 'true': LiveChannel('קבלה 66', '66', 10, os.path.join(imagesDir, "kabbalah.jpg"), 'kabbalah', programs=nowEPG.get('66', []))
	if Addon.getSetting("ch_96") == 'true': LiveChannel('מאיר 96', '96', 10, os.path.join(imagesDir, "meirtv.jpg"), 'meirtv', programs=nowEPG.get('96', []))
	if Addon.getSetting("ch_97") == 'true': LiveChannel('הידברות 97', '97', 10, os.path.join(imagesDir, "hidabroot.jpg"), 'hidabroot', programs=nowEPG.get('97', []))
	if Addon.getSetting("ch_99") == 'true': LiveChannel('כנסת 99', '99', 10, os.path.join(imagesDir, "knesset.png"), 'knesset', programs=nowEPG.get('99', []))
	if Addon.getSetting("ch_2news") == 'true': LiveChannel('ערוץ החדשות', 'news', 4, os.path.join(imagesDir, "2news.jpg"), 'reshet')
	if Addon.getSetting("ch_i24en") == 'true': LiveChannel('i24 English', 'i24en', 10, os.path.join(imagesDir, "i24.png"), 'i24', programs=nowEPG.get('i24en', []))
	if Addon.getSetting("ch_i24fr") == 'true': LiveChannel('i24 French', 'i24fr', 10, os.path.join(imagesDir, "i24.png"), 'i24', programs=nowEPG.get('i24fr', []))
	if Addon.getSetting("ch_i24ar") == 'true': LiveChannel('i24 Arabic', 'i24ar', 10, os.path.join(imagesDir, "i24.png"), 'i24', programs=nowEPG.get('i24ar', []))
	if Addon.getSetting("ch_keshetBest") == 'true': LiveChannel('קשת המיטב', 'keshetBest', 10, os.path.join(imagesDir, "keshet_best.jpg"), 'keshet')
	if Addon.getSetting("ch_refresh") == 'true':
		name = '[B]רענון רשימה[/B]'
		common.addDir(name, '', 4, icon, infos={"Title": name}, isFolder=False)

def LiveChannel(name, url, mode, iconimage, module, choose=True, programs=[]):
	displayName = "[COLOR {0}][B]{1}[/B][/COLOR]".format(Addon.getSetting("chColor"), name)
	description = ''
	contextMenu = []
	if len(programs) > 0:
		contextMenu.append(('EPG', 'Container.Update({0}?url={1}&name={2}&mode=2&iconimage={3}&module=epg)'.format(sys.argv[0], url, urllib.quote_plus(name), urllib.quote_plus(iconimage))))
		start_time = datetime.datetime.fromtimestamp(programs[0]["start"]).strftime('%H:%M')
		end_time = datetime.datetime.fromtimestamp(programs[0]["end"]).strftime('%H:%M')
		programName = "[COLOR {0}][B]{1}[/B][/COLOR] [COLOR {2}][{3}-{4}][/COLOR]".format(Addon.getSetting("prColor"), programs[0]["name"].encode('utf-8'), Addon.getSetting("timesColor"), start_time, end_time)
		displayName = "{0} - {1}".format(displayName, programName)
		description = '{0}[CR]{1}'.format(programName, programs[0]["description"].encode('utf-8'))
		if len(programs) > 1:
			description = '{0}[CR][CR]Next: [COLOR {1}][B]{2}[/B][/COLOR] [COLOR {3}][{4}-{5}][/COLOR]'.format(description, Addon.getSetting("prColor"), programs[1]["name"].encode('utf-8'), Addon.getSetting("timesColor"), datetime.datetime.fromtimestamp(programs[1]["start"]).strftime('%H:%M'), datetime.datetime.fromtimestamp(programs[1]["end"]).strftime('%H:%M'))
	if choose:
		contextMenu.insert(0, (common.GetLocaleString(30005), 'RunPlugin({0}?url={1}&name={2}&mode={3}&iconimage={4}&moredata=choose&module={5})'.format(sys.argv[0], url, urllib.quote_plus(displayName), mode, urllib.quote_plus(iconimage), module)))
	if contextMenu == []:
		contextMenu = None
	common.addDir(displayName, url, mode, iconimage, infos={"Title": displayName, "Plot": description}, contextMenu=contextMenu, moreData='best', module=module, isFolder=False, isPlayable=True)

def VODs():
	name = 'כאן 11'
	common.addDir(name, '', 0, os.path.join(imagesDir, "kan.jpg"), infos={"Title": name}, module='kan')
	name = 'קשת 12'
	common.addDir(name, '', 0, os.path.join(imagesDir, "mako.png"), infos={"Title": name}, module='keshet')
	name = 'רשת 13'
	common.addDir(name, '', 0, os.path.join(imagesDir, "13.png"), infos={"Title": name}, module='reshet')
	name = 'עשר 14'
	common.addDir(name, '', 0, os.path.join(imagesDir, "ten.png"), infos={"Title": name}, module='ten')
	name = 'מורשת 20'
	common.addDir(name, '', 0, os.path.join(imagesDir, "20.png"), infos={"Title": name}, module='twenty')

def Radios():
	nowEPG = epg.GetNowEPG()
	if Addon.getSetting("rd_glglz") == 'true': LiveChannel('גלגל"צ', 'glglz', 11, os.path.join(imagesDir, "glglz.jpg"), 'glz', choose=False, programs=nowEPG.get('glglz', []))
	if Addon.getSetting("rd_88") == 'true': LiveChannel('כאן 88', '88', 11, os.path.join(imagesDir, "88.png"), 'kan', choose=False, programs=nowEPG.get('88', []))
	if Addon.getSetting("rd_99") == 'true': LiveChannel('ECO 99FM', '99fm', 11, os.path.join(imagesDir, "99fm.png"), '99fm', choose=False, programs=nowEPG.get('99fm', []))
	if Addon.getSetting("rd_102") == 'true': LiveChannel('102FM רדיו תל אביב', '102fm', 11, os.path.join(imagesDir, "102fm.jpg"), '102fm', choose=False, programs=nowEPG.get('102fm', []))
	if Addon.getSetting("rd_103") == 'true': LiveChannel('103FM רדיו ללא הפסקה', '103fm', 11, os.path.join(imagesDir, "103fm.png"), '103fm', choose=False, programs=nowEPG.get('103fm', []))
	if Addon.getSetting("rd_glz") == 'true': LiveChannel('גלי צה"ל', 'glz', 11, os.path.join(imagesDir, "glz.jpg"), 'glz', choose=False, programs=nowEPG.get('glz', []))
	if Addon.getSetting("rd_bet") == 'true': LiveChannel('כאן ב', 'bet', 11, os.path.join(imagesDir, "bet.png"), 'kan', choose=False, programs=nowEPG.get('bet', []))
	if Addon.getSetting("rd_gimel") == 'true': LiveChannel('כאן גימל', 'gimel', 11, os.path.join(imagesDir, "gimel.png"), 'kan', choose=False, programs=nowEPG.get('gimel', []))
	if Addon.getSetting("rd_culture") == 'true': LiveChannel('כאן תרבות', 'culture', 11, os.path.join(imagesDir, "culture.png"), 'kan', choose=False, programs=nowEPG.get('culture', []))
	if Addon.getSetting("rd_music") == 'true': LiveChannel('כאן קול המוסיקה', 'music', 11, os.path.join(imagesDir, "music.png"), 'kan', choose=False, programs=nowEPG.get('music', []))
	if Addon.getSetting("rd_moreshet") == 'true': LiveChannel('כאן מורשת', 'moreshet', 11, os.path.join(imagesDir, "moreshet.png"), 'kan', choose=False, programs=nowEPG.get('moreshet', []))
	if Addon.getSetting("rd_reka") == 'true': LiveChannel('כאן Reka', 'reka', 11, os.path.join(imagesDir, "reka.png"), 'kan', choose=False, programs=nowEPG.get('reka', []))
	if Addon.getSetting("rd_makan") == 'true': LiveChannel('כאן مكان', 'makan', 11, os.path.join(imagesDir, "makan.png"), 'kan', choose=False, programs=nowEPG.get('makan', []))
	if Addon.getSetting("rd_persian") == 'true': LiveChannel('כאן فارسی', 'persian', 11, os.path.join(imagesDir, "persian.png"), 'kan', choose=False, programs=nowEPG.get('persian', []))
	if Addon.getSetting("rd_80_90") == 'true': LiveChannel("כאן 80-90", '80-90', 11, os.path.join(imagesDir, "80_90.png"), 'kan', choose=False)
	if Addon.getSetting("rd_alt") == 'true': LiveChannel("כאן קצת אחרת", 'alt', 11, os.path.join(imagesDir, "alt.png"), 'kan', choose=False)
	if Addon.getSetting("rd_classic") == 'true': LiveChannel("כאן קלאסי", 'classic', 11, os.path.join(imagesDir, "classic.png"), 'kan', choose=False)
	if Addon.getSetting("rd_hits") == 'true': LiveChannel("כאן להיטים", 'hits', 11, os.path.join(imagesDir, "hits.png"), 'kan', choose=False)
	if Addon.getSetting("rd_nos") == 'true': LiveChannel("כאן נוסטלגי", 'nos', 11, os.path.join(imagesDir, "nos.png"), 'kan', choose=False)
	if Addon.getSetting("rd_regesh") == 'true': LiveChannel("כאן שיא הרגש", 'regesh', 11, os.path.join(imagesDir, "regesh.png"), 'kan', choose=False)
	if Addon.getSetting("rd_oriental") == 'true': LiveChannel('כאן ים תיכוני', 'oriental', 11, os.path.join(imagesDir, "oriental.png"), 'kan', choose=False)
	if Addon.getSetting("rd_refresh") == 'true':
		name = '[B]רענון רשימה[/B]'
		common.addDir(name, '', 4, icon, infos={"Title": name}, isFolder=False)

if module is None:
	if mode == -1:
		GetCategoriesList()
	elif mode == 1:
		LiveChannels()
	elif mode == 2:
		VODs()
	elif mode == 3:
		Radios()
	elif mode == 4:
		xbmc.executebuiltin("Container.Refresh()")
	elif mode == 5:
		epg.GetEPG(deltaInSec=0)
	elif mode == 6:
		Addon.openSettings()
		sys.exit()
	if mode == 1 or mode == 3:
		common.SetViewMode('episodes')
else:
	try:
		moduleScript = __import__('resources.lib.{0}'.format(module), fromlist=[module])
		moduleScript.Run(name, url, mode, iconimage, moreData)
	except Exception as ex:
		xbmc.log(str(ex), 3)

xbmcplugin.endOfDirectory(handle)