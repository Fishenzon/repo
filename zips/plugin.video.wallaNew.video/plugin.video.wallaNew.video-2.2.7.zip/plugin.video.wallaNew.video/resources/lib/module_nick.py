# -*- coding: utf-8 -*-
'''
Created on 01/05/2011

@author: shai
'''

import re,xbmcplugin,sys,xbmc
import wallacommon as common

__BASE_URL__ = 'http://nick.walla.co.il/'
__NAME__ = 'nick'

class manager_nick:
    def __init__(self):
        self.MODES = common.enum(GET_SERIES_LIST=1, GET_EPISODES_LIST=2)
       
    def work(self, mode, url='', name='', page=''):
        
        if (mode==self.MODES.GET_SERIES_LIST):
            self.getSeriesList()
        elif(mode==self.MODES.GET_EPISODES_LIST):
            self.getEpisodeList(url)

    def getSeriesList(self):
		contentType,block = common.getMatches(__BASE_URL__+'tvshows','desktop&quot;:5(.*?)</section>')
		page = re.compile('<a href="/(.*?)".*?<img src="(.*?)".*?cd-title>(.*?)<').findall(block[0])
		for path in page:
			summary = ''
			iconImage='http:' + path[1]
			url=__BASE_URL__ + path[0]
			title=path[2]
			common.addDir('utf-8',title, url, self.MODES.GET_EPISODES_LIST, iconImage, __NAME__, summary)               
		xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

    def getEpisodeList(self, inUrl):
		if 'tvshow' in inUrl:
			contentType,block = common.getMatches(inUrl, '<nav class="common-sub-menu">(.*?)</nav>')
			matches = re.compile('<li class=""><a href="/item/(\d*)">(.*?)</a>').findall(block[0])
			seasons = []
			for match in matches:
				if 'פרקים מלאים' in match[1]:
					seasons.append(match)
			sl = len(seasons)
			if sl < 1:
				return
			elif sl == 1:
				inUrl=__BASE_URL__+'item/'+seasons[0][0]
			else:
				for season in seasons:
					common.addDir('UTF-8', season[1], __BASE_URL__+'item/'+season[0], self.MODES.GET_EPISODES_LIST, 'DefaultFolder.png', __NAME__)
				xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
				return
				
		contentType,mainPage = common.getData(inUrl)
		urls = re.compile('/TVEpisode.*?src="(.*?)".*?title>(.*?)</span>').findall(mainPage)
		for path in urls:
			title = path[1]
			iconImage = 'http:' + path[0]
			vidid = re.compile('/(\d*)-').findall(iconImage)[0]
			id = vidid[:-2].zfill(5)
			url = 'http://62.90.90.56/walla_vod/_definst_/mp4:media/0' + id[:2] + '/' + id[2:] + '/' + vidid + '-40.mp4/playlist.m3u8'
			common.addLink('utf-8', title, url, iconImage)
			
		nav = re.compile('class="pager"(.*?)</nav>').findall(mainPage)
		if len(nav) > 0:
			pages = re.compile('href="(.*?)" class="(.*?)"').findall(nav[0])
			if len(pages) > 0 and pages[-1][1] == 'icon-right':
				common.addDir('UTF-8', common.__language__(30001), __BASE_URL__ + pages[-1][0][1:], self.MODES.GET_EPISODES_LIST, 'DefaultFolder.png', __NAME__)
		xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
