#!/usr/bin/python
from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer
import os,json,logging
import threading
from r import get_link
PORT_NUMBER = 8080
global all_ids
all_ids={}
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
Addon = xbmcaddon.Addon()
#This class will handles any incoming request from
#the browser 
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
class myHandler(BaseHTTPRequestHandler):
    
    #Handler for the GET requests
    def do_GET(self):
        global all_ids
        logging.warning('GET NOW')
        self_id=(self.path).replace('/','')
        self.send_response(200)
        self.send_header('Content-type','text/html')
        self.end_headers()
        
        # Send the html message
        logging.warning(all_ids[self_id])
        self.wfile.write(all_ids[self_id])
        return
    def do_POST(self):
        global all_ids
        
        content_length = int(self.headers['Content-Length']) # <--- Gets the size of data
        post_data = json.loads(self.rfile.read(content_length)) # <--- Gets the data itself
        youtube_link=post_data['url']
        
        try:
            out,id_out=get_link(youtube_link)
            if id_out=='m3u8' :
                ready_data={'url':out,'type':'m3u8'}
            else:
                all_ids[id_out]=out
                ready_data={'url':id_out,'type':'direct'}
        except Exception as e:
            logging.warning(e)
            ready_data={'url':'None'}
        
        
        self.send_response(200)
        self.send_header('Content-type','text/html')
        self.end_headers()
            
            
           
        self.wfile.write(json.dumps(ready_data))
import socket
from contextlib import closing

def find_free_port():
    with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as s:
        s.bind(('', 0))
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        return s.getsockname()[1]
def start_server():
    free_port=find_free_port()

    if free_port!=int(Addon.getSetting("port")): 
        Addon.setSetting("port",str(free_port))
        xbmc.executebuiltin('Container.Refresh')
    logging.warning('free_port:'+str(free_port))
    PORT_NUMBER =free_port
    #Create a web server and define the handler to manage the
    #incoming request
    server = HTTPServer(('', PORT_NUMBER), myHandler)
    print 'Started httpserver on port ' , PORT_NUMBER
    
    #Wait forever for incoming htto requests
    server.serve_forever()

thread=[]
thread.append(Thread(start_server))

thread[0].start()
cond=xbmc.abortRequested
while not cond:
    xbmc.sleep(100)

server.socket.close()
