# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin#, xbmcaddon
import sys, re, gzip, json
from StringIO import StringIO
import urllib, urllib2

#AddonID = 'plugin.video.reshet'
#Addon = xbmcaddon.Addon(AddonID)
#AddonName = "Reshet"
#icon = Addon.getAddonInfo('icon')
handle = int(sys.argv[1])

def GetUrlJson(url):
	result = {}
	try:
		text = OpenURL(url)
		data_query = re.compile('data_query = \{(.*?)\};').findall(text)
		result = json.loads('{' + data_query[0] + '}') if len(data_query) > 0 else {}
	except:
		pass
	return result

def GetSeriesList():
	url = 'http://reshet.tv/general/programs/'
	result = GetUrlJson(url)
	if len(result) < 1:
		return
	seriesIDs = []
	grids = result.get('Content', {}).get('PageGrid', {})
	for grid in grids:
		for seriesID in grid['Posts']:
			if seriesID in seriesIDs or seriesID == 13555 or seriesID == 170768:
				continue
			seriesIDs.append(seriesID)
			serie = result.get('ItemStore', {}).get(str(seriesID), {})
			name = serie['title'].encode('utf-8')
			pageTitle = serie.get('pageTitle', {})
			description = name if pageTitle is None else pageTitle.get('description'.encode('utf-8'), name)
			addDir(name, serie['link'], 1, serie['images']['sidebar_portrait'].encode('utf-8'), infos={"Title": name, "Plot": description})
	
def GetSeasonList(url, name, iconimage):
	result = GetUrlJson(url)
	if len(result) < 1:
		return
	for grid in result['Content']['PageGrid']:
		if not 'GridTitle' in grid:
			continue
		if 'episodes' in grid['GridTitle']['link']:
			name = grid['GridTitle']['title'].encode('utf-8')
			addDir(name, grid['GridTitle']['link'], 2, iconimage, infos={"Title": name})

def GetEpisodesList(url, iconimage):
	result = GetUrlJson(url)
	if len(result) < 1:
		return
	grids = result.get('Content', {}).get('PageGrid', {})
	for grid in grids:
		for pid in grid['Posts']:
			post = result.get('ItemStore', {}).get(str(pid), {})
			if post['video']['videoID'] is None:
				continue
			icon =  post['images'].get('sidebar_portrait', iconimage).encode('utf-8')
			#icon =  post['video'].get('poster', icon)
			name = post['title'].encode('utf-8')
			addDir(name, post['video']['videoID'], 3, icon, infos={"Title": name, "Plot": post['subtitle'].encode('utf-8'), "Aired": post['publishDate']})

def Play(url):
	try:
		#url = 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=' + url
		result = OpenURL('https://edge.api.brightcove.com/playback/v1/accounts/1551111274001/videos/' + url, headers={"Accept": "application/json;pk=BCpkADawqM30eqkItS5d08jYUtMkbTKu99oEBllbfUaFKeknXu4iYsh75cRm2huJ_b1-pXEPuvItI-733TqJN1zENi-DcHlt7b4Dv6gCT8T3BS-ampD0XMnORQLoLvjvxD14AseHxvk0esW3"})
		sources = json.loads(result)['sources']
		url = ''
		avg_bitrate = 0
		for source in sources:
			if 'src' in source:
				if source['container'] == 'M2TS':
					url = source['src']
					break
				if source['avg_bitrate'] > avg_bitrate:
					url = source['src']
					avg_bitrate = source['avg_bitrate']
		listItem = xbmcgui.ListItem(path=url)
		xbmcplugin.setResolvedUrl(handle=handle, succeeded=True, listitem=listItem)
	except:
		pass

def OpenURL(url, headers={}, user_data={}, referer=None, Host=None):
	link = ""
	if user_data:
		user_data = urllib.urlencode(user_data)
		req = urllib2.Request(url, user_data)
	else:
		req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.86 Safari/537.36')
	req.add_header('Accept-encoding', 'gzip')
	for k, v in headers.items():
		req.add_header(k, v)
	if referer:
		req.add_header('Referer' ,referer)
	if Host:
		req.add_header('Host' ,Host)
	try:
		response = urllib2.urlopen(req,timeout=100)
		if response.info().get('Content-Encoding') == 'gzip':
			buf = StringIO( response.read())
			f = gzip.GzipFile(fileobj=buf)
			link = f.read()
		else:
			link = response.read()
		response.close()
	except Exception as ex:
		xbmc.log(str(ex), 3)
		return None
	return link
		
def addDir(name, url, mode, iconimage, infos={}, totalItems=None, isFolder=True):
	u = "{0}?url={1}&mode={2}&name={3}&iconimage={4}".format(sys.argv[0], urllib.quote_plus(url), str(mode), urllib.quote_plus(name), iconimage)

	if (iconimage == None):
		iconimage = "DefaultFolder.png"
		
	liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo(type="Video", infoLabels=infos)
	if mode==3:
		isFolder=False
		liz.setProperty("IsPlayable","true")
	if totalItems == None:
		ok = xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=liz,isFolder=isFolder)
	else:
		ok =xbmcplugin.addDirectoryItem(handle=handle,url=u,listitem=liz,isFolder=isFolder,totalItems=totalItems)
	
	return ok

def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring) >= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?','')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0].lower()] = splitparams[1]
	return param

params=get_params()
url = None
mode = None
name = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:        
	mode = int(params["mode"])
except:
	pass
try:      
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:        
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass
	

if mode == None or url == None or len(url) < 1:
	#------------- Series: -----------------
	GetSeriesList()
elif mode == 1:
	#------------- Seasons: -----------------
	GetSeasonList(url, name, iconimage)
elif mode == 2:
	#------------- Episodes: -----------------
	GetEpisodesList(url, iconimage)
elif mode == 3:
	#------------- Playing episode  -----------------
	Play(url)

xbmcplugin.setContent(handle, 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(handle)